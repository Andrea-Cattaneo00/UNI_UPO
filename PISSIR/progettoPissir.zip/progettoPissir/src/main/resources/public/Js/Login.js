document.getElementById("login_form").addEventListener("submbit", async (e) => {
e.preventDefault();

const email = document.querySelector('input[name="email"]').value;
const password =  document.querySelector('input[name="password"]').value;

    try {
       await login(email,password);
    } catch (error) {
        alert("Login failed: " +error.msg);
        return;
    }
});
