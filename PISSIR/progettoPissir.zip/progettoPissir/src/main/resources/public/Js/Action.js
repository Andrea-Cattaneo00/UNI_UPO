/**
 * Variabile globale che rappresenta il corpo della tabella degli istituti.
 */
let bodyTabella;

/**
 * Flag per determinare se la macchina è "nascosta" (disguised).
 */
let isMachineDisguised = true;

/**
 * Array contenente le checkbox selezionate.
 */
const selectedCheckboxes = [];

/**
 * Popola la tabella degli istituti al caricamento della pagina.
 */
document.addEventListener("DOMContentLoaded", async () => {
  const response = await checkSession();
  if (response) {
    document.querySelector(".login-btn").style.visibility = "hidden";
    document.querySelector(".login-btn").classList.add("no-hover");
    document.querySelector(".logout-btn").style.visibility = "visible";

    if (response.role === "employee") {
      document.querySelectorAll(".newInstituteBtn, .DeleteInstBtn, .newMachineBtn, .deleteMachineBtn")
        .forEach(e => e.classList.add("adminOnly"));
    }
  } else {
    document.querySelector(".login-btn").style.visibility = "visible";
    document.querySelector(".login-btn").classList.remove("no-hover");
    alert("To view the full page you must log in");
  }

  let institutes = await getAllInstitutes();
  bodyTabella = document.querySelector(".instituteTable");
  let counter = 0;

  institutes.forEach((institute) => {
    completeTable(institute, counter++);
  });
});

/**
 * Listener per il pulsante di eliminazione dell'istituto. Mostra i controlli di conferma.
 */
document.querySelectorAll(".deleteInstBtn").forEach((button) => {
  button.addEventListener("click", (e) => {
    const deleteBtn = e.currentTarget;
    deleteBtn.style.display = "none";

    const hiddenContainer = document.querySelector("#hiddenContainer");
    hiddenContainer.style.display = "flex";

    const elements = document.querySelectorAll(".disguiseI, .was-disguisedI");
    elements.forEach((elem) => {
      elem.classList.remove("disguiseI");
      elem.classList.add("was-disguisedI");
    });
  });
});

/**
 * Listener per il pulsante di annullamento dell'eliminazione istituto.
 */
document.querySelector(".cancelBtn").addEventListener("click", () => {
  const btnContainer = document.querySelector("#hiddenContainer");
  btnContainer.style.display = "none";

  const deleteInstBtn = document.querySelector(".deleteInstBtn");
  deleteInstBtn.style.display = "flex";

  const checkboxes = document.querySelectorAll(".disguiseI, .was-disguisedI");
  checkboxes.forEach((elem) => {
    elem.classList.add("disguiseI");
    elem.classList.remove("was-disguisedI");
  });
});

/**
 * Listener per il pulsante di conferma eliminazione istituto.
 */
document.querySelector(".confirmDeleteBtn").addEventListener("click", () => {
  if (selectedCheckboxes.length === 0) {
    Swal.fire({
      icon: "warning",
      title: "Warning",
      text: "No institute/s selected!",
    });
  }

  selectedCheckboxes.forEach((institute) => {
    const instID = institute.slice(1);

    deleteInstitute(instID).then(() => {
      Swal.fire({
        icon: "success",
        title: "Delete successfully done!",
        showConfirmButton: false,
        timer: 1500,
      }).then(() => {
        window.location.href = "HomePage.html";
      });
    });
  });
});

/**
 * Chiude il modulo per la creazione di un nuovo istituto.
 */
function closeModal() {
  document.getElementById("modal").style.display = "none";
}

/**
 * Apre il modulo per la creazione di un nuovo istituto.
 */
function openModal() {
  document.getElementById("modal").style.display = "flex";
}

/**
 * Aggiunge una riga alla tabella con i dati dell'istituto.
 * @param {Institute} institute - Oggetto istituto da visualizzare.
 * @param {number} counter - Indice della riga.
 */
async function completeTable(institute, counter) {
  const subId = `sub${counter++}`;
  const newRow = document.createElement("tr");
  newRow.classList.add("expandable");

  newRow.addEventListener("click", async function (e) {
    if (e.target.tagName === "INPUT" || e.target.closest(".checkbox-container"))
      return;
    await toggleSubTable(newRow, institute.id);
  });

  const nameCell = document.createElement("td");
  nameCell.innerHTML = `${institute.name} <span class="expand-icon"></span>`;
  nameCell.classList.add(institute.id.toString());

  const machineQuantity = await countMachineOfInst(institute.id);

  const quantityCell = document.createElement("td");
  quantityCell.textContent = machineQuantity;

  const cityCell = document.createElement("td");
  cityCell.textContent = institute.city;

  const incomeCell = document.createElement("td");
  incomeCell.textContent = institute.income.toFixed(2);

  const td = document.createElement("td");
  td.className = "disguiseI";

  const label = document.createElement("label");
  label.className = "checkbox-container disguise";

  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = false;
  input.value = "i" + institute.id;
  input.addEventListener("change", () => toggleSelection(input));

  const checkmark = document.createElement("div");
  checkmark.className = "checkmark";

  label.appendChild(input);
  label.appendChild(checkmark);
  td.appendChild(label);

  newRow.appendChild(nameCell);
  newRow.appendChild(quantityCell);
  newRow.appendChild(cityCell);
  newRow.appendChild(incomeCell);
  newRow.appendChild(td);

  bodyTabella.appendChild(newRow);
}


/**
 * Mostra o nasconde la sottotabella delle macchinette per un istituto specifico.
 * Se già visibile, la nasconde. Altrimenti, la carica tramite fetch e la mostra sotto la riga selezionata.
 * 
 * @async
 * @param {HTMLTableRowElement} row - La riga della tabella principale cliccata.
 * @param {number|string} instituteId - L'ID dell'istituto a cui appartengono le macchinette.
 */
async function toggleSubTable(row, instituteId) {
  const existingSubRow = document.querySelector(".subtable-row");

  if (row.classList.contains("expanded")) {
    row.classList.remove("expanded");
    if (existingSubRow) existingSubRow.remove();
    return;
  }

  if (existingSubRow) {
    existingSubRow.previousElementSibling.classList.remove("expanded");
    existingSubRow.remove();
  }

  if (existingSubRow && existingSubRow.previousElementSibling === row) return;

  const machines = await getMachinesByInstitute(instituteId);

  const subRow = document.createElement("tr");
  subRow.classList.add("subtable-row");

  const td = document.createElement("td");
  td.colSpan = 6;

  const innerTable = document.createElement("table");
  innerTable.classList.add("sub-table");

  const header = document.createElement("tr");
  header.innerHTML = `
  <th>Machine ID</th>
  <th>Income</th>
  <th>Status</th>
  <th>
    <button class="btn-action newMachineBtn" onClick="startNewMachineFlow(this)">New machine</button>
    <button class="btn-action cancelNewMachineBtn orange-bg" style="display: none;" onClick="cancelNewMachine(this)">Cancel</button>
    <button class="btn-action confirmNewMachineBtn" value="${instituteId}" style="display: none;" onClick="confirmNewMachine(this)">Confirm</button>
  </th>
  <th>
    <button class="btn-action deleteMachineBtn" value="${instituteId}" onClick="startDeleteMachinesFlow(this)">Delete machines</button>
    <button class="btn-action cancelDeleteMachinesBtn orange-bg" style="display: none;" onClick="cancelDeleteMachines(this)">Cancel</button>
    <button class="btn-action confirmDeleteMachinesBtn" style="display: none;" onClick="confirmDeleteMachines(this)">Confirm</button>
  </th>`;

  innerTable.appendChild(header);
  machines.forEach((machine) => {
    const machineRow = createMachineRow(machine);
    innerTable.appendChild(machineRow);
  });

  td.appendChild(innerTable);
  subRow.appendChild(td);
  row.parentNode.insertBefore(subRow, row.nextSibling);
  row.classList.add("expanded");
}

/**
 * Crea una riga HTML della sottotabella per una singola macchinetta.
 * Imposta anche i listener e la visibilità dei pulsanti in base allo stato della macchina.
 * 
 * @param {Object} machine - Oggetto rappresentante una macchinetta.
 * @param {number|string} machine.id - ID della macchinetta.
 * @param {number} machine.income - Guadagno attuale.
 * @param {string} machine.status - Stato attuale della macchinetta.
 * @param {number|string} machine.instituteId - ID dell'istituto proprietario.
 * @returns {HTMLTableRowElement} - La riga HTML costruita.
 */
function createMachineRow(machine) {
  const row = document.createElement("tr");
  row.innerHTML = `
    <td>${machine.id}</td>
    <td>${machine.income.toFixed(2)}</td>
    <td><button class="btn-action fillPodsBtn" value="${machine.id}" onClick="fillPodsInMachine(this.value)">Fill Pods</button></td>
    <td><button class="btn-action repairBtn" value="${machine.id}" onClick="repairMachine(this.value)">Repair</button></td>
    <td><button class="btn-action cashoutBtn" value="${machine.id}" data-inst-id="${machine.instituteId}" onClick="collectCashbox(this)">Cash out</button></td>
    <td class="disguiseM">
      <label class="checkbox-container"> 
        <input type="checkbox" value="m${machine.id}">
        <div class="checkmark"></div>
      </label>
    </td>`;

  const checkbox = row.querySelector("input[type='checkbox']");
  checkbox.addEventListener("change", () => toggleSelection(checkbox));

  checkStatusBtns(machine, row);
  return row;
}

/**
 * Controlla lo stato della macchinetta e mostra solo il pulsante pertinente (cash out, riempi pod, ripara).
 * 
 * @param {Object} machine - Oggetto macchinetta con proprietà di stato.
 * @param {HTMLTableRowElement} row - La riga DOM della macchinetta.
 */
function checkStatusBtns(machine, row) {
  const MachineStatus = {
    BROKEN: "BROKEN",
    WORKING: "WORKING",
    BALANCE_FULL: "BALANCE_FULL",
    EMPTY_PODS: "EMPTY_PODS",
  };

  const cashoutBtn = row.querySelector(".cashoutBtn");
  const fillPodsBtn = row.querySelector(".fillPodsBtn");
  const repairBtn = row.querySelector(".repairBtn");
  cashoutBtn.style.display = "none";
  fillPodsBtn.style.display = "none";
  repairBtn.style.display = "none";

  if (machine.status == MachineStatus.BALANCE_FULL) {
    cashoutBtn.style.display = "flex";
  } else if (machine.status == MachineStatus.EMPTY_PODS) {
    fillPodsBtn.style.display = "flex";
  } else if (machine.status == MachineStatus.BROKEN) {
    repairBtn.style.display = "flex";
  }
}

/**
 * Listener globale per attivare o disattivare la modalità "selezione macchinette da eliminare".
 * Alterna le classi CSS `disguiseM` e `was-disguisedM` sugli elementi.
 * 
 * @param {MouseEvent} e - Evento di click.
 */
document.addEventListener("click", function (e) {
  if (e.target && e.target.classList.contains("deleteMachineBtn")) {
    const elements = document.querySelectorAll(".disguiseM, .was-disguisedM");
    elements.forEach((elem) => {
      if (isMachineDisguised) {
        elem.classList.remove("disguiseM");
        elem.classList.add("was-disguisedM");
      } else {
        elem.classList.add("disguiseM");
        elem.classList.remove("was-disguisedM");
      }
    });
    isMachineDisguised = !isMachineDisguised;
  }
});

/**
 * Avvia il flusso di creazione di una nuova macchinetta, mostrando i pulsanti "Annulla" e "Conferma".
 * 
 * @param {HTMLButtonElement} button - Il pulsante "New machine" cliccato.
 */
function startNewMachineFlow(button) {
  const containerTh = button.parentElement;
  button.style.display = "none";
  containerTh.querySelector(".confirmNewMachineBtn").style.display = "inline-block";
  containerTh.querySelector(".cancelNewMachineBtn").style.display = "inline-block";
}

/**
 * Conferma la creazione della nuova macchinetta richiamando `createNewMachine()`.
 * Ripristina i pulsanti originali.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Confirm" cliccato.
 */
function confirmNewMachine(button) {
  const instId = button.value;
  createNewMachine(instId);
  const containerTh = button.parentElement;
  containerTh.querySelector(".newMachineBtn").style.display = "inline-block";
  containerTh.querySelector(".confirmNewMachineBtn").style.display = "none";
  containerTh.querySelector(".cancelNewMachineBtn").style.display = "none";
}

/**
 * Annulla la creazione della nuova macchinetta e ripristina la visualizzazione originale dei pulsanti.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Cancel" cliccato.
 */
function cancelNewMachine(button) {
  const containerTh = button.parentElement;
  containerTh.querySelector(".newMachineBtn").style.display = "inline-block";
  containerTh.querySelector(".confirmNewMachineBtn").style.display = "none";
  containerTh.querySelector(".cancelNewMachineBtn").style.display = "none";
}


/**
 * Annulla la creazione di una nuova macchinetta e ripristina i pulsanti originali.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Cancel" cliccato.
 */
function cancelNewMachine(button) {
  const containerTh = button.parentElement;
  containerTh.querySelector(".newMachineBtn").style.display = "inline-block";
  containerTh.querySelector(".confirmNewMachineBtn").style.display = "none";
  containerTh.querySelector(".cancelNewMachineBtn").style.display = "none";
}

/**
 * Mostra i pulsanti "Annulla" e "Conferma" per la cancellazione delle macchinette.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Delete machines" cliccato.
 */
function startDeleteMachinesFlow(button) {
  const containerTh = button.parentElement;
  button.style.display = "none";
  containerTh.querySelector(".confirmDeleteMachinesBtn").style.display = "inline-block";
  containerTh.querySelector(".cancelDeleteMachinesBtn").style.display = "inline-block";
}

/**
 * Conferma la cancellazione delle macchinette selezionate.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Confirm" cliccato.
 */
function confirmDeleteMachines(button) {
  deleteMachines(button);
  const containerTh = button.parentElement;
  containerTh.querySelector(".deleteMachineBtn").style.display = "inline-block";
  containerTh.querySelector(".confirmDeleteMachinesBtn").style.display = "none";
  containerTh.querySelector(".cancelDeleteMachinesBtn").style.display = "none";
}

/**
 * Annulla il flusso di cancellazione delle macchinette e ripristina i pulsanti e le checkbox.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Cancel" cliccato.
 */
function cancelDeleteMachines(button) {
  const containerTh = button.parentElement;
  containerTh.querySelector(".deleteMachineBtn").style.display = "inline-block";
  containerTh.querySelector(".confirmDeleteMachinesBtn").style.display = "none";
  containerTh.querySelector(".cancelDeleteMachinesBtn").style.display = "none";

  const elements = document.querySelectorAll(".disguiseM, .was-disguisedM");
  elements.forEach((elem) => {
    elem.classList.add("disguiseM");
    elem.classList.remove("was-disguisedM");
  });

  isMachineDisguised = true;
}

/**
 * Richiama l'API per riparare una macchinetta rotta.
 * Mostra un alert in base all'esito e ricarica la pagina.
 * 
 * @async
 * @param {string|number} machineID - L'ID della macchinetta da riparare.
 */
async function repairMachine(machineID) {
  const response = await repairMachineAPI(machineID);
  if (response == true) {
    Swal.fire({
      icon: "success",
      title: "Repair successfully performed!",
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
      location.reload();
    });
  } else {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "Failed to repair the machine",
    });
  }
}

/**
 * Riempie i pod della macchinetta e tenta il reset dello stato macchina.
 * 
 * @async
 * @param {string|number} machineID - L'ID della macchinetta.
 */
async function fillPodsInMachine(machineID) {
  const response = await ReloadPods(machineID);
  if (response == true) {
    Swal.fire({
      icon: "success",
      title: "Successfully filled capsules!",
      showConfirmButton: false,
      timer: 1500,
    }).then(async () => {
      const response2 = await repairMachineAPI(machineID);
      if (!response2) {
        alert("Error during the reset of the machine status with id : " + machineID);
      }
      location.reload();
    });
  } else {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "Failed to fill the machine",
    });
  }
}

/**
 * Raccoglie i soldi dalla cashbox della macchinetta e aggiorna l'incasso dell'istituto.
 * 
 * @async
 * @param {HTMLButtonElement} button - Il pulsante "Cash out" cliccato.
 */
async function collectCashbox(button) {
  const machineId = button.value;
  const result = await CashFromMachine(machineId);

  if (isNaN(result)) {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "Failed to collect the cashbox machine",
    });
  } else {
    const instID = button.dataset.instId;
    const res = await updateInstituteIncome(result, instID);
    if (res) {
      Swal.fire({
        icon: "success",
        title: "Cashout done!",
        timer: 1500,
        showConfirmButton: false,
        text: "Cashout successfully done!",
      }).then(() => {
        location.reload();
      });
    } else {
      alert("errore");
      location.reload();
    }
  }
}

/**
 * Listener per la creazione di un nuovo istituto e delle sue macchinette associate.
 * 
 * @event submit
 * @param {SubmitEvent} e - Evento di submit del form.
 */
document.querySelector("#newInstForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.querySelector("#instName").value;
  const city = document.querySelector("#instCity").value;
  const quantity = parseInt(document.querySelector("#instQuantity").value);

  const institute = new Institute(null, name, city, 0.0);
  const newInstID = await addInstitute(institute);

  if (!newInstID) {
    alert("Error during the creation of the institute!");
    return;
  }

  let counter = 0;
  for (let count = 0; count < quantity; count++) {
    const success = await addMachine(newInstID.id);
    if (success) {
      counter++;
    }
  }

  if (counter === quantity) {
    Swal.fire({
      icon: "success",
      title: "Creation successfull done!",
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
      location.reload();
    });
  } else {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "Failed to create all the machines",
    });
  }
});

/**
 * Aggiunge o rimuove una macchinetta selezionata per la cancellazione tramite checkbox.
 * 
 * @param {HTMLInputElement} checkbox - La checkbox cliccata.
 */
function toggleSelection(checkbox) {
  const value = checkbox.value;
  if (checkbox.checked) {
    if (!selectedCheckboxes.includes(value)) {
      selectedCheckboxes.push(value);
    }
  } else {
    const index = selectedCheckboxes.indexOf(value);
    if (index > -1) {
      selectedCheckboxes.splice(index, 1);
    }
  }
}

/**
 * Aggiunge una nuova macchinetta all’istituto e ricarica la pagina.
 * 
 * @async
 * @param {string|number} instId - ID dell’istituto.
 */
async function createNewMachine(instId) {
  await addMachine(instId);
  location.reload();
}

/**
 * Elimina una singola macchinetta tramite chiamata API.
 * Mostra un alert di conferma o errore.
 * 
 * @param {string|number} machineId - L’ID della macchinetta da eliminare.
 */
function removeMachine(machineId) {
  deliteMachine(machineId)
    .then(() => {
      Swal.fire({
        icon: "success",
        title: "Machine removed",
        text: "Machine removed successfully!",
      });
    })
    .catch(() => {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "Failed to remove machine",
      });
    });
}

/**
 * Cancella tutte le macchinette selezionate tramite checkbox.
 * Rimuove le righe dal DOM, aggiorna l'array dei selezionati e mostra un messaggio di conferma o errore.
 * 
 * @param {HTMLButtonElement} button - Il pulsante "Confirm delete" cliccato.
 */
function deleteMachines(button) {
  const machineIds = selectedCheckboxes
    .filter((id) => id.startsWith("m"))
    .map((id) => id.slice(1));

  if (machineIds.length === 0) {
    Swal.fire({
      icon: "warning",
      title: "Warning",
      text: "No machine selected!",
    });
    return;
  }

  Promise.all(machineIds.map((id) => deliteMachine(id)))
    .then(() => {
      machineIds.forEach((id) => {
        const checkbox = document.querySelector(`input[value="m${id}"]`);
        if (checkbox) {
          const row = checkbox.closest("tr");
          if (row) row.remove();
        }
      });

      machineIds.forEach((id) => {
        const index = selectedCheckboxes.indexOf("m" + id);
        if (index !== -1) selectedCheckboxes.splice(index, 1);
      });

      Swal.fire({
        icon: "success",
        title: "Machines deleted successfully!",
        showConfirmButton: false,
        timer: 1500,
      });
    })
    .catch(() => {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "An error occurred during deletion.",
      });
    });
}

/**
 * Chiamata API per cancellare una macchinetta tramite metodo HTTP DELETE.
 * 
 * @async
 * @param {string|number} machineId - L’ID della macchinetta.
 * @returns {Promise<boolean>} - Ritorna `true` se la cancellazione ha avuto successo, altrimenti `false`.
 */
async function deliteMachine(machineId) {
  try {
    const response = await fetch(`/api/machines/${machineId}`, {
      method: "DELETE",
    });

    if (!response.ok) {
      throw new Error("Delete failed");
    }

    return true;
  } catch (err) {
    console.error("Errore durante la cancellazione:", err);
    return false;
  }
}

