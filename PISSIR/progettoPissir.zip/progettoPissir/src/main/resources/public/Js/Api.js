/**
 * URL base per tutte le chiamate API.
 * @constant {string}
 */
const URL = "http://localhost:8080/web/pissir";

/**
 * Rappresenta un utente del sistema.
 */
class User {
  constructor(id, email, role) {
    this.id = id;
    this.email = email;
    this.role = role;
  }

  /**
   * Crea un oggetto User da un JSON.
   * @param {Object} json - Oggetto JSON con proprietà id, email e role.
   * @returns {User}
   */
  static from(json) {
    return new User(json.id, json.email, json.role);
  }
}

/**
 * Rappresenta un istituto con le sue macchinette.
 */
class Institute {
  constructor(id, name, quantity, city, income) {
    this.id = id;
    this.name = name;
    this.quantity = quantity;
    this.city = city;
    this.income = income;
  }

  /**
   * Crea un oggetto Institute da un JSON.
   * @param {Object} json - Oggetto JSON con id, name, quantity, city, income.
   * @returns {Institute}
   */
  static from(json) {
    return new Institute(
      json.id,
      json.name,
      json.quantity,
      json.city,
      json.income
    );
  }
}

/**
 * Rappresenta una macchinetta.
 */
class Machine {
  constructor(id, instituteId, status, income) {
    this.id = id;
    this.instituteId = instituteId;
    this.status = status;
    this.income = income;
  }

  /**
   * Crea un oggetto Machine da un JSON.
   * @param {Object} json - Oggetto JSON con id, instituteId, status, income.
   * @returns {Machine}
   */
  static from(json) {
    return new Machine(json.id, json.instituteId, json.status, json.income);
  }
}

/**
 * Enum degli stati della macchinetta.
 */
const MachineStatus = {
  BROKEN: 0,
  WORKING: 1,
  BALANCE_FULL: 2,
  EMPTY_PODS: 3,

  /**
   * Ritorna lo stato della macchina a partire dal valore numerico.
   * @param {number} value - Valore numerico dello stato.
   * @returns {number} - Stato corrispondente.
   */
  fromValue(value) {
    switch (value) {
      case 0:
        return this.BROKEN;
      case 1:
        return this.WORKING;
      case 2:
        return this.BALANCE_FULL;
      case 3:
        return this.EMPTY_PODS;
      default:
        throw new Error("Invalid status value: " + value);
    }
  },
};

/**
 * Verifica se l'utente corrente ha ruolo admin.
 * @returns {Promise<boolean>}
 */
async function ensureAdmin() {
  const user = await getCurrentUser();
  if (user.role !== "admin") {
    return false;
  }
  return true;
}

/**
 * Controlla la validità della sessione corrente.
 * @returns {Promise<Object|null>} - Oggetto con dati sessione o null se non valida.
 */
async function checkSession() {
  const response = await fetch(getFullUrl("api/checkSession"), {
    method: "GET",
    credentials: "include",
  });

  if(response.status === 200) {
    const data = await response.json();
    return data;
  } else {
    return null;
  }
}

/**
 * Effettua il login con email e password.
 * @param {string} email
 * @param {string} password
 */
async function login(email, password) {
  const response = await fetch(getFullUrl("login"), {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });

  if (response.status === 200) {
    Swal.fire({
      icon: "success",
      title: "Login successfull!",
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
      window.location.href = "HomePage.html";
    });
  } else if (response.status === 400) {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "Internal server error",
    });
  }
}

/**
 * Effettua il logout dell'utente e reindirizza alla pagina di login.
 * @throws {LogoutError} - In caso di errore di rete o del server.
 */
async function logout() {
  try {
    const response = await fetch(getFullUrl("logout"), {
      method: "POST",
      credentials: "include",
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new LogoutError(response.status, errorText);
    } else if (response.status == 200) {
      window.location.href = "Login.html";
    }
  } catch (error) {
    throw new LogoutError(500, "Errore di rete o interno: " + error.message);
  }
}

/**
 * Recupera i dati dell'utente attualmente loggato.
 * @returns {Promise<User>} - Oggetto utente.
 * @throws {Object} - Errore con status e messaggio.
 */
async function getCurrentUser() {
  const response = await fetch(getFullUrl("get/user"), {
    method: "GET",
    credentials: "include",
    headers: { Accept: "application/json" },
  });

  if (response.ok) {
    const userJson = await response.json();
    return User.from(userJson);
  } else {
    const errorText = await response.text();
    throw { status: response.status, msg: errorText };
  }
}

/**
 * Registra un nuovo utente nel sistema.
 * @param {string} email
 * @param {string} password
 * @param {string} role
 * @returns {Promise<string>} - Risposta testuale dal server.
 */
async function registerUser(email, password, role) {
  const response = await fetch(getFullUrl("register"), {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, role }),
  });

  if (response.status === 409) {
    Swal.fire({
      icon: "error",
      title: "Email already registered",
      text: "This email is already registered, you can do the login",
    });
  } else if (response.status === 404) {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "Internal server error",
    });
  } else if (response.status === 200) {
    Swal.fire({
      icon: "success",
      title: "Registrazione avvenuta!",
      showConfirmButton: false,
      timer: 1500,
    }).then(() => {
      window.location.href = "HomePage.html";
    });
  }
  return await response.text();
}

/**
 * Recupera tutti gli istituti presenti.
 * @returns {Promise<Institute[]>} - Lista di oggetti Institute.
 */
async function getAllInstitutes() {
  try {
    const response = await fetch(getFullUrl("institutes"), {
      method: "GET",
      credentials: "include",
      headers: { Accept: "application/json" },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }
    const institutesJson = await response.json();

    return institutesJson.map(Institute.from);
  } catch (error) {
    throw new Error(
      `Errore nel recupero degli istituti: ${error.message || error}`
    );
  }
}

/**
 * Aggiunge un nuovo istituto.
 * @param {Institute} institute - L'oggetto da inviare al server.
 * @returns {Promise<Object|null>} - Risposta del server o null se errore.
 */
async function addInstitute(institute) {
  const response = await fetch(getFullUrl("institutes/add"), {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(institute),
  });

  if (!response.ok) {
    return null;
  }
  const data = await response.json();

  return data;
}

/**
 * Elimina un istituto dal sistema dato il suo ID.
 * @param {number|string} id - ID dell’istituto.
 * @throws {Error} - In caso di errore HTTP.
 */
async function deleteInstitute(id) {
  const response = await fetch(getFullUrl(`institutes/${id}`), {
    method: "DELETE",
    credentials: "include",
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`HTTP ${response.status}: ${errorText}`);
  }
}

/**
 * Recupera tutte le macchinette associate a un istituto.
 * @param {number|string} instituteId - ID dell’istituto.
 * @returns {Promise<Machine[]>}
 */
async function getMachinesByInstitute(instituteId) {
  try {
    const response = await fetch(
      getFullUrl(`machines/${instituteId}/institute`),
      {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const machinesJson = await response.json();
    return machinesJson.map(Machine.from);
  } catch (error) {
    throw new Error(
      `Errore nel recupero delle macchine: ${error.message || error}`
    );
  }
}





/**
 * Conta il numero di macchinette associate a un istituto.
 * @param {number|string} instituteID - ID dell’istituto.
 * @returns {Promise<number>} - Numero totale di macchinette.
 */
async function countMachineOfInst(instituteID) {
  try {
    const response = await fetch(
      getFullUrl(`institutes/${instituteID}/count/machines`),
      {
        method: "GET",
        credentials: "include",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    return data.total;
  } catch (error) {
    throw new Error(
      `Errore nel recupero delle macchine: ${error.message || error}`
    );
  }
}

/**
 * Aggiunge una macchinetta a un istituto.
 * @param {number|string} instituteId - ID dell’istituto.
 * @returns {Promise<boolean>} - True se creazione avvenuta, false altrimenti.
 */
async function addMachine(instituteId) {
  const response = await fetch(getFullUrl("machines/add"), {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(instituteId),
  });
  if (response.status === 400) {
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "During the creation of the new machine",
    });
    return false;
  } else if (response.status === 200) {
    Swal.fire({
      icon: "success",
      title: "Machine has been created successfully!",
      showConfirmButton: false,
      timer: 1500,
    });
    return true;
  }
  return false;
}

/**
 * Elimina una macchinetta dal sistema.
 * @param {number|string} id - ID della macchinetta.
 * @throws {Error} - In caso di errore HTTP.
 */
async function deleteMachine(id) {
  const response = await fetch(getFullUrl(`machines/${id}`), {
    method: "DELETE",
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`HTTP ${response.status}: ${errorText}`);
  }
}

/**
 * Raccoglie i contanti da una macchinetta.
 * @param {number|string} machineId - ID della macchinetta.
 * @returns {Promise<number>} - Valore in euro prelevato dalla macchina.
 */
async function CashFromMachine(machineId) {
  try {
    const response = await fetch(getFullUrl(`machines/${machineId}/collect`), {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const respText = await response.text();
    const cashboxValue = parseFloat(respText);
    if (isNaN(cashboxValue)) throw new Error(`Risposta non valida dal server: ${respText}`);

    return cashboxValue;
  } catch (error) {
    throw new Error(`Errore nel ritiro contanti: ${error.message || error}`);
  }
}

/**
 * Aggiorna il valore della cassa della macchinetta.
 * @param {number|string} machineID - ID della macchinetta.
 * @returns {Promise<number>} - Nuovo valore della cassa.
 */
async function updateMachineCashbox(machineID) {
  try {
    const response = await fetch(
      getFullUrl(`machines/${machineID}/update/income`),
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const text = await response.text();
    return parseFloat(text);
  } catch (error) {
    throw new Error(`Errore nel ritiro contanti: ${error.message || error}`);
  }
}

/**
 * Aggiorna il guadagno totale dell’istituto.
 * @param {number} cashboxValue - Importo da aggiungere.
 * @param {number|string} instID - ID dell’istituto.
 * @returns {Promise<boolean>}
 */
async function updateInstituteIncome(cashboxValue, instID) {
  try {
    const response = await fetch(getFullUrl(`institutes/update/${instID}/income`), {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(cashboxValue),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    return true;
  } catch (error) {
    throw new Error(`Errore nel ritiro contanti: ${error.message || error}`);
  }
}

/**
 * Ricarica le cialde di una macchinetta.
 * @param {number|string} machineId - ID della macchinetta.
 * @returns {Promise<boolean>}
 */
async function ReloadPods(machineId) {
  try {
    const response = await fetch(
      getFullUrl(`machines/${machineId}/refillPods`),
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    return true;
  } catch (error) {
    throw new Error(
      `Errore nel rifornimento delle cialde: ${error.message || error}`
    );
  }
}

/**
 * Ripara una macchinetta guasta.
 * @param {number|string} machineId - ID della macchinetta.
 * @returns {Promise<boolean>}
 */
async function repairMachineAPI(machineId) {
  try {
    const response = await fetch(
      getFullUrl(`machines/${machineId}/fixMachine`),
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    return true;
  } catch (error) {
    throw new Error(
      `Errore nella riparazione della macchina: ${error.message || error}`
    );
  }
}

/**
 * Recupera i ricavi di una singola macchinetta.
 * @param {number|string} machineId - ID della macchinetta.
 * @returns {Promise<Object[]>} - Lista dei ricavi.
 */
async function fetchMachineIncomes(machineId) {
  try {
    const response = await fetch(getFullUrl(`revenues/${machineId}`), {
      method: "GET",
      credentials: "include",
      headers: { Accept: "application/json" },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const incomesJson = await response.json();
    return incomesJson.map(Income.from);
  } catch (error) {
    throw new Error(
      `Errore nel recupero ricavi macchina: ${error.message || error}`
    );
  }
}

/**
 * Recupera tutti i ricavi del sistema.
 * @returns {Promise<Object[]>} - Lista dei ricavi globali.
 */
async function fetchAllIncomes() {
  try {
    const response = await fetch(getFullUrl("revenues"), {
      method: "GET",
      credentials: "include",
      headers: { Accept: "application/json" },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const incomesJson = await response.json();
    return incomesJson.map(Income.from);
  } catch (error) {
    throw new Error(
      `Errore nel recupero di tutti i ricavi: ${error.message || error}`
    );
  }
}

/**
 * Costruisce l’URL completo per una richiesta API.
 * @param {string} path - Il path relativo all’endpoint.
 * @returns {string} - URL completo.
 */
function getFullUrl(path) {
  return `${URL}/${path}`;
}
