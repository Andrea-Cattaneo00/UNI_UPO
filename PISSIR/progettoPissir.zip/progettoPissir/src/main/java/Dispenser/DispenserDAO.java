package Dispenser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DB.DBConnection;

/**
 * Classe DAO che fornisce metodi per accedere alle informazioni sui pod e prezzi 
 * associati ai prodotti, nonché per verificarne la disponibilità.
 */
public class DispenserDAO {

    /**
     * Restituisce la lista degli ID dei pod necessari per preparare un prodotto.
     *
     * @param idProdChoosen ID del prodotto scelto
     * @param machineID     ID della macchina (non utilizzato nella query ma mantenuto per compatibilità)
     * @return lista di ID dei pod necessari
     */
    public static ArrayList<Integer> getNecessaryPods(int idProdChoosen, int machineID) {
        final String query = "SELECT idPod1, idPod2, idPod3 FROM Pods WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            st.setInt(1, idProdChoosen);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                ArrayList<Integer> pods = new ArrayList<>();

                Integer idPod1 = (Integer) rs.getObject("idPod1");
                if (idPod1 != null)
                    pods.add(idPod1);

                Integer idPod2 = (Integer) rs.getObject("idPod2");
                if (idPod2 != null)
                    pods.add(idPod2);

                Integer idPod3 = (Integer) rs.getObject("idPod3");
                if (idPod3 != null)
                    pods.add(idPod3);

                return pods;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    /**
     * Verifica se tutti i pod richiesti sono disponibili nella macchina specificata.
     *
     * @param machineID ID della macchina
     * @param pods      lista di ID dei pod da controllare
     * @return {@code true} se tutti i pod sono disponibili, {@code false} altrimenti
     */
    public static boolean checkProductAvailability(int machineID, ArrayList<Integer> pods) {
        final String query = "SELECT * FROM Capsules_in_machines WHERE id_capsule = ? AND id_machine = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            for (int podId : pods) {
                st.setInt(1, podId);
                st.setInt(2, machineID);

                try (ResultSet rs = st.executeQuery()) {
                    if (rs.next()) {
                        int podQuantity = rs.getInt("quantity");
                        if (podQuantity <= 0)
                            return false;
                    } else {
                        return false;
                    }
                }
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return false;
    }

    /**
     * Restituisce il prezzo di un prodotto in base al suo ID.
     *
     * @param userChoice ID del prodotto scelto
     * @return prezzo del prodotto, oppure {@code 0.0} se non trovato o in caso di errore
     */
    public static double getPrice(int userChoice) {
        final String query = "SELECT price FROM Pods WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            st.setInt(1, userChoice);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                double price = rs.getDouble("price");
                return price;
            } else {
                return 0.0;
            }

        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return 0.0;
    }
}
