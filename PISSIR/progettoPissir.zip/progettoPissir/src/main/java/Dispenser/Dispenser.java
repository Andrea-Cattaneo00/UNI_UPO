package Dispenser;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import Client.MQTTClient;
import FrontendMachine.FrontendDAO;
import Models.Drink;
import Models.Machine;

/**
 * Classe principale del modulo Dispenser. 
 * Gestisce le richieste MQTT relative a lista bevande, disponibilità prodotti, 
 * informazioni sulle macchine e prezzi.
 */
public class Dispenser {

    static Gson gson = new Gson();
    private static MQTTClient mqttClient;

    /**
     * Metodo principale che avvia la configurazione MQTT.
     *
     * @param args argomenti da linea di comando (non utilizzati)
     */
    public static void main(String[] args) {
        setUpMQTT();
    }

    /**
     * Configura il client MQTT e sottoscrive i topic utilizzati per la comunicazione 
     * con le macchine Frontend.
     */
    private static void setUpMQTT() {
        String serverURL = "ssl://localhost:8883";
        String clientID = "Dispenser";  
        System.out.println("Dispenser online");
        System.out.println("Client ID in use: " + clientID);

        String clientCertPath = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.p12";
        String clientKeyPath  = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.key";

        mqttClient = new MQTTClient(serverURL, clientID, clientCertPath, clientKeyPath);
        mqttClient.connect();

        // 1) Gestione richiesta lista bevande
        mqttClient.subscribe("/drinks/list/+/request", (topic, msg) -> {
            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);

            List<Drink> dispensableDrinks = FrontendDAO.getAllDrinks();
            String drinksJson = gson.toJson(dispensableDrinks);
            mqttClient.publish(
                "/drinks/list/" + requestedMachineID + "/response",
                drinksJson.getBytes(StandardCharsets.UTF_8)
            );
        });

        // 2) Gestione verifica disponibilità prodotto
        mqttClient.subscribe("/check/availability/+/request", (topic, msg) -> {
            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);
            int userChoice = ByteBuffer.wrap(msg.getPayload()).getInt();

            ArrayList<Integer> pods = DispenserDAO.getNecessaryPods(userChoice, requestedMachineID);
            byte[] response = new byte[1];
            response[0] = (byte) (pods.isEmpty() || !DispenserDAO.checkProductAvailability(requestedMachineID, pods) 
                                  ? 0 
                                  : 1);

            mqttClient.publish(
                "/check/availability/" + requestedMachineID + "/response",
                response
            );
        });

        // 3) Gestione richiesta informazioni macchina
        mqttClient.subscribe("/get/machine_infos/+/request", (topic, msg) -> {
            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);

            Machine machineInfos = FrontendDAO.getSpecsMachine(requestedMachineID);
            if (machineInfos != null) {
                String json = gson.toJson(machineInfos);
                mqttClient.publish(
                    "/get/machine_infos/" + requestedMachineID + "/response",
                    json.getBytes(StandardCharsets.UTF_8)
                );
            } else {
                System.err.println("Error retrieving machine info for ID: " + requestedMachineID);
            }
        });

        // 4) Gestione richiesta prezzo prodotto
        mqttClient.subscribe("/get/prod_price/+/request", (topic, msg) -> {
            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);
            int userChoice = ByteBuffer.wrap(msg.getPayload()).getInt();

            double prodPrice = DispenserDAO.getPrice(userChoice);
            if (prodPrice > 0.0) {
                byte[] priceBytes = ByteBuffer.allocate(Double.BYTES).putDouble(prodPrice).array();
                mqttClient.publish(
                    "/get/prod_price/" + requestedMachineID + "/response",
                    priceBytes
                );
            } else {
                System.err.println("Error retrieving product price for ID: " + userChoice);
            }
        });
    }
}
