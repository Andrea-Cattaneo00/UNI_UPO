package Models;

/**
 * Rappresenta una capsula (pod) utilizzata da una macchinetta per preparare bevande.
 */
public class Pod {
    
    private int id;  // Identificativo univoco della capsula
    private int currentQuantity; // Quantità attualmente disponibile nella macchinetta
    private final int maxQuantity; // Quantità massima che può contenere la macchinetta
    private String type; // Tipo di capsula (es. Caffè, Thè, ecc.)

    /**
     * Costruttore della classe Pod.
     *
     * @param id              identificativo della capsula
     * @param currentQuantity quantità attuale nella macchinetta
     * @param maxQuantity     quantità massima supportata
     * @param type            tipo della capsula (es. "Caffè", "Thè")
     */
    public Pod(int id, int currentQuantity, int maxQuantity, String type) {
        this.id = id;
        this.currentQuantity = currentQuantity;
        this.maxQuantity = maxQuantity;
        this.type = type;
    }

    /**
     * Restituisce la quantità attuale di capsule disponibili.
     *
     * @return quantità disponibile
     */
    public int getCurrentQuantity() {
        return currentQuantity;
    }

    /**
     * Imposta la quantità attuale di capsule disponibili.
     *
     * @param currentQuantity nuova quantità disponibile
     */
    public void setCurrentQuantity(int currentQuantity) {
        this.currentQuantity = currentQuantity;
    }

    /**
     * Restituisce la quantità massima di capsule supportata dalla macchinetta.
     *
     * @return quantità massima
     */
    public int getMaxQuantity() {
        return maxQuantity;
    }

    /**
     * Restituisce il tipo di capsula.
     *
     * @return tipo di capsula (es. "Caffè")
     */
    public String getType() {
        return type;
    }

    /**
     * Imposta il tipo di capsula.
     *
     * @param type nuovo tipo di capsula
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Restituisce l'identificativo della capsula.
     *
     * @return ID della capsula
     */
    public int getId() {
        return id;
    }

    /**
     * Imposta l'identificativo della capsula.
     *
     * @param id nuovo ID della capsula
     */
    public void setId(int id) {
        this.id = id;
    }
}
