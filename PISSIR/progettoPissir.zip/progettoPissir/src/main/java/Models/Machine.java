package Models;

/**
 * Rappresenta una macchinetta distributrice con attributi relativi al suo stato,
 * alla quantità di denaro presente nella cassa (cashBox), al credito inserito dall'utente
 * e ad altri dati identificativi.
 */
public class Machine {

    private int id;
    private double cashBox; // Valore attuale della cassa
    private static final double MaxCashBox = 200.0; // Limite massimo di denaro nella cassa
    private double credit; // Credito inserito dall'utente
    private MachineStatus status; // Stato della macchina: BROKEN (0) o WORKING (1)
    private int id_institute;

    /**
     * Costruttore base della macchinetta.
     *
     * @param id        ID della macchinetta
     * @param cashBox   Quantità attuale di denaro nella cassa
     * @param status    Stato della macchinetta
     */
    public Machine(int id, double cashBox, MachineStatus status) {
        this.id = id;
        this.cashBox = cashBox;
        this.status = status;
    }

    /**
     * Restituisce una rappresentazione testuale della macchina.
     */
    @Override
    public String toString() {
        return "Machine{" +
               "id=" + id +
               ", cashBox=" + cashBox +
               ", status=" + status +
               ", id_institute=" + id_institute +
               '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getCashBox() {
        return cashBox;
    }

    public void setCashBox(double cashBox) {
        this.cashBox = cashBox;
    }

    /**
     * Restituisce il valore massimo della cassa.
     *
     * @return limite massimo della cashBox
     */
    public static double getMaxCashBox() {
        return MaxCashBox;
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    /**
     * Aggiunge credito alla macchina.
     *
     * @param credit importo da aggiungere
     */
    public void addCredit(double credit) {
        this.credit += credit;
    }

    public MachineStatus getStatus() {
        return status;
    }

    public void setStatus(MachineStatus status) {
        this.status = status;
    }

    /**
     * Verifica se la macchina è guasta.
     *
     * @return true se lo stato è BROKEN
     */
    public boolean isBroken() {
        return status == MachineStatus.BROKEN;
    }

    /**
     * Verifica se la cassa ha raggiunto il limite massimo.
     *
     * @return true se la cassa è piena
     */
    public boolean isCashboxFull() {
        return cashBox >= MaxCashBox;
    }

    /**
     * Verifica se la macchina può accettare un pagamento di un certo importo.
     *
     * @param amount importo da verificare
     * @return true se è possibile accettare il pagamento
     */
    public boolean canAcceptPayment(double amount) {
        return status == MachineStatus.WORKING && (cashBox + amount) <= MaxCashBox;
    }
}
