package Models;

/**
 * Enum che rappresenta lo stato di una macchina distributrice.
 * Ogni stato è associato a un valore intero e a un messaggio descrittivo.
 */
public enum MachineStatus {

    /**
     * Stato in cui la macchina è guasta.
     */
    BROKEN(0, "Error, the machine is broken"),

    /**
     * Stato in cui la macchina è operativa.
     */
    WORKING(1, "Machine working"),

    /**
     * Stato in cui la cassa è piena.
     */
    CASHBOX_FULL(2, "Error, machine cashbox full!"),

    /**
     * Stato in cui le capsule sono esaurite.
     */
    EMPTY_PODS(3, "Error, pods empty");

    private final int value;
    private final String message;

    /**
     * Costruttore dell'enum.
     *
     * @param value   valore numerico dello stato
     * @param message messaggio descrittivo dello stato
     */
    MachineStatus(int value, String message) {
        this.value = value;
        this.message = message;
    }

    /**
     * Restituisce il valore numerico associato allo stato.
     *
     * @return valore dello stato
     */
    public int getValue() {
        return value;
    }

    /**
     * Restituisce il messaggio descrittivo dello stato.
     *
     * @return messaggio dello stato
     */
    public String getMessage() {
        return message;
    }

    /**
     * Converte un valore numerico in un oggetto MachineStatus.
     *
     * @param value valore numerico da convertire
     * @return stato corrispondente
     * @throws IllegalArgumentException se il valore non corrisponde a nessuno stato
     */
    public static MachineStatus fromValue(int value) {
        for (MachineStatus status : values()) {
            if (status.value == value) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status value: " + value);
    }
}
