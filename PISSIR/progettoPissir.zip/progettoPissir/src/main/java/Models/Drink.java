package Models;

import java.util.List;

/**
 * Rappresenta una bevanda erogabile dalla macchina.
 * Ogni bevanda ha un identificativo, un nome, un prezzo e una ricetta composta da pod.
 */
public class Drink {

    private int id;
    private String name;
    private double price; 
    private List<Pod> recipe;

    /**
     * Costruttore con ricetta.
     *
     * @param id      identificativo della bevanda
     * @param name    nome della bevanda
     * @param price   prezzo della bevanda
     * @param recipe  lista di pod necessari per preparare la bevanda
     */
    public Drink(int id, String name, double price, List<Pod> recipe) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.setRecipe(recipe);
    }

    /**
     * Costruttore senza ricetta.
     *
     * @param id     identificativo della bevanda
     * @param name   nome della bevanda
     * @param price  prezzo della bevanda
     */
    public Drink(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    /**
     * Restituisce l'identificativo della bevanda.
     *
     * @return id della bevanda
     */
    public int getId() {
        return id;
    }

    /**
     * Imposta l'identificativo della bevanda.
     *
     * @param id nuovo id della bevanda
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Restituisce il nome della bevanda.
     *
     * @return nome della bevanda
     */
    public String getName() {
        return name;
    }

    /**
     * Imposta il nome della bevanda.
     *
     * @param name nuovo nome della bevanda
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Restituisce il prezzo della bevanda.
     *
     * @return prezzo della bevanda
     */
    public double getPrice() {
        return price;
    }

    /**
     * Imposta il prezzo della bevanda.
     *
     * @param price nuovo prezzo della bevanda
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Restituisce la lista dei pod che compongono la ricetta della bevanda.
     *
     * @return lista di oggetti {@code Pod}
     */
    public List<Pod> getRecipe() {
        return recipe;
    }

    /**
     * Imposta la lista dei pod che compongono la ricetta della bevanda.
     *
     * @param recipe lista di pod
     */
    public void setRecipe(List<Pod> recipe) {
        this.recipe = recipe;
    }
}
