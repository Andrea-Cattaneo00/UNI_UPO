package Client;

import javax.net.ssl.*;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.security.cert.Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.util.Base64;

/**
 * Classe di utilità per configurare un contesto SSL sicuro, includendo la gestione di certificati client e CA.
 */
public class SSLUtil {

    /**
     * Restituisce una {@code SSLSocketFactory} configurata per l'uso con TLS 1.3,
     * caricando i certificati e la chiave privata dal classpath.
     *
     * @return una SSLSocketFactory sicura
     * @throws Exception in caso di errore durante il caricamento o la configurazione
     */
    public static SSLSocketFactory getSecureSocketFactory() throws Exception {
        X509Certificate caCert = loadCertificate("mqtt_certs/ca/ca.crt");
        X509Certificate clientCert = loadCertificate("mqtt_certs/client/client.crt");
        PrivateKey clientKey = loadPrivateKey(
            SSLUtil.class.getClassLoader().getResourceAsStream("mqtt_certs/client/client.key"));

        TrustManager[] trustManagers = createTrustManagers(caCert);
        KeyManager[] keyManagers = createKeyManagers(clientCert, clientKey);

        SSLContext sslContext = SSLContext.getInstance("TLSv1.3");
        sslContext.init(keyManagers, trustManagers, new SecureRandom());

        return sslContext.getSocketFactory();
    }

    /**
     * Carica un certificato X.509 dal classpath.
     *
     * @param resourcePath percorso del certificato nel classpath
     * @return il certificato caricato
     * @throws Exception se il certificato non è trovato o non valido
     */
    private static X509Certificate loadCertificate(String resourcePath) throws Exception {
        try (InputStream certStream = SSLUtil.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (certStream == null) {
                throw new FileNotFoundException("Certificate not found: " + resourcePath);
            }
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            return (X509Certificate) cf.generateCertificate(certStream);
        }
    }

    /**
     * Carica una chiave privata da uno stream PEM codificato in Base64.
     *
     * @param keyStream stream contenente la chiave privata
     * @return la chiave privata
     * @throws Exception se la chiave non è leggibile o valida
     */
    private static PrivateKey loadPrivateKey(InputStream keyStream) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(keyStream, StandardCharsets.UTF_8))) {
            StringBuilder keyContent = new StringBuilder();
            String line;
            boolean inKeySection = false;

            while ((line = reader.readLine()) != null) {
                if (line.contains("BEGIN PRIVATE KEY") || line.contains("BEGIN RSA PRIVATE KEY")) {
                    inKeySection = true;
                    continue;
                }
                if (line.contains("END PRIVATE KEY") || line.contains("END RSA PRIVATE KEY")) {
                    break;
                }
                if (inKeySection) {
                    keyContent.append(line);
                }
            }

            if (keyContent.length() == 0) {
                throw new IllegalArgumentException("No private key found in the provided stream");
            }

            byte[] decodedKey = Base64.getDecoder().decode(keyContent.toString());
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");

            try {
                return keyFactory.generatePrivate(new PKCS8EncodedKeySpec(decodedKey));
            } catch (InvalidKeySpecException e) {
                RSAPrivateCrtKeySpec keySpec = decodePKCS1PrivateKey(decodedKey);
                return keyFactory.generatePrivate(keySpec);
            }
        }
    }

    /**
     * Decodifica una chiave privata in formato PKCS#1.
     *
     * @param keyBytes array di byte contenente la chiave
     * @return la specifica della chiave PKCS#1
     * @throws IOException se la decodifica fallisce
     */
    private static RSAPrivateCrtKeySpec decodePKCS1PrivateKey(byte[] keyBytes) throws IOException {
        try (ByteArrayInputStream bis = new ByteArrayInputStream(keyBytes);
             DataInputStream dis = new DataInputStream(bis)) {

            BigInteger version = readBigInteger(dis);
            if (!version.equals(BigInteger.ZERO)) {
                throw new IllegalArgumentException("Unsupported PKCS#1 version");
            }

            BigInteger modulus = readBigInteger(dis);
            BigInteger publicExp = readBigInteger(dis);
            BigInteger privateExp = readBigInteger(dis);
            BigInteger prime1 = readBigInteger(dis);
            BigInteger prime2 = readBigInteger(dis);
            BigInteger exp1 = readBigInteger(dis);
            BigInteger exp2 = readBigInteger(dis);
            BigInteger crtCoeff = readBigInteger(dis);

            return new RSAPrivateCrtKeySpec(
                modulus, publicExp, privateExp, prime1, prime2, exp1, exp2, crtCoeff);
        }
    }

    /**
     * Legge un {@code BigInteger} da un {@code DataInputStream}.
     *
     * @param dis stream di input
     * @return il numero decodificato
     * @throws IOException in caso di errore di lettura
     */
    private static BigInteger readBigInteger(DataInputStream dis) throws IOException {
        int len = dis.readInt();
        byte[] bytes = new byte[len];
        dis.readFully(bytes);
        return new BigInteger(1, bytes);
    }

    /**
     * Crea un array di {@code TrustManager} usando un certificato CA.
     *
     * @param caCert certificato della Certification Authority
     * @return array di {@code TrustManager}
     * @throws Exception se la configurazione fallisce
     */
    private static TrustManager[] createTrustManagers(X509Certificate caCert) throws Exception {
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        trustStore.load(null, null);
        trustStore.setCertificateEntry("ca", caCert);

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(
            TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trustStore);

        return tmf.getTrustManagers();
    }

    /**
     * Crea un array di {@code KeyManager} usando un certificato client e una chiave privata.
     *
     * @param clientCert certificato del client
     * @param clientKey  chiave privata del client
     * @return array di {@code KeyManager}
     * @throws Exception se la configurazione fallisce
     */
    private static KeyManager[] createKeyManagers(X509Certificate clientCert, PrivateKey clientKey)
            throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null, null);
        keyStore.setCertificateEntry("client-cert", clientCert);
        keyStore.setKeyEntry("client-key", clientKey, "".toCharArray(),
                new Certificate[]{clientCert});

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(
            KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keyStore, "".toCharArray());

        return kmf.getKeyManagers();
    }

    /**
     * Versione alternativa del metodo per ottenere una {@code SSLSocketFactory},
     * utilizzando percorsi assoluti per CA, certificato client e chiave privata.
     *
     * @param caCertPath      percorso del certificato CA
     * @param clientCertPath  percorso del certificato del client
     * @param clientKeyPath   percorso della chiave privata del client
     * @return una {@code SSLSocketFactory} configurata (attualmente null per completamento futuro)
     * @throws Exception in caso di errore durante il caricamento dei file
     */
    public static SSLSocketFactory getSecureSocketFactory(String caCertPath,
                                                          String clientCertPath,
                                                          String clientKeyPath) throws Exception {
        X509Certificate caCert = loadCertificateFromFile(caCertPath);
        X509Certificate clientCert = loadCertificateFromFile(clientCertPath);
        PrivateKey clientKey = loadPrivateKey(new FileInputStream(clientKeyPath));
        return null; // da completare
    }

    /**
     * Carica un certificato da file.
     *
     * @param filePath percorso assoluto del file del certificato
     * @return il certificato caricato
     * @throws Exception se il file non è valido o non leggibile
     */
    private static X509Certificate loadCertificateFromFile(String filePath) throws Exception {
        try (InputStream is = new FileInputStream(filePath)) {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            return (X509Certificate) cf.generateCertificate(is);
        }
    }
}
