package Client;

import DB.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe di utilità per operazioni sul database relative alle macchine.
 */
public class MachineDB {

    /**
     * Recupera gli ID di tutte le macchine attive (status = '1') dal database.
     *
     * @return lista di stringhe con i nomi delle macchine attive, nel formato "macchina_{id}"
     */
    public static List<String> getAllMachineIds() {
        List<String> machineIds = new ArrayList<>();
        try (Connection conn = DBConnection.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id FROM Machines WHERE status = '1'")) {
            
            while (rs.next()) {
                machineIds.add("macchina_" + rs.getInt("id"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching machine IDs: " + e.getMessage());
        }
        return machineIds;
    }
}
