package Client;

import java.io.*;
import java.security.*;
import java.security.spec.*;
import java.util.Base64;

/**
 * Classe di utilità per il parsing di file PEM contenenti chiavi private in formato PKCS#8.
 */
public class PEMParser {

    /**
     * Carica una chiave privata da un file PEM codificato in Base64.
     *
     * @param file il file contenente la chiave privata in formato PEM
     * @return la chiave privata come oggetto {@code PrivateKey}
     * @throws Exception se la chiave non può essere letta o convertita
     */
    public static PrivateKey loadPrivateKey(File file) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        StringBuilder key = new StringBuilder();
        boolean inKey = false;

        while ((line = br.readLine()) != null) {
            if (line.contains("BEGIN PRIVATE KEY")) {
                inKey = true;
            } else if (line.contains("END PRIVATE KEY")) {
                break;
            } else if (inKey) {
                key.append(line);
            }
        }
        br.close();

        byte[] keyBytes = Base64.getDecoder().decode(key.toString());
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(spec);
    }
}
