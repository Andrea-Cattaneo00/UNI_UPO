package Client;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 * Classe per la gestione di un client MQTT con supporto a connessione, 
 * pubblicazione e sottoscrizione, incluso l'uso di certificati SSL.
 */
public class MQTTClient {
    private MqttClient client;
    private MqttConnectOptions options;

    /**
     * Costruttore base per il client MQTT.
     *
     * @param brokerUrl       URL del broker MQTT
     * @param clientId        Identificatore univoco del client
     * @param clientCertPath  Percorso del certificato del client (PKCS12)
     * @param clientKeyPath   Percorso della chiave privata del client
     */
    public MQTTClient(String brokerUrl, String clientId, String clientCertPath, String clientKeyPath) {
        this(brokerUrl, clientId, clientCertPath, clientKeyPath, new MemoryPersistence());
    }

    /**
     * Costruttore avanzato con specifica della persistenza.
     *
     * @param brokerUrl       URL del broker MQTT
     * @param clientId        Identificatore univoco del client
     * @param clientCertPath  Percorso del certificato del client (PKCS12)
     * @param clientKeyPath   Percorso della chiave privata del client
     * @param persistence     Meccanismo di persistenza del client MQTT
     */
    public MQTTClient(String brokerUrl, String clientId, String clientCertPath, String clientKeyPath, MqttClientPersistence persistence) {
        try {
            client = new MqttClient(brokerUrl, clientId, persistence);
            options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setAutomaticReconnect(true);
            options.setConnectionTimeout(10);
            options.setKeepAliveInterval(60);
            options.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1_1);

            // Configure SSL with client certificate
            System.setProperty("javax.net.ssl.keyStore", clientCertPath);
            System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
            System.setProperty("javax.net.ssl.keyStoreType", "PKCS12");

            // Configure truststore with CA certificate
            System.setProperty("javax.net.ssl.trustStore", "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/mosquitto-truststore.jks");
            System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Connette il client al broker MQTT utilizzando le opzioni definite.
     */
    public void connect() {
        try {
            System.out.println("Using truststore: " + System.getProperty("javax.net.ssl.trustStore"));
            System.out.println("Connecting to MQTT broker...");
            client.connect(options);
            System.out.println("Connected!");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Disconnette il client dal broker MQTT.
     */
    public void disconnect() {
        try {
            client.disconnect();
            System.out.println("Disconnected.");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Pubblica un messaggio di tipo stringa su un topic specifico.
     *
     * @param topic   Topic su cui pubblicare
     * @param message Messaggio testuale da pubblicare
     */
    public void publish(String topic, String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            client.publish(topic, mqttMessage);
            System.out.println("Published message to topic " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Pubblica un messaggio binario su un topic specifico.
     *
     * @param topic   Topic su cui pubblicare
     * @param payload Messaggio in formato byte array
     */
    public void publish(String topic, byte[] payload) {
        try {
            MqttMessage mqttMessage = new MqttMessage(payload);
            client.publish(topic, mqttMessage);
            System.out.println("Published byte[] message to topic " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sottoscrive il client a un topic MQTT con un listener.
     *
     * @param topic    Topic a cui sottoscriversi
     * @param listener Listener per la gestione dei messaggi ricevuti
     */
    public void subscribe(String topic, IMqttMessageListener listener) {
        try {
            client.subscribe(topic, listener);
            System.out.println("Subscribed to topic " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
