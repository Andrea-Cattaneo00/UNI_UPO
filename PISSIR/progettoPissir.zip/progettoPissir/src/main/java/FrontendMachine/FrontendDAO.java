package FrontendMachine;

import java.util.ArrayList;
import java.util.List;

import DB.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Models.Drink;
import Models.Machine;
import Models.MachineStatus;

/**
 * Classe DAO per l'accesso alle informazioni delle macchine frontend e dei prodotti erogabili.
 */
public class FrontendDAO {

    /**
     * Recupera la lista di tutte le bevande disponibili nel sistema.     
     * @return lista di oggetti {@code Drink} rappresentanti i prodotti con prezzo maggiore di 0
     */
    public static List<Drink> getAllDrinks() {
        final String query = "SELECT * FROM Pods WHERE price != 0.0";
        List<Drink> products = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query);
             ResultSet rs = st.executeQuery()) {

            while (rs.next()) {
                Drink drink = new Drink(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price")
                );
                products.add(drink);
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return products;
    }

    /**
     * Recupera le specifiche della macchina (ID, cassetto contanti, stato) a partire dal suo ID.
     *
     * @param machineID ID della macchina
     * @return oggetto {@code Machine} con le informazioni, oppure {@code null} se non trovata
     */
    public static Machine getSpecsMachine(int machineID) {
        final String query = "SELECT * FROM Machines WHERE id = ?";
        Machine machineInfos = null;

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            st.setInt(1, machineID);
            try (ResultSet rs = st.executeQuery()) {

                if (rs.next()) {
                    MachineStatus currentStatus = MachineStatus.fromValue(rs.getInt("status"));

                    machineInfos = new Machine(
                        machineID,
                        rs.getDouble("cashBox"),
                        currentStatus
                    );

                    return machineInfos;
                } else {
                    System.out.println("We are sorry, we encountered an error with your machineID: " + machineID);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return machineInfos;
    }
}
