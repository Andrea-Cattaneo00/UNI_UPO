package FrontendMachine;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import Client.MQTTClient;
import Models.Drink;
import Models.Machine;
import Models.MachineStatus;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

/**
 * Classe principale che simula il comportamento di una macchinetta automatica frontend.
 * Gestisce:
 * - l'interazione con l'utente via console
 * - la comunicazione MQTT con il backend
 * - il flusso completo dell'acquisto di una bevanda
 */

public class FrontendMachine {

    // Variabili condivise tra i metodi
	private static MQTTClient mqttClient;
	public static int machineID;
	private volatile static boolean isMachineActive = true;

    // Stato attuale della macchina e dati relativi all'ordine
	private final static Object key = new Object();

	static Scanner scanner = new Scanner(System.in);
	// Variabili globali per le azioni
	private static MachineStatus currentStatus = null; 
	private static List<Drink> availableDrinks = new ArrayList<>();
	private static boolean isProdAvailable = false;
	private static double prodPrice = 0.0;
	private static Machine machineInfos = null;
	private static boolean isUpdateSuccessfull = false;
	private static final Random rnd = new Random();
	private static final double PROB_BREAK = 0.1; //10%

	
	/**
     * Punto d'ingresso dell'applicazione.
     * Chiede all'utente l'ID della macchina, avvia MQTT e il ciclo principale.
     */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	    System.out.print("Inserisci l'ID della macchina: ");
	    machineID = scanner.nextInt();
	    scanner.nextLine();
		setUpMQTT();
		start();
	}

	 /**
     * Configura e avvia la connessione MQTT, sottoscrivendosi ai topic rilevanti.
     */
	private static void setUpMQTT() {
		String serverURL = "ssl://localhost:8883";
		int machineID = FrontendMachine.machineID;
		String clientID = "FrontendMachine" + machineID;
		System.out.println("FrontendMachine online");
		System.out.println("Client ID in uso: " + clientID);
		
		String clientCertPath = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.p12";
	    String clientKeyPath = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.key";
	    
	    mqttClient = new MQTTClient(serverURL, clientID, clientCertPath, clientKeyPath, new MemoryPersistence());
		mqttClient.connect();
		
	
		// Aggiorna lo status della macchinetta all'interno del DB 
		mqttClient.subscribe("/update/status/" + machineID + "/response", (topic, msg) -> {
            synchronized (key) {
                boolean ok = (msg.getPayload()[0] == 1);
                if (!ok) {
                    System.err.println("Errore during status update");
                }
                mqttClient.publish("/get/machine_infos/" + machineID + "/request", new byte[0]);
                threadNotify(key);
            }
        });

		// Ottiene la lista di tutti i prodotti di norma erogabili (anche quelli che al momento non sono disponibili)
		mqttClient.subscribe("/drinks/list/" + machineID + "/response", (topic, msg) -> {
		    synchronized (key) {
		        try {
		            String jsonDrinks = new String(msg.getPayload(), StandardCharsets.UTF_8);
		            
		            availableDrinks = drinkGson(jsonDrinks);
		            
		            threadNotify(key);
		        } catch (Exception e) {
		            System.err.println("Error processing drinks list: " + e.getMessage());
		            availableDrinks = new ArrayList<>();
		            threadNotify(key);
		        }
		    }
		});

		// Controlla che la macchinetta abbia le pod necessarie per il prodotto scelto
		mqttClient.subscribe("/check/availability/" + machineID + "/response", (topic, msg) -> {
			synchronized (key) {
				isProdAvailable = (msg.getPayload()[0] == 1);
				threadNotify(key);
			}
		});

		// Recupero le varie info della macchinetta (status, cashBox, id_institute)
		mqttClient.subscribe("/get/machine_infos/" + machineID + "/response", (topic, msg) -> {
		    synchronized (key) {
		        try {
		            String jsonMachine = new String(msg.getPayload(), StandardCharsets.UTF_8);
		            
		            Gson gson = new Gson();
					machineInfos = gson.fromJson(jsonMachine, Machine.class);
		            
		            if (machineInfos != null) {
		                currentStatus = machineInfos.getStatus();
		            } else {
		                currentStatus = MachineStatus.BROKEN;
		            }
		            threadNotify(key);
		        } catch (Exception e) {
		            System.err.println("Error deserializing machine info: " + e.getMessage());
		            currentStatus = MachineStatus.BROKEN;
		            threadNotify(key);
		        }
		    }
		});

		// Recupero i dati dell'ordine dell'utente
		mqttClient.subscribe("/get/prod_price/" + machineID + "/response", (topic, msg) -> {
			synchronized (key) {
				prodPrice = ByteBuffer.wrap(msg.getPayload()).getDouble();
				threadNotify(key);
			}
		});

		// Invia il credito dell'utente alla cashBox della macchinetta
		mqttClient.subscribe("/cashbox/update/" + machineID + "/response", (topic, msg) -> {
			synchronized (key) {
				isUpdateSuccessfull = (msg.getPayload()[0] == 1);
				if (!isUpdateSuccessfull) System.out.println("Error during the cashbox update, we are sorry, retry...");
			}
		});
		
		// Eroga il resto all'utente (se necessario)
		mqttClient.subscribe("/give/change/" + machineID + "/response", (topic, msg) -> {
			synchronized (key) {
				isUpdateSuccessfull = (msg.getPayload()[0] == 1);
				if (isUpdateSuccessfull) System.out.printf("You can withdraw  the change of %.2f € \n", userChange);
				else System.out.println("Error during the cashbox update for the change, we are sorry, retry...");
			}
		});
		
		// Aggiorna la quantità delle pod nel DB appena utilizzate 
		mqttClient.subscribe("/update/pods/" + machineID + "/response", (topic, msg) -> {
			synchronized(key) {
				isUpdateSuccessfull = (msg.getPayload()[0] == 1);
				if(isUpdateSuccessfull) System.out.println("Pod inventory update has been successfull!");
				else System.out.println("Error during the pod inventory update, we are sorry, do the purchase again, we are giving you back the money");
			}
		});
		

		// Ottiene le informazioni della macchinetta (id, status, cashbox, id_institute)
		mqttClient.publish("/get/machine_infos/" + machineID + "/request", new byte[0]);
	    threadWait(key);
	    
	    if (machineInfos != null) {
	        currentStatus = machineInfos.getStatus();
	        isMachineActive = (currentStatus == MachineStatus.WORKING);
	        System.out.println("Initial machine status: " + currentStatus);
	    }
	}

	// Controlla lo stato della macchinetta e imposta un boolean che permette di rimanere in while true così da poter vedere 
	// in diretta il cambiamento dello stato a working da parte del management 
	private static boolean checkMachineStatus() {
		if(currentStatus == null) {
			System.out.println("Waiting for machine status...");
			return false;
		}
		System.out.println("Current machine status: " + currentStatus);
		if (!isMachineActive) {
			System.out.println("⚠️ Machine Status : " + currentStatus.getMessage());
			return false;
		} else {
			return true;
		}
	}

	// Variabile globale usata per salvare l'azione dell'utente 
	static int userAction = 0;

	/**
     * Avvia il ciclo principale per l'interazione utente.
     */
	private static void start() {
	    userAction = 0;
	    int retryCount = 0;
	    final int MAX_RETRIES = 3;

	    while (true) {
	        if (currentStatus == null && retryCount < MAX_RETRIES) {
	            System.out.println("Requesting machine info (attempt " + (retryCount+1) + ")");
	            mqttClient.publish("/get/machine_infos/" + machineID + "/request", new byte[0]);
	            threadWait(key);
	            retryCount++;
	            
	        } else if (currentStatus == null) {
	            System.out.println("Failed to get machine info after " + MAX_RETRIES + " attempts. Using default BROKEN status.");
	            
	        }
			
			threadWait(key);
		
			
			if (!checkMachineStatus()) {
				try {
			        Thread.sleep(3000); 
			    } catch (InterruptedException e) {
			        e.printStackTrace();
			    }
				continue;
			}

			switch (userAction) {
				case 0:
					System.out.println("1- Choose the beverage: ");
					try {
						userAction = scanner.nextInt();
						scanner.nextLine();
					} catch (InputMismatchException e) {
						System.out.println("Invalid input");
						scanner.nextLine();
						userAction = 0;
					}
					break;
				case 1:
					showDrinks();
					getUserChoice();
					break;
				case 2:
					checkCashboxStatus();
					break;
				default:
					System.out.println("Invalid choice, try again");
					userAction = 0;
					break;
			}
		}
	}

	/**
     * Mostra tutte le bevande vendute dalla macchina, senza controllarne la disponibilità.
     */
	private static void showDrinks() {
		try {
			String machineIDstr = String.valueOf(machineID);
			byte[] byteIDMachine = machineIDstr.getBytes(StandardCharsets.UTF_8);
			mqttClient.publish("/drinks/list/" + machineID + "/request", byteIDMachine);
			threadWait(key);

			if (availableDrinks.isEmpty()) {
				System.out.println("We are sorry, there are no drinks available");
				return;
			}

			System.out.println("Here all the drinks: ");
			for (Drink drink : availableDrinks) {
				System.out.println(drink.getId() + ") " + drink.getName() + " - €" + drink.getPrice());
			}
		} catch (InputMismatchException e) {
			System.out.println("Invalid Input, please enter a number");
			scanner.nextLine();
		}
	}

	// Variabile globale usata per salvare il prodotto scelto dall'utente 
	static int choosenProd;

	/**
     * Chiede all'utente di scegliere una bevanda e verifica se è disponibile.
     */
	private static void getUserChoice() {
		System.out.println("Choose the drink or press 0 to go back");
		choosenProd = scanner.nextInt();
		scanner.nextLine();

		if (choosenProd == 0)
			return;

		byte[] byteChoosenProd = ByteBuffer.allocate(4).putInt(choosenProd).array();
		mqttClient.publish("/check/availability/" + machineID + "/request", byteChoosenProd);
		threadWait(key);

		if (isProdAvailable) {
			System.out.println("Product available! Proceed to payment...");
			userAction = 2;
		} else {
			System.out.println("We are sorry, the product is not available.");
			getUserChoice();
		}
	}

	/**
     * Controlla che la cassa non abbia superato il valore massimo impostato dalla macchina (come costante).
     */
	private static void checkCashboxStatus() {
		
		mqttClient.publish("/get/machine_infos/" + machineID + "/request", new byte[0]);
		threadWait(key);

		if (machineInfos.getCashBox() < Machine.getMaxCashBox()) { 	// Controllo pressocchè inutile ma non fa male
			checkTransitionPossibility();
		} else {
			System.out.println("We are sorry, the cashbox is full, we can carry out your order...");
			System.out.println("Try with a cheaper product or even don't try again");

			updateStatus(1);
			userAction = 0;
		}
	}

	/**
     * Verifica se è possibile completare la transazione senza superare il valore massimo della cassa.
     */
	private static void checkTransitionPossibility() {
		byte[] byteChoosenProd = ByteBuffer.allocate(4).putInt(choosenProd).array();
		mqttClient.publish("/get/prod_price/" + machineID + "/request", byteChoosenProd);
		threadWait(key);
		
		if (machineInfos.getCashBox() + prodPrice >= Machine.getMaxCashBox()) {
			requestMoney();
			currentBalance = 0;
			updateStatus(1);
		} else if (machineInfos.getCashBox() + prodPrice < Machine.getMaxCashBox()) {
			requestMoney();
			currentBalance = 0;
		} else {
			System.out.println("Error, our cashbox is full. We are sorry we can't execute the transaction");
			userAction = 0;
		}
	}

	// Variabili globali usate per salvare il saldo attuale dell'utente e il resto che la macchinetta dovrà erogare
	static double currentBalance = 0.0;
	static double userChange = 0.0;
	
	/**
     * Gestisce l'inserimento del credito da parte dell'utente e verifica la possibilità di completare il pagamento.
     */
	private static void requestMoney() {
	    double moneyLeft = prodPrice;
	    System.out.println("Insert credit: €" + String.format("%.2f", prodPrice) + ":");
	    System.out.println("(If you want to cancel and get all your credit back, press 'C')");

	    while (currentBalance < prodPrice) {
	        System.out.print(">>> ");
	        String input = scanner.nextLine().trim();

	        // Se l'utente preme 'C' (o 'c'), annullo subito e restituisco il credito
	        if (input.equalsIgnoreCase("C")) {
	            if (currentBalance > 0) {
	                System.out.printf("⛔ Transaction cancelled: I'll refund you €%.2f\n", currentBalance);
	                currentBalance = 0.0;
	            } else {
	                System.out.println("⛔ No credit entered to return.");
	            }
	            userAction = 0;   // torno al menu principale
	            return;         
	        }

	        double temp;
	        try {
	            temp = Double.parseDouble(input);
	        } catch (NumberFormatException e) {
	            System.out.println("⚠️ Invalid input! Enter a number (e.g. 0.50) or 'C' to cancel.");
	            continue;
	        }

	        // Se l'utente digita 0 come numero, lo consideriamo come "ritorna al menu" (stessa logica del 'C')
	        if (temp == 0.0) {
	            System.out.println("⛔ Transaction cancelled: No credit entered will be taken.");
	            userAction = 0;
	            return;
	        }

	        currentBalance += temp;

	        if (currentBalance >= prodPrice) {
	            userChange = currentBalance - prodPrice;

	            // Verifico se posso dare il resto dalla cassa
	            if (machineInfos.getCashBox() < userChange) {
	                System.out.println("⚠️ Unable to provide change: insufficient cash. Transaction cancelled.");
	                System.out.printf("€%.2f will be returned to you.\n", currentBalance);
	                currentBalance = 0.0;
	                userAction = 0;
	                return;
	            }

	            // Invio il resto al modulo MoneyManager (MQTT /give/change)
	            byte[] userChangeByte = ByteBuffer.allocate(Double.BYTES).putDouble(userChange).array();
	            mqttClient.publish("/give/change/" + machineID + "/request", userChangeByte);
	            // Attendo risposta su isUpdateSuccessfull (imposta userChange o segnala errore)
	            threadWait(key);

	            break; 
	        }

	        // Altrimenti informo quanto manca ancora
	        moneyLeft = prodPrice - currentBalance;
	        System.out.printf("Current credit: €%.2f | Missing: €%.2f\n", currentBalance, moneyLeft);
	    }

	    // Accreditiamo definitivamente il credito nella cassa
	    byte[] userCreditByte = ByteBuffer.allocate(Double.BYTES).putDouble(currentBalance).array();
	    mqttClient.publish("/cashbox/update/" + machineID + "/request", userCreditByte);
	    threadWait(key);

	    if (!isUpdateSuccessfull) {
	        // Se l'accredito non va a buon fine, riprovo o informo l'utente
	        System.out.println("⚠️ Error saving your credit at checkout...");
	        if (currentBalance == prodPrice) {
	            System.out.println("We will retry the crediting operation for your amount...");
	            mqttClient.publish("/cashbox/update/" + machineID + "/request", userCreditByte);
	            threadWait(key);
	        } else {
	            System.out.println("Sorry, we couldn't save your credit. Please try again.");
	            requestMoney(); // riparte la logica da zero
	            return;
	        }
	    }

	    updatePodsInDB();
	}
	
	/**
     * Aggiorna lo stato della macchina in caso di cassa piena o capsule terminate.
     * @param err codice dell'errore (1 = cassa piena, 2 = pod terminati)
     */
	private static void updateStatus(int err) {
		int newStatus = 0;
		
		if(err == 1) {						// Cashbox full 
			newStatus = 2;
		} else if (err == 2) {				// Empty pods
			newStatus = 3;
		}
		byte[] newStatusByte = ByteBuffer.allocate(Integer.BYTES).putInt(newStatus).array();
		String t = "/update/status/" + machineID + "/request";
		mqttClient.publish("/update/status/" + machineID + "/request", newStatusByte);
		threadWait(key);
	}

	/**
     * Aggiorna il numero di pod disponibili nel database.
     */
	private static void updatePodsInDB() {
		
		byte[] byteChoosenProd = ByteBuffer.allocate(4).putInt(choosenProd).array();
		mqttClient.publish("/update/pods/" + machineID + "/request", byteChoosenProd);
		threadWait(key);
		
		if(!isUpdateSuccessfull) System.out.println("Error during the pod update in the DB ....");
		else {
			updateStatus(2);
			try {
				deliverProd();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}
	
	/**
     * Esegue un'animazione testuale che simula l'erogazione della bevanda.
     * Può anche generare un guasto casuale.
     */
	private static void deliverProd() throws InterruptedException {
		int high = 10;
		char emptyGlass = ' ';
        char liquid = '█';
        int width = 10;

        // Array che rappresenta il bicchiere
        char[][] bicchiere = new char[high][width];

        // Inizializza il bicchiere vuoto
        for (int i = 0; i < high; i++) {
            for (int j = 0; j < width; j++) {
                bicchiere[i][j] = emptyGlass;
            }
        }

        // Riempimento progressivo dal basso verso l'alto
        for (int livello = high - 1; livello >= 0; livello--) {
            for (int j = 0; j < width; j++) {
                bicchiere[livello][j] = liquid;
            }

            // Pulisce lo schermo 
            System.out.print("\033[H\033[2J");
            System.out.flush();

            // Stampa il bicchiere attuale
            for (int i = 0; i < high; i++) {
                System.out.print("|");
                for (int j = 0; j < width; j++) {
                    System.out.print(bicchiere[i][j]);
                }
                System.out.println("|");
            }
            System.out.println("‾‾‾‾‾‾‾‾‾‾‾");

            // Attendi prima di riempire il prossimo livello
            synchronized (key) {            	
            	key.wait(500);
            }
        }
        System.out.println("You can take the product! ");
        System.out.println("Press 0 to return to the menu");
        int choice = scanner.nextInt();
        if(choice == 0) userAction = 0;
        
        
        //controllo probabilità di guasto
        double casuale = rnd.nextDouble();
        if (casuale < PROB_BREAK) {
            // simulo guasto: mando subito BROKEN (0)
            int brokenStatus = MachineStatus.BROKEN.getValue(); // che dovrebbe valere 0
            byte[] statusPayload = ByteBuffer.allocate(Integer.BYTES).putInt(brokenStatus).array();
            mqttClient.publish("/update/status/" + machineID + "/request", statusPayload);
            
            // aggiorno internamente lo stato
            currentStatus = MachineStatus.BROKEN;
            isMachineActive = false;
            
            System.out.println("⚠️ Oh no, machine is broken!");
        }
	}
	
	/**
     * Risveglia un oggetto sincronizzato per proseguire l'esecuzione del thread.
     * @param obj oggetto da notificare
     */
	private static void threadNotify(Object obj) {
		synchronized (obj) {
			obj.notify();
		}
	}

	/**
     * Mette in attesa un oggetto sincronizzato per un massimo di 5 secondi.
     * @param obj oggetto da mettere in attesa
     */
	private static void threadWait(Object obj) {
		synchronized (obj) {
			try {
				obj.wait(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
     * Converte una stringa JSON contenente una lista di bevande in una lista di oggetti {@link Drink}.
     * @param jsonDrinks stringa JSON delle bevande
     * @return lista di oggetti Drink
     */
	private static List<Drink> drinkGson(String jsonDrinks) {
		List<Drink> drinks = new ArrayList<>();
		try {
			Gson gson = new Gson();
			Type drinkType = new TypeToken<ArrayList<Drink>>() {
			}.getType();
			drinks = gson.fromJson(jsonDrinks, drinkType);
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
		}
		return drinks;
	}
}
