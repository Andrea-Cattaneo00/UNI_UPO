package Money;

import java.nio.ByteBuffer;
import com.google.gson.Gson;
import Client.MQTTClient;

/**
 * Questa classe gestisce le operazioni legate al denaro per le macchinette distributrici.
 * In particolare, si occupa di:
 * 
 *   Accreditare il credito inserito dall'utente nella cashbox della macchina
 *   Restituire il resto all'utente dopo un acquisto
 * 
 * La comunicazione avviene tramite protocollo MQTT.
 */
public class MoneyManager {

    private static MQTTClient mqttClient;
    private static final Gson gson = new Gson();

    /**
     * Metodo principale che avvia la configurazione del client MQTT per la gestione monetaria.
     *
     * @param args argomenti da linea di comando
     */
    public static void main(String[] args) {
        setUpMQTT();
    }

    /**
     * Configura e avvia il client MQTT, sottoscrivendo i topic relativi a:
     * 
     *   Aggiornamento della cassa dopo inserimento di credito
     *   Gestione dell'erogazione del resto
     * 
     */
    private static void setUpMQTT() {
        String serverURL     = "ssl://localhost:8883";
        String clientID      = "MoneyManager";
        String clientCert    = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.p12";
        String clientKey     = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.key";

        System.out.println("MoneyManager online");
        System.out.println("Client ID in use: " + clientID);

        mqttClient = new MQTTClient(serverURL, clientID, clientCert, clientKey);
        mqttClient.connect();

        // *** ACCREDITO DEL CREDITO INSERITO ***
        mqttClient.subscribe("/cashbox/update/+/request", (topic, msg) -> {
            // topic = "/cashbox/update/{machineID}/request"
            String[] parts = topic.split("/");
            int machineID = Integer.parseInt(parts[3]);
            double userCredit = ByteBuffer.wrap(msg.getPayload()).getDouble();

            boolean ok = MoneyDAO.updateCashbox(machineID, userCredit);
            System.out.println(ok
                ? "Cashbox update successful for machine " + machineID
                : "Error updating cashbox for machine " + machineID);

            byte[] resp = new byte[]{ (byte)(ok ? 1 : 0) };
            mqttClient.publish("/cashbox/update/" + machineID + "/response", resp);
        });

        // *** EROGAZIONE DEL RESTO ***
        mqttClient.subscribe("/give/change/+/request", (topic, msg) -> {
            // topic = "/give/change/{machineID}/request"
            String[] parts = topic.split("/");
            int machineID = Integer.parseInt(parts[3]);
            double change = ByteBuffer.wrap(msg.getPayload()).getDouble();

            boolean ok = MoneyDAO.giveChange(machineID, change);
            System.out.println(ok
                ? "Change given for machine " + machineID
                : "Error giving change for machine " + machineID);

            byte[] resp = new byte[]{ (byte)(ok ? 1 : 0) };
            mqttClient.publish("/give/change/" + machineID + "/response", resp);
        });
    }
}
