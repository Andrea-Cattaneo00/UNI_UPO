package Money;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DB.DBConnection;

/**
 * Classe di accesso ai dati (DAO) per la gestione della cassa delle macchinette.
 */
public class MoneyDAO {
    
    /**
     * Restituisce l'importo attuale presente nella cassa della macchinetta specificata.
     *
     * @param machineID l'ID della macchinetta
     * @return l'importo attuale della cassa, oppure 0.0 in caso di errore
     */
    public static double getCurrentCashboxAmount(int machineID) {
        final String query = "SELECT * FROM Machines WHERE id = ?";
        double cashbox = 0.0;
        
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {
            
            st.setInt(1, machineID);
            ResultSet rs = st.executeQuery();
            
            if (rs.next()) {
                cashbox = rs.getDouble("cashBox");    
            } else {
                System.out.println("Error during the check query for the current cashbox amount");
                return 0.0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cashbox;
    }
    
    /**
     * Aggiorna la cassa della macchinetta aggiungendo il credito inserito dall'utente.
     *
     * @param machineID  l'ID della macchinetta
     * @param userCredit il credito da aggiungere alla cassa
     * @return true se l'aggiornamento ha avuto successo, false altrimenti
     */
    public static boolean updateCashbox(int machineID, double userCredit) {
        final String query = "UPDATE Machines SET cashBox = cashBox + ? WHERE id = ?";
        
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {
            
            st.setDouble(1, userCredit);
            st.setInt(2, machineID);
            
            int rowsUpdated = st.executeUpdate();
            return rowsUpdated > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Rimuove dalla cassa l'importo da restituire come resto all'utente.
     *
     * @param machineID  l'ID della macchinetta
     * @param userChange l'importo del resto da sottrarre dalla cassa
     * @return true se l'aggiornamento ha avuto successo, false altrimenti
     */
    public static boolean giveChange(int machineID, double userChange) {
        final String query = "UPDATE Machines SET cashBox = cashBox - ? WHERE id = ?";
        
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {
            
            st.setDouble(1, userChange);
            st.setInt(2, machineID);
            
            int rowsUpdated = st.executeUpdate();
            return rowsUpdated > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;        
        }
    }
}
