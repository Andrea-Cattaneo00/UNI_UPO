package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe singleton per la gestione della connessione al database SQLite.
 */
public class DBConnection {

    private static final String DBPath = "jdbc:sqlite:src/main/resources/Storage.db";
    static private DBConnection instance = null;

    /**
     * Costruttore privato per evitare istanze multiple.
     */
    private DBConnection () {
        instance = this;
    }

    /**
     * Restituisce l'istanza singleton della connessione al database.
     *
     * @return istanza unica di {@code DBConnection}
     */
    public static DBConnection getInstance() {
        if (instance == null) {
            return new DBConnection();
        } else {
            return instance;
        }
    }

    /**
     * Ottiene una connessione al database SQLite.
     *
     * @return oggetto {@code Connection} connesso al database
     * @throws SQLException se la connessione fallisce
     */
    public Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(DBPath);
        } catch (SQLException e) {
            throw new SQLException("Cannot get connection to the DB: " + DBPath, e);
        }
    }

    /**
     * Metodo di utilità per testare la connessione al database.
     * Stampa un messaggio in console in caso di successo o fallimento.
     */
    public static void testConnection() {
        try (Connection conn = getInstance().getConnection()) {
            System.out.println("Database connection successful!");
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}
