package Assistance;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import com.google.gson.Gson;

import admin.DAO.MachineDAO;
import admin.Model.Machine;
import admin.Model.MachineStatus;
import admin.Utils.MQTTClient;

import static spark.Spark.*;

import FrontendMachine.FrontendMachine;
import Dispenser.DispenserDAO;
import Assistance.AssistanceDAO;

/**
 * Classe principale del modulo Assistance. 
 * Si occupa di ricevere richieste MQTT e interagire con il database 
 * per aggiornare lo stato delle macchine e la disponibilità dei pod.
 */
public class Assistance {
    private static Gson gson = new Gson();
    private static MQTTClient mqttClient;

    /**
     * Metodo di avvio dell'applicazione. Inizializza il client MQTT.
     *
     * @param args argomenti da linea di comando 
     */
    public static void main(String[] args) {
        setUpMQTT();
    }

    /**
     * Configura e avvia il client MQTT. Sottoscrive ai topic rilevanti e definisce le callback
     * per la gestione degli aggiornamenti delle macchine e dei pod.
     */
    private static void setUpMQTT() {
        String serverURL = "ssl://localhost:8883";
        String clientID = "Assistance-" + java.util.UUID.randomUUID();
        System.out.println("Assistance online");
        System.out.println("Client ID in use: " + clientID);

        String clientCertPath = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.p12";
        String clientKeyPath  = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.key";

        mqttClient = new MQTTClient(serverURL, clientID, clientCertPath, clientKeyPath);
        mqttClient.connect();
        
        mqttClient.subscribe("#", (topic, msg) -> {
            System.out.println("ASSISTANCE DEBUG MQTT (catch-all) topic: " + topic);
        });

        // 1) Gestione aggiornamento pod per ogni /update/pods/{X}/request
        mqttClient.subscribe("/update/pods/+/request", (topic, msg) -> {
            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);

            byte[] userChoiceByte = msg.getPayload();
            int userChoice = ByteBuffer.wrap(userChoiceByte).getInt();

            ArrayList<Integer> pods = DispenserDAO.getNecessaryPods(userChoice, requestedMachineID);
            byte[] byteRes = new byte[1];
            byteRes[0] = 1; // assume success

            for (Integer pod : pods) {
                boolean res = AssistanceDAO.updatePodsInDB(pod, requestedMachineID);
                if (!res) {
                    System.out.println("Error during the pod update in the DB, retrying....");
                    AssistanceDAO.updatePodsInDB(pod, requestedMachineID);
                    byteRes[0] = 0;
                }
            }

            mqttClient.publish("/update/pods/" + requestedMachineID + "/response", byteRes);
        });

        // 2) Gestione aggiornamento status per ogni /update/status/{X}/request
        mqttClient.subscribe("/update/status/+/request", (topic, msg) -> {
            System.out.println("Processing status update request...");

            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);

            byte[] newStatusByte = msg.getPayload();
            int newStatus = ByteBuffer.wrap(newStatusByte).getInt();

            boolean result = AssistanceDAO.updateStatus(newStatus, requestedMachineID);
            byte[] byteRes = new byte[1];
            if (result) {
                System.out.println("Status update successful for machine " + requestedMachineID);
                byteRes[0] = 1;
            } else {
                System.out.println("Error during the status update for machine " + requestedMachineID);
                byteRes[0] = 0;
            }

            System.out.println("Status update result: " + result);
            mqttClient.publish("/update/status/" + requestedMachineID + "/response", byteRes);
        });

        // 3) Verifica della situazione pod per ogni /status/pod/{X}/request
        mqttClient.subscribe("/status/pod/+/request", (topic, msg) -> {
            String[] parts = topic.split("/");
            int requestedMachineID = Integer.parseInt(parts[3]);

            boolean result = AssistanceDAO.checkPodSituation(requestedMachineID);
            byte[] byteRes = new byte[1];
            if (result) {
                System.out.println("Pod not enough for machine " + requestedMachineID + ", status updated!");
                byteRes[0] = 1;
            } else {
                System.out.println("No changes for machine " + requestedMachineID);
                byteRes[0] = 0;
            }
            mqttClient.publish("/status/pod/" + requestedMachineID + "/response", byteRes);
        });
    }
}
