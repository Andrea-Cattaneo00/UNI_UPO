package Assistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DB.DBConnection;

/**
 * Classe DAO per la gestione delle operazioni sul database relative all'assistenza,
 * come l'aggiornamento dei pod, dello stato delle macchine e la verifica della disponibilità pod.
 */
public class AssistanceDAO {

    /**
     * Decrementa di 1 la quantità di una capsula associata a una macchina specifica.
     *
     * @param podId     ID della capsula
     * @param machineID ID della macchina
     * @return {@code true} se l'aggiornamento è riuscito, altrimenti {@code false}
     */
    public static boolean updatePodsInDB(int podId, int machineID) {
        final String query = "UPDATE Capsules_in_machines SET quantity = quantity - 1 WHERE id_capsule = ? AND id_machine = ? AND quantity > 0";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            st.setInt(1, podId);
            st.setInt(2, machineID);

            st.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Aggiorna lo stato di una macchina nel database.
     *
     * @param newStatus  nuovo stato da assegnare
     * @param machineID  ID della macchina
     * @return {@code true} se l'aggiornamento è riuscito, altrimenti {@code false}
     */
    public static boolean updateStatus(int newStatus, int machineID) {
        final String query = "UPDATE Machines SET status = ? WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            st.setInt(1, newStatus);
            st.setInt(2, machineID);

            st.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Verifica se almeno due capsule hanno quantità pari a zero per una determinata macchina.
     *
     * @param machineID ID della macchina
     * @return {@code true} se ci sono almeno due capsule esaurite, altrimenti {@code false}
     */
    public static boolean checkPodSituation(int machineID) {
        final String query = "SELECT COUNT(*) >= 2 AS result FROM Capsules_in_machines WHERE quantity = 0 AND id_machine = ?";

        System.out.println("AssistanceDAO");

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(query)) {

            st.setInt(1, machineID);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                return rs.getBoolean("result");
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
