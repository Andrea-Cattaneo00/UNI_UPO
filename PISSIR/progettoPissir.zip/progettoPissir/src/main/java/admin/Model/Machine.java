package admin.Model;

/**
 * Classe che rappresenta una macchina appartenente a un istituto.
 */
public class Machine 
{
    private int id;
    private int instituteId;
    private MachineStatus status;
    private double income;

    /**
     * Costruttore della classe Machine.
     * 
     * @param id identificativo della macchina
     * @param instituteId identificativo dell'istituto a cui appartiene la macchina
     * @param status stato attuale della macchina
     * @param income valore totale presente nella cassa della macchina
     */
    public Machine(int id, int instituteId, MachineStatus status, double income)
    {
        this.id = id;
        this.instituteId = instituteId;
        this.status = status;
        this.income = income;
    }

    /**
     * Restituisce l'ID della macchina.
     * 
     * @return ID della macchina
     */
    public int getId() 
    {
        return id;
    }

    /**
     * Imposta l'ID della macchina.
     * 
     * @param id nuovo ID della macchina
     */
    public void setId(int id)
    {
        this.id = id;
    }

    /**
     * Restituisce l'ID dell'istituto associato.
     * 
     * @return ID dell'istituto
     */
    public int getInstituteId() 
    {
        return instituteId;
    }

    /**
     * Imposta l'ID dell'istituto associato.
     * 
     * @param instituteId nuovo ID dell'istituto
     */
    public void setInstituteId(int instituteId) 
    {
        this.instituteId = instituteId;
    }

    /**
     * Restituisce lo stato della macchina.
     * 
     * @return stato corrente della macchina
     */
    public MachineStatus getStatus() 
    {
        return status;
    }

    /**
     * Imposta lo stato della macchina.
     * 
     * @param status nuovo stato della macchina
     */
    public void setStatus(MachineStatus status) 
    {
        this.status = status;
    }

    /**
     * Restituisce il valore presente nella cassa della macchina.
     * 
     * @return importo totale nella cassa
     */
    public double getIncome() {
        return this.income;
    }
} 
