package admin.Model;

/**
 * Classe che rappresenta un reddito (income) generato da una macchina.
 */
public class Income 
{
    private int id;
    private int machineId;
    private int instituteId;
    private double money;

    /**
     * Costruttore della classe Income.
     * 
     * @param id identificativo del reddito
     * @param machineId identificativo della macchina associata
     * @param instituteId identificativo dell'istituto associato
     * @param money importo del reddito
     */
    public Income(int id, int machineId, int instituteId, double money) 
    {
        this.id = id;
        this.machineId = machineId;
        this.instituteId = instituteId;
        this.money = money;
    }

    /**
     * Restituisce l'ID del reddito.
     * 
     * @return ID del reddito
     */
    public int getId() 
    {
        return id;
    }

    /**
     * Imposta l'ID del reddito.
     * 
     * @param id nuovo ID del reddito
     */
    public void setId(int id) 
    {
        this.id = id;
    }

    /**
     * Restituisce l'ID della macchina associata.
     * 
     * @return ID della macchina
     */
    public int getMachineId()
    {
        return machineId;
    }

    /**
     * Imposta l'ID della macchina associata.
     * 
     * @param machineId nuovo ID della macchina
     */
    public void setMachineId(int machineId) 
    {
        this.machineId = machineId;
    }

    /**
     * Restituisce l'importo del reddito.
     * 
     * @return importo del reddito
     */
    public double getMoney() 
    {
        return money;
    }

    /**
     * Imposta l'importo del reddito.
     * 
     * @param money nuovo importo del reddito
     */
    public void setMoney(double money) 
    {
        this.money = money;
    }

    /**
     * Restituisce l'ID dell'istituto associato.
     * 
     * @return ID dell'istituto
     */
    public int getInstituteId() {
        return instituteId;
    }

    /**
     * Imposta l'ID dell'istituto associato.
     * 
     * @param instituteId nuovo ID dell'istituto
     */
    public void setInstituteId(int instituteId) {
        this.instituteId = instituteId;
    }
} 
