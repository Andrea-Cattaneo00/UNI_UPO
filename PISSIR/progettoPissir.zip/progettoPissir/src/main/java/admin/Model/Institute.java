package admin.Model;

/**
 * Classe che rappresenta un istituto con nome, città e reddito totale.
 */
public class Institute {
    private int id;
    private String name;
    private String city;
    private double income;

    /**
     * Costruttore della classe Institute.
     * 
     * @param id identificativo dell'istituto
     * @param name nome dell'istituto
     * @param city città in cui si trova l'istituto
     * @param income reddito totale associato all'istituto
     */
    public Institute(int id, String name, String city, double income) {
        this.setId(id);
        this.setName(name);
        this.setCity(city);
        this.setIncome(income);
    }

    /**
     * Restituisce l'ID dell'istituto.
     * 
     * @return ID dell'istituto
     */
    public int getId() {
        return id;
    }

    /**
     * Imposta l'ID dell'istituto.
     * 
     * @param id nuovo ID dell'istituto
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Restituisce il nome dell'istituto.
     * 
     * @return nome dell'istituto
     */
    public String getName() {
        return name;
    }

    /**
     * Imposta il nome dell'istituto.
     * 
     * @param name nuovo nome dell'istituto
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Restituisce la città dell'istituto.
     * 
     * @return città in cui si trova l'istituto
     */
    public String getCity() {
        return this.city;
    }

    /**
     * Imposta la città dell'istituto.
     * 
     * @param city nuova città dell'istituto
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Restituisce il reddito dell'istituto.
     * 
     * @return reddito totale
     */
    public double getIncome() {
        return income;
    }

    /**
     * Imposta il reddito dell'istituto.
     * 
     * @param income nuovo valore del reddito
     */
    public void setIncome(double income) {
        this.income = income;
    }

    /**
     * Restituisce una rappresentazione testuale dell'oggetto Institute.
     * 
     * @return stringa con i dati dell'istituto
     */
    @Override
    public String toString() {
        return "Institute{" +
                "id=" + id +
                ", nome='" + name + '\'' +
                ", città='" + city + '\'' +
                ", income='" + income + '\'' +
                '}';
    }
}
