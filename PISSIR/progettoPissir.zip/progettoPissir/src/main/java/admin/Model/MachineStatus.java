package admin.Model;

/**
 * Enum che rappresenta i possibili stati di una macchina.
 */
public enum MachineStatus {

    BROKEN(0),        // Macchina guasta
    WORKING(1),       // Macchina funzionante
    BALANCE_FULL(2),  // Cassetta piena
    EMPTY_PODS(3);    // Capsule esaurite

    private int value;

    /**
     * Costruttore dell'enumerazione MachineStatus.
     * 
     * @param value valore numerico associato allo stato
     */
    MachineStatus(int value) {
        this.value = value;
    }

    /**
     * Restituisce il valore numerico associato allo stato.
     * 
     * @return valore intero dello stato
     */
    public int getValue() {
        return value;
    }

    /**
     * Restituisce lo stato corrispondente al valore numerico fornito.
     * 
     * @param value valore numerico da convertire
     * @return stato corrispondente
     * @throws IllegalArgumentException se il valore non corrisponde ad alcuno stato
     */
    public static MachineStatus fromValue(int value) {
        for (MachineStatus status : MachineStatus.values()) {
            if (status.value == value) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status value: " + value);
    }
}
