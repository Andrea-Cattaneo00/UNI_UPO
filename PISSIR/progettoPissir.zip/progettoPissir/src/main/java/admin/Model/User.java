package admin.Model;

/**
 * Classe che rappresenta un utente del sistema.
 */
public class User 
{
	private int id;
	private String password;
	private String email;
	private String role;
	
	/**
	 * Costruttore della classe User.
	 * 
	 * @param id identificativo dell'utente
	 * @param email email dell'utente
	 * @param password password dell'utente (criptata)
	 * @param role ruolo dell'utente
	 */
	public User(int id, String email, String password, String role)
	{
		this.id = id;
		this.email = email;
		this.setPassword(password);
		this.role = role;
	}

	/**
	 * Restituisce l'ID dell'utente.
	 * 
	 * @return ID dell'utente
	 */
	public int getId() 
	{
		return id;
	}

	/**
	 * Imposta l'ID dell'utente.
	 * 
	 * @param id nuovo ID da assegnare all'utente
	 */
	public void setId(int id) 
	{
		this.id = id;
	}

	/**
	 * Restituisce l'email dell'utente.
	 * 
	 * @return email dell'utente
	 */
	public String getEmail() 
	{
		return email;
	}

	/**
	 * Imposta l'email dell'utente.
	 * 
	 * @param email nuova email da assegnare
	 */
	public void setEmail(String email) 
	{
		this.email = email;
	}

	/**
	 * Restituisce il ruolo dell'utente.
	 * 
	 * @return ruolo dell'utente
	 */
	public String getrole() 
	{
		return role;
	}

	/**
	 * Imposta il ruolo dell'utente.
	 * 
	 * @param role nuovo ruolo da assegnare
	 */
	public void setrole(String role) 
	{
		this.role = role;
	}

	/**
	 * Restituisce la password dell'utente.
	 * 
	 * @return password dell'utente
	 */
	public String getPassword() 
	{
		return password;
	}

	/**
	 * Imposta la password dell'utente.
	 * 
	 * @param password nuova password 
	 */
	public void setPassword(String password) 
	{
		this.password = password;
	}
} 