package admin.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mindrot.jbcrypt.BCrypt;

import admin.Model.User;
import admin.Utils.DBConnection;

public class UserDAO {

    private static Map<String, String> sessions = new HashMap<>(); // Sessioni attive

    /**
     * Registra un nuovo utente nel database.
     * 
     * @param email email dell'utente
     * @param password password dell'utente (già criptata)
     * @param role ruolo dell'utente
     * @return true se la registrazione ha avuto successo, false altrimenti
     */
    public static boolean registerUser(String email, String password, String role) {
        final String sql = "INSERT INTO Users (email, password, role) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setString(1, email);
            st.setString(2, password);
            st.setString(3, role);
            st.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Error while registering user");
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Verifica se un'email esiste già nel database.
     * 
     * @param email email da verificare
     * @return true se l'email esiste, false altrimenti
     */
    public static boolean emailExists(String email) {
        final String sql = "SELECT 1 FROM Users WHERE email = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setString(1, email);
            ResultSet rs = st.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            System.err.println("Error while checking if email exists");
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Restituisce un oggetto utente in base all'email.
     * 
     * @param email email dell'utente
     * @return oggetto {@link User} oppure null se non trovato
     */
    public static User getUserByEmail(String email) {
        final String sql = "SELECT id, email, password, role FROM Users WHERE email = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setString(1, email);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                return new User(
                        rs.getInt("id"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getString("role"));
            }

        } catch (SQLException e) {
            System.err.println("Error while retrieving user by email");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Restituisce la lista di tutti gli utenti.
     * 
     * @return lista di oggetti {@link User}
     */
    public static List<User> getAllUsers() {
        final String sql = "SELECT id, email, password, role FROM Users";
        List<User> users = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                users.add(new User(
                        rs.getInt("id"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getString("role")));
            }

        } catch (SQLException e) {
            System.err.println("Error while retrieving all users");
            e.printStackTrace();
        }
        return users;
    }

    /**
     * Verifica le credenziali di accesso dell'utente.
     * 
     * @param email email dell'utente
     * @param password password fornita
     * @return ID di sessione se login valido, null altrimenti
     */
    public static String checkLogin(String email, String password) {
        final String sql = "SELECT password FROM Users WHERE email = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setString(1, email);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");

                if (BCrypt.checkpw(password, storedPassword)) {
                    String sessionID = generatesessionID();
                    sessions.put(sessionID, email);
                    return sessionID;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while checking login");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Restituisce il ruolo associato a una sessione.
     * 
     * @param sessionID ID della sessione
     * @return ruolo dell'utente oppure stringa vuota se non trovato
     */
    public static String getRoleFromSession(String sessionID) {
        String email = sessions.get(sessionID);

        if (email == null) return "";

        try (Connection conn = DBConnection.getInstance().getConnection();) {
            PreparedStatement stmt = conn.prepareStatement("SELECT role FROM Users WHERE email = ?");
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("role");
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving role from session");
            e.printStackTrace();
        }

        return "";
    }

    /**
     * Genera un ID di sessione univoco.
     * 
     * @return ID di sessione come stringa
     */
    private static String generatesessionID() {
        return String.valueOf(System.currentTimeMillis());
    }

    /**
     * Invalida una sessione esistente.
     * 
     * @param sessionID ID della sessione da terminare
     */
    public static void logout(String sessionID) {
        sessions.remove(sessionID);
    }

    /**
     * Restituisce l'email associata a una sessione.
     * 
     * @param sessionID ID della sessione
     * @return email dell'utente associato oppure null se non trovata
     */
    public static String getUserFromSession(String sessionID) {
        return sessions.get(sessionID);
    }

    /**
     * Verifica se una sessione è valida.
     * 
     * @param sessionID ID della sessione
     * @return true se la sessione è attiva, false altrimenti
     */
    public static boolean isSessionValid(String sessionID) {
        return sessions.containsKey(sessionID);
    }
}