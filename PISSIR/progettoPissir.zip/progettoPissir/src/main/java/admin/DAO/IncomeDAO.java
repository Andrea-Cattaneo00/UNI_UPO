package admin.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import admin.Model.Income;
import admin.Utils.DBConnection;

public class IncomeDAO {

    private static final Logger LOGGER = Logger.getLogger(IncomeDAO.class.getName());

    /**
     * Restituisce tutti i record presenti nella tabella "Incomes".
     * 
     * @return una lista di oggetti {@link Income} contenenti tutti i record della tabella
     */
    public static List<Income> getAllIncomes() {
        final String sql = "SELECT * FROM Incomes";
        List<Income> incomes = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Income income = new Income(
                    rs.getInt("id"),
                    rs.getInt("machineId"),
                    0, rs.getDouble("money")
                );
                incomes.add(income);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error while retrieving all incomes", e);
        }
        return incomes;
    }

    /**
     * Restituisce tutti i record della tabella "Incomes" associati a una specifica macchina.
     * 
     * @param machineId l'identificativo della macchina
     * @return una lista di oggetti {@link Income} associati alla macchina specificata
     */
    public static List<Income> getIncomesByMachine(int machineId) {
        final String sql = "SELECT * FROM Incomes WHERE machine_id = ?";
        List<Income> incomes = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, machineId);
            try (ResultSet rs = st.executeQuery()) {
                while (rs.next()) {
                    Income income = new Income(
                        rs.getInt("id"),
                        rs.getInt("machineID"),
                        machineId, rs.getDouble("money")
                    );
                    incomes.add(income);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error while retrieving incomes for machine with ID " + machineId, e);
        }
        return incomes;
    }

    /**
     * Inserisce un nuovo record nella tabella "Incomes".
     * 
     * @param machineId l'identificativo della macchina a cui associare il reddito
     * @param money l'importo da registrare
     * @return true se l'inserimento ha avuto successo, false altrimenti
     */
    public static boolean addIncome(int machineId, double money) {
        final String sql = "INSERT INTO Incomes (machine_id, amount) VALUES (?, ?)";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, machineId);
            st.setDouble(2, money);
            int rowsInserted = st.executeUpdate();

            return rowsInserted > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error while inserting new income", e);
        }
        return false;
    }
}
