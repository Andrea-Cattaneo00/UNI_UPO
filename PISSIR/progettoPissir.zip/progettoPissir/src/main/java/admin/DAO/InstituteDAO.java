package admin.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import admin.Model.Institute;
import admin.Utils.DBConnection;

public class InstituteDAO {

    /**
     * Restituisce tutti gli istituti presenti nel database.
     * 
     * @return lista di oggetti {@link Institute}
     */
    public static List<Institute> getAllInstitutes() {
        String query = "SELECT * FROM institutes";
        List<Institute> institutes = new ArrayList<>();

        try (
                Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()
        ) {
            while (rs.next()) {
                institutes.add(mapResultSetToInstitute(rs));
            }

        } catch (SQLException e) {
            logError("Error while retrieving institutes", e);
        }
        return institutes;
    }

    /**
     * Inserisce un nuovo istituto nel database.
     * 
     * @param institute oggetto Institute da inserire
     * @return ID generato del nuovo istituto oppure 0 in caso di errore
     */
    public static int addInstitute(Institute institute) {
        String sql = "INSERT INTO institutes (name, city, income) VALUES (?, ?, ?)";

        try (
                Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, institute.getName());
            stmt.setString(2, institute.getCity());
            stmt.setDouble(3, institute.getIncome());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating institute failed, no rows affected.");
            }

            try (Statement idStmt = conn.createStatement();
                    ResultSet rs = idStmt.executeQuery("SELECT last_insert_rowid()")) {

                if (rs.next()) {
                    return rs.getInt(1);
                } else {
                    throw new SQLException("Creating institute failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Recupera un istituto in base al suo ID.
     * 
     * @param id identificativo dell'istituto
     * @return oggetto {@link Institute} oppure null se non trovato
     */
    public static Institute getInstituteById(int id) {
        String query = "SELECT id, name FROM institutes WHERE id = ?";

        try (
                Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToInstitute(rs);
                }
            }

        } catch (SQLException e) {
            logError("Error while retrieving institute with ID " + id, e);
        }
        return null;
    }

    /**
     * Elimina un istituto dato il suo ID.
     * 
     * @param id identificativo dell'istituto da eliminare
     * @return true se l'eliminazione ha avuto successo, false altrimenti
     */
    public static boolean deleteInstitute(int id) {
        String query = "DELETE FROM institutes WHERE id = ?";

        try (
                Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            logError("Error while deleting institute with ID " + id, e);
            return false;
        }
    }

    /**
     * Aggiorna il valore dell'income dell'istituto specificato.
     * 
     * @param instId ID dell'istituto
     * @param incomeToAdd valore da aggiungere all'income corrente
     * @return true se l'aggiornamento ha avuto successo, false altrimenti
     */
    public static boolean updateIncome(int instId, double incomeToAdd) {
        final String query = "UPDATE Institutes SET income = income + ? WHERE id = ?";

        try (
                Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDouble(1, incomeToAdd);
            stmt.setInt(2, instId);
            int rowsAffected = stmt.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            logError("Error while updating income for institute with ID " + instId, e);
            return false;
        }
    }

    /**
     * Conta il numero di macchine associate a un istituto specifico.
     * 
     * @param instituteID ID dell'istituto
     * @return numero di macchine oppure -1 in caso di errore
     */
    public static int countMachinesByInstitute(int instituteID) {
        final String sql = "SELECT COUNT(*) AS total_machines FROM Machines WHERE id_institute = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, instituteID);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                return rs.getInt("total_machines");
            }
            return 0;

        } catch (SQLException e) {
            logError("Error while counting machines for institute with ID " + instituteID, e);
            return -1;
        }
    }

    /**
     * Converte un risultato di una query (ResultSet) in un oggetto {@link Institute}.
     * 
     * @param rs il ResultSet della query
     * @return oggetto Institute con i dati estratti
     * @throws SQLException in caso di errore nell'accesso ai dati
     */
    private static Institute mapResultSetToInstitute(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String name = rs.getString("name");
        String city = rs.getString("city");
        double income = rs.getDouble("income");
        return new Institute(id, name, city, income);
    }

    /**
     * Metodo di utilità per loggare un errore con messaggio personalizzato.
     * 
     * @param message messaggio di errore
     * @param e eccezione generata
     */
    private static void logError(String message, Exception e) {
        System.err.println("[InstituteDAO] " + message);
        e.printStackTrace();
    }
} 
