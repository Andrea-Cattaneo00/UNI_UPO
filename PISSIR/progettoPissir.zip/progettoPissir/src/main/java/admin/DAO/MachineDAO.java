package admin.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import admin.Model.Machine;
import admin.Model.MachineStatus;
import admin.Utils.DBConnection;

public class MachineDAO {

    /**
     * Aggiorna lo stato di una macchina.
     * 
     * @param machineId ID della macchina
     * @param status nuovo stato da assegnare
     * @return true se l'aggiornamento ha avuto successo, false altrimenti
     */
    public static boolean updateMachineStatus(int machineId, MachineStatus status) {
        final String sql = "UPDATE machines SET status = ? WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, status.getValue());
            st.setInt(2, machineId);

            int affectedRows = st.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            System.err.println("Error while updating machine status with ID " + machineId);
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Raccoglie il valore del cashBox della macchina e lo resetta a 0.
     * 
     * @param machineId ID della macchina
     * @return valore attuale del cashBox prima del reset
     */
    public static double collectCashboxValue(int machineId) {
        final String selectSql = "SELECT cashBox FROM machines WHERE id = ?";
        final String updateSql = "UPDATE machines SET cashBox = 0, Status = 1 WHERE id = ?";
        double cashboxValue = 0;

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement selectStmt = conn.prepareStatement(selectSql);
                PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

            selectStmt.setInt(1, machineId);
            try (ResultSet rs = selectStmt.executeQuery()) {
                if (rs.next()) {
                    cashboxValue = rs.getDouble("cashBox");
                } else {
                    System.err.println("No machine found with ID " + machineId);
                    return 0;
                }
            }

            updateStmt.setInt(1, machineId);
            updateStmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error while resetting cashBox for machine with ID " + machineId);
            e.printStackTrace();
        }

        return cashboxValue;
    }

    /**
     * Restituisce lo stato della macchina.
     * 
     * @param machineId ID della macchina
     * @return stato della macchina, oppure null in caso di errore
     */
    public static MachineStatus getStatus(int machineId) {
        final String sql = "SELECT status FROM machines WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, machineId);
            try (ResultSet rs = st.executeQuery()) {
                if (rs.next()) {
                    int statusValue = rs.getInt("status");
                    return MachineStatus.fromValue(statusValue);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving status for machine with ID " + machineId);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Restituisce la lista di tutte le macchine presenti nel database.
     * 
     * @return lista di oggetti {@link Machine}
     */
    public static List<Machine> getAllMachines() {
        final String sql = "SELECT * FROM machines";
        List<Machine> machines = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql);
                ResultSet rs = st.executeQuery()) {

            while (rs.next()) {
                Machine machine = new Machine(
                        rs.getInt("id"),
                        rs.getInt("id_institute"),
                        MachineStatus.fromValue(rs.getInt("status")),
                        rs.getDouble("cashBox"));
                machines.add(machine);
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving all machines.");
            e.printStackTrace();
        }
        return machines;
    }

    /**
     * Aggiunge una nuova macchina all'istituto specificato.
     * 
     * @param id_institute ID dell'istituto associato
     * @return true se l'inserimento ha avuto successo, false altrimenti
     */
    public static boolean addMachine(Integer id_institute) {
        final String sql = "INSERT INTO machines (id_institute, status, cashBox) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, id_institute);
            st.setInt(2, 1);
            st.setDouble(3, 0.0);
            st.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.err.println("Error during the creation of the new machine");
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Restituisce una macchina dato il suo ID.
     * 
     * @param id ID della macchina
     * @return oggetto {@link Machine} oppure null se non trovata
     */
    public static Machine getMachineById(int id) {
        final String sql = "SELECT id, id_institute, status FROM machines WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, id);
            try (ResultSet rs = st.executeQuery()) {
                if (rs.next()) {
                    return new Machine(
                            rs.getInt("id"),
                            rs.getInt("id_institute"),
                            MachineStatus.fromValue(rs.getInt("status")),
                            rs.getDouble("cashBox"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving machine with ID " + id);
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Elimina una macchina dato il suo ID.
     * 
     * @param id ID della macchina
     * @return true se la macchina è stata eliminata con successo, false altrimenti
     */
    public static boolean deleteMachine(int id) {
        final String sql = "DELETE FROM machines WHERE id = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, id);
            int affectedRows = st.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            System.err.println("Error while deleting machine with ID " + id);
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Restituisce tutte le macchine associate a un dato istituto.
     * 
     * @param id_institute ID dell'istituto
     * @return lista di oggetti {@link Machine} associati all'istituto
     */
    public static List<Machine> getMachinesByInstitute(int id_institute) {
        final String sql = "SELECT * FROM machines WHERE id_institute = ?";
        List<Machine> machines = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, id_institute);
            try (ResultSet rs = st.executeQuery()) {
                while (rs.next()) {
                    Machine machine = new Machine(
                            rs.getInt("id"),
                            rs.getInt("id_institute"),
                            MachineStatus.fromValue(rs.getInt("status")),
                            rs.getDouble("cashBox"));
                    machines.add(machine);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error while retrieving machines for institute with ID " + id_institute);
            e.printStackTrace();
        }
        return machines;
    }

    /**
     * Rifornisce la macchina specificata incrementando la quantità di capsule.
     * 
     * @param machineID ID della macchina
     * @return true se l'operazione ha avuto successo, false altrimenti
     */
    public static boolean refillMachine(int machineID) {
        final String sql = "UPDATE Capsules_in_machines SET quantity = quantity + 30 WHERE id_machine = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
                PreparedStatement st = conn.prepareStatement(sql)) {

            st.setInt(1, machineID);
            int affectedRows = st.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            System.err.println("Error while refilling pods for machine with ID " + machineID);
            e.printStackTrace();
            return false;
        }
    }
}
