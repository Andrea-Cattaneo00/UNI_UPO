package admin.Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe singleton per la gestione della connessione al database SQLite.
 */
public class DBConnection 
{
    static private final String dbLoc = "jdbc:sqlite:src/main/resources/Storage.db";
    static private DBConnection instance = null;

    /**
     * Costruttore privato per evitare istanze multiple della classe.
     */
    private DBConnection()
    {
        instance = this;
    }

    /**
     * Restituisce l'istanza singleton di {@code DBConnection}.
     *
     * @return istanza unica della classe {@code DBConnection}
     */
    public static DBConnection getInstance() 
    {
        if (instance == null)
            return new DBConnection();
        else
        {
            return instance;
        }
    }

    /**
     * Ottiene una connessione al database SQLite.
     *
     * @return oggetto {@code Connection} verso il database
     * @throws SQLException se la connessione fallisce
     */
    public Connection getConnection() throws SQLException 
    {
        try 
        {
            // return the connection instance
            return DriverManager.getConnection(dbLoc);
        } catch (SQLException e)
        {
            throw new SQLException("Cannot get connection to " + dbLoc, e);
        }
    }
}
