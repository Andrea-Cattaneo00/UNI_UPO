package admin.Utils;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 * Classe per la gestione di un client MQTT con supporto a SSL, connessione, 
 * pubblicazione e sottoscrizione.
 */
public class MQTTClient {
    private MqttClient client;
    private MqttConnectOptions options;

    /**
     * Costruttore base del client MQTT.
     *
     * @param brokerUrl        URL del broker MQTT
     * @param clientId         Identificatore del client MQTT
     * @param clientCertPath   Percorso del certificato client (PKCS12)
     * @param clientKeyPath    Percorso della chiave privata del client
     */
    public MQTTClient(String brokerUrl, String clientId, String clientCertPath, String clientKeyPath) {
        this(brokerUrl, clientId, clientCertPath, clientKeyPath, new MemoryPersistence());
    }

    /**
     * Costruttore avanzato del client MQTT che consente di specificare un tipo di persistenza.
     *
     * @param brokerUrl        URL del broker MQTT
     * @param clientId         Identificatore del client MQTT
     * @param clientCertPath   Percorso del certificato client (PKCS12)
     * @param clientKeyPath    Percorso della chiave privata del client
     * @param persistence      Strategia di persistenza per il client
     */
    public MQTTClient(String brokerUrl, String clientId, String clientCertPath, String clientKeyPath, MqttClientPersistence persistence) {
        try {
            client = new MqttClient(brokerUrl, clientId, persistence);
            options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setAutomaticReconnect(true);
            options.setConnectionTimeout(10);
            options.setKeepAliveInterval(60);
            options.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1_1);

            // Configura SSL con certificato client
            System.setProperty("javax.net.ssl.keyStore", clientCertPath);
            System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
            System.setProperty("javax.net.ssl.keyStoreType", "PKCS12");

            // Configura truststore per il certificato CA
            System.setProperty("javax.net.ssl.trustStore", "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/mosquitto-truststore.jks");
            System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Connette il client al broker MQTT.
     */
    public void connect() {
        try {
            System.out.println("Using truststore: " + System.getProperty("javax.net.ssl.trustStore"));
            System.out.println("Connecting to MQTT broker...");
            client.connect(options);
            System.out.println("Connected!");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Disconnette il client dal broker MQTT.
     */
    public void disconnect() {
        try {
            client.disconnect();
            System.out.println("Disconnected.");
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Pubblica un messaggio testuale su un topic MQTT.
     *
     * @param topic   Il topic su cui pubblicare
     * @param message Il messaggio da inviare
     */
    public void publish(String topic, String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            client.publish(topic, mqttMessage);
            System.out.println("Published message to topic " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Pubblica un messaggio binario su un topic MQTT.
     *
     * @param topic   Il topic su cui pubblicare
     * @param payload Il messaggio in formato byte[]
     */
    public void publish(String topic, byte[] payload) {
        try {
            MqttMessage mqttMessage = new MqttMessage(payload);
            client.publish(topic, mqttMessage);
            System.out.println("Published byte[] message to topic " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sottoscrive un listener per ricevere messaggi da un topic MQTT.
     *
     * @param topic    Il topic da sottoscrivere
     * @param listener Il listener che gestisce i messaggi ricevuti
     */
    public void subscribe(String topic, IMqttMessageListener listener) {
        try {
            client.subscribe(topic, listener);
            System.out.println("Subscribed to topic " + topic);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
