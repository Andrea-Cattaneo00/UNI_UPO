package admin.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mindrot.jbcrypt.BCrypt;

import com.google.gson.Gson;

import admin.DAO.InstituteDAO;
import admin.DAO.MachineDAO;
import admin.DAO.UserDAO;
import admin.Model.Institute;
import admin.Model.Machine;
import admin.Model.MachineStatus;
import admin.Utils.MQTTClient;
import static spark.Spark.*;

/**
 * Servizio principale per la gestione delle rotte HTTP dell'applicazione.
 */
public class ManagementServices {
    private static Gson gson = new Gson();
    private static MQTTClient mqttClient;

    /**
     * Metodo principale per avviare il servizio sulla porta 8080.
     * Imposta la cartella pubblica, connessione MQTT e le rotte REST.
     * 
     * @param args argomenti da riga di comando (non usati)
     */
    public static void main(String[] args) {
        port(8080);
        staticFiles.location("/public");

        setUpMQTT();
        setupRoutes();
    }

    /**
     * Inizializza la connessione MQTT per la comunicazione con il broker.
     */
    private static void setUpMQTT() {
        String serverURL = "ssl://localhost:8883";
        String clientID  = "Assistance";
        System.out.println("Assistance online");
        System.out.println("Client ID in use: " + clientID);

        String clientCertPath = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.p12";
        String clientKeyPath  = "/home/andrea/Scaricati/progettoPissir/mqtt_certs/client/client.key";

        mqttClient = new MQTTClient(serverURL, clientID, clientCertPath, clientKeyPath);
        mqttClient.connect();
    }

    /**
     * Imposta tutte le rotte HTTP esposte dal servizio.
     */
    private static void setupRoutes() {
        path("/web/pissir", () -> {

            get("/api/checkSession", (req, res) -> {
                String sessionID = req.cookie("sessionID");

                if (sessionID == null || !UserDAO.isSessionValid(sessionID)) {
                    res.status(401);
                    return false;
                }

                String role = UserDAO.getRoleFromSession(sessionID);
                Map<String, String> response = new HashMap<>();
                response.put("status", "ok");
                response.put("role", role);
                return gson.toJson(response);
            });

            post("/register", (req, res) -> {
                Map<String, String> registrationData = gson.fromJson(req.body(), Map.class);
                String email = registrationData.get("email");
                String password = registrationData.get("password");
                String role = registrationData.get("role");

                boolean check = UserDAO.emailExists(email);

                if (check) {
                    res.status(409);
                    return "Error, this email is already registered!";
                } else {
                    String hashedPass = BCrypt.hashpw(password, BCrypt.gensalt(10));

                    boolean result = UserDAO.registerUser(email, hashedPass, role);
                    if (result) {
                        res.status(200);
                        return "User added correctly!";
                    } else {
                        res.status(404);
                        return "Error during the user registration";
                    }
                }
            });

            post("/login", (req, res) -> {
                Map<String, String> userCredentials = gson.fromJson(req.body(), Map.class);
                String email = userCredentials.get("email");
                String password = userCredentials.get("password");

                String sessionID = UserDAO.checkLogin(email, password);

                if (sessionID.isEmpty()) {
                    res.status(400);
                    return "Invalid credential";
                } else {
                    res.cookie("sessionID", sessionID);
                    res.status(200);
                    return gson.toJson(sessionID);
                }
            });

            before("/*", (req, res) -> {
                String path = req.pathInfo();
                if (path.equals("/web/pissir/login") || path.equals("/web/pissir/register") || path.equals("/web/pissir/currentUser")) {
                    return;
                }

                String sessionID = req.cookie("sessionID");

                if (sessionID == null || !UserDAO.isSessionValid(sessionID)) {
                    halt(401, "Access denied, please login.");
                }
            });

            path("/institutes", () -> {

                post("/add", (req, res) -> {
                    Institute institute = gson.fromJson(req.body(), Institute.class);
                    int newId = InstituteDAO.addInstitute(institute);

                    if (newId > 0) {
                        institute.setId(newId);
                    }
                    res.status(201);
                    return gson.toJson(institute);
                });

                delete("/:id", (req, res) -> {
                    int instituteId = Integer.parseInt(req.params("id"));
                    boolean deleted = InstituteDAO.deleteInstitute(instituteId);

                    if (deleted) {
                        res.status(200);
                        return "Institute deleted successfully";
                    } else {
                        res.status(404);
                        return "Institute not found";
                    }
                });

                post("/update/:id/income", (req, res) -> {
                    int instId = Integer.parseInt(req.params("id"));
                    double income = gson.fromJson(req.body(), double.class);

                    boolean result = InstituteDAO.updateIncome(instId, income);

                    if (!result) {
                        res.status(400);
                        return "Error during the institute income update";
                    } else {
                        res.status(200);
                        return true;
                    }
                });

                get("/:id/count/machines", (req, res) -> {
                    res.type("application/json");
                    int instId = Integer.parseInt(req.params("id"));

                    int result = InstituteDAO.countMachinesByInstitute(instId);
                    if (result < 0) {
                        res.status(500);
                        return gson.toJson(Map.of("error", "Error counting machines"));
                    } else if (result == 0) {
                        res.status(404);
                        return gson.toJson(Map.of("total", 0));
                    } else {
                        res.status(200);
                        return gson.toJson(Map.of("total", result));
                    }
                });

                get("", (req, res) -> {
                    res.type("application/json");
                    List<Institute> institutes = InstituteDAO.getAllInstitutes();
                    return gson.toJson(institutes);
                });
            });

            path("/machines", () -> {

                get("/:id/institute", (req, res) -> {
                    res.type("application/json");
                    int instituteId = Integer.parseInt(req.params("id"));
                    return gson.toJson(MachineDAO.getMachinesByInstitute(instituteId));
                });

                post("/:id/fixMachine", (req, res) -> {
                    res.type("application/json");
                    int machineID = Integer.parseInt(req.params("id"));
                    boolean result = MachineDAO.updateMachineStatus(machineID, MachineStatus.WORKING);

                    if (result) {
                        res.status(200);
                        return true;
                    } else {
                        res.status(400);
                        return false;
                    }
                });

                post("/:id/collect", (req, res) -> {
                    res.type("application/json");
                    int machineID = Integer.parseInt(req.params(":id"));
                    double result = MachineDAO.collectCashboxValue(machineID);

                    if (result == 0.0) {
                        res.status(400);
                        return "Error during the cashbox collect";
                    }
                    return result;
                });

                post("/:id/refillPods", (req, res) -> {
                    res.type("application/json");
                    int machineID = Integer.parseInt(req.params(":id"));

                    boolean result = MachineDAO.refillMachine(machineID);

                    if (result) {
                        res.status(200);
                        return true;
                    } else {
                        res.status(400);
                        return false;
                    }
                });

                post("/add", (req, res) -> {
                    Integer instituteIdOfMachine = gson.fromJson(req.body(), Integer.class);
                    boolean result = MachineDAO.addMachine(instituteIdOfMachine);
                    if (result) {
                        res.status(200);
                        return true;
                    } else {
                        res.status(400);
                        return false;
                    }
                });

                get("/:id", (req, res) -> {
                    int machineId = Integer.parseInt(req.params(":id"));
                    Machine machine = MachineDAO.getMachineById(machineId);
                    if (machine != null) {
                        res.type("application/json");
                        return gson.toJson(machine);
                    } else {
                        res.status(404);
                        return "Machine not found";
                    }
                });

                delete("/:id", (req, res) -> {
                    int machineId = Integer.parseInt(req.params(":id"));
                    boolean success = MachineDAO.deleteMachine(machineId);
                    if (success) {
                        res.status(200);
                        return "Machine deleted";
                    } else {
                        res.status(404);
                        return "Machine not found";
                    }
                });
            });

            get("", (req, res) -> {
                res.type("application/json");
                return gson.toJson(MachineDAO.getAllMachines());
            });
        });
    }

    /**
     * Genera un ID di sessione univoco.
     * 
     * @return ID di sessione
     */
    private static String generatesessionID() {
        return String.valueOf(System.currentTimeMillis());
    }
}
