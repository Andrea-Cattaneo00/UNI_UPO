package com.example.merge_projects

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.merge_projects.adapter.ChatRecyclerAdapter
import com.example.merge_projects.model.ChatMessageModel
import com.example.merge_projects.model.ChatroomModel
import com.example.merge_projects.model.UserModel
import com.example.merge_projects.utils.AndroidUtil
import com.example.merge_projects.utils.FirebaseUtil
import com.firebase.ui.firestore.FirestoreRecyclerOptions
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.Query
import com.google.firebase.ktx.Firebase

class ChatActivity : AppCompatActivity() {
    private lateinit var messageInput: EditText
    private lateinit var sendMessageBtn: ImageButton
    private lateinit var backBtn: ImageButton
    private lateinit var otherUsername: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var otherUser: UserModel
    private lateinit var chatroomId: String
    private var chatroomModel: ChatroomModel? = null
    private lateinit var auth: FirebaseAuth
    private lateinit var chatRecyclerAdapter: ChatRecyclerAdapter

    /**
     * Initializes the activity and sets up the UI components.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        auth = Firebase.auth

        // Check if the user is authenticated.
        val currentUser = auth.currentUser
        if (currentUser == null) {
            println("Error: User not logged in!")
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val currentUserId = currentUser.uid

        // Retrieve the other user from the intent.
        otherUser = AndroidUtil.getUserModelFromIntent(intent)

        // Debug: Print otherUser values.
        println("Other User: $otherUser")
        println("Other User ID: ${otherUser.userId}")

        // Validate otherUser.userId.
        if (otherUser.userId.isNullOrEmpty()) {
            println("Error: Invalid other user ID!")
            return
        }

        // Generate the chatroom ID.
        chatroomId = FirebaseUtil.getChatroomId(currentUserId, otherUser.userId)
        if (chatroomId.isNullOrEmpty()) {
            println("Error: Unable to generate chatroom ID!")
            return
        }

        // Debug: Print values.
        println("Current User ID: $currentUserId")
        println("Other User ID: ${otherUser.userId}")
        println("Chatroom ID: $chatroomId")

        // Initialize views.
        messageInput = findViewById(R.id.chat_message_input)
        sendMessageBtn = findViewById(R.id.message_send_btn)
        backBtn = findViewById(R.id.back_btn)
        otherUsername = findViewById(R.id.other_email)
        recyclerView = findViewById(R.id.chat_recycler_view)

        // Set up the back button listener.
        backBtn.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Set the other user's name.
        otherUsername.text = otherUser.email

        // Set up the send message button listener.
        sendMessageBtn.setOnClickListener {
            val message = messageInput.text.toString().trim()

            if (message.isEmpty()) {
                println("Warning: Message is empty. Ignoring send request.")
                return@setOnClickListener
            }

            // Check if chatroomModel is null.
            if (chatroomModel == null) {
                println("Warning: chatroomModel is null. Initializing chatroom...")
                getOnCreateChatroomModel {
                    // Call sendMessageToUser after initializing chatroomModel.
                    sendMessageToUser(message, chatroomId)
                }
                return@setOnClickListener
            }

            // If chatroomModel is already initialized, send the message.
            sendMessageToUser(message, chatroomId)
        }

        // Call the method to create or update the chatroom.
        getOnCreateChatroomModel {
            println("Info: ChatroomModel initialized successfully.")
        }

        setupChatRecyclerView()
    }

    /**
     * Sets up the RecyclerView to display chat messages.
     * Configures the adapter, layout manager, and data observer for the RecyclerView.
     */
    private fun setupChatRecyclerView() {
        // Create a query to get chatroom messages ordered by timestamp.
        val query = FirebaseUtil.getChatroomMessageReference(chatroomId)
            .orderBy("timestamp", Query.Direction.ASCENDING)

        // Create FirestoreRecyclerOptions for the adapter.
        val options = FirestoreRecyclerOptions.Builder<ChatMessageModel>()
            .setQuery(query, ChatMessageModel::class.java)
            .build()

        // Initialize the adapter.
        chatRecyclerAdapter = ChatRecyclerAdapter(options, this)

        // Configure the LinearLayoutManager.
        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true // Start messages from the bottom.

        // Configure the RecyclerView.
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = chatRecyclerAdapter

        // Start listening for data changes.
        chatRecyclerAdapter.startListening()

        // Automatically scroll to the end when new messages are added.
        chatRecyclerAdapter.registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                super.onItemRangeInserted(positionStart, itemCount)
                recyclerView.smoothScrollToPosition(chatRecyclerAdapter.itemCount) // Scroll to the end of the list.
            }
        })
    }

    /**
     * Sends a message to the user and updates the chatroom with the latest message details.
     * @param message The message text to be sent.
     * @param chatroomId The ID of the chatroom where the message is sent.
     */
    private fun sendMessageToUser(message: String, chatroomId: String) {
        val firebaseTimestamp = Timestamp.now()

        // Update the chatroom model with the latest message details.
        chatroomModel?.lastMessageTimestamp = firebaseTimestamp
        chatroomModel?.lastMessageSenderId = FirebaseUtil.currentUserId()

        // Safely use chatroomModel to update the Firestore document.
        FirebaseUtil.getChatroomReference(chatroomId).set(chatroomModel!!)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    println("Info: Chatroom updated successfully.")

                    // Create a new message model.
                    val chatMessageModel = FirebaseUtil.currentUserId()?.let {
                        ChatMessageModel(message, it, firebaseTimestamp)
                    }

                    // Add the message to the Firestore messages collection.
                    if (chatMessageModel != null) {
                        FirebaseUtil.getChatroomMessageReference(chatroomId).add(chatMessageModel)
                            .addOnCompleteListener { messageTask ->
                                if (messageTask.isSuccessful) {
                                    println("Info: Message sent successfully.")
                                    messageInput.setText("") // Clear the input field after sending the message.
                                } else {
                                    println("Error: Failed to send message. ${messageTask.exception?.message}")
                                }
                            }
                    }
                } else {
                    println("Error: Failed to update chatroom. ${task.exception?.message}")
                }
            }
    }

    /**
     * Extracts chatroom data from a Firestore document and initializes the chatroom model.
     * The document is expected to contain fields: "chatroomId", "userIds", "lastMessageTimestamp", and "lastMessageSenderId".
     */
    private fun getOnCreateChatroomModel(onComplete: () -> Unit) {
        FirebaseUtil.getChatroomReference(chatroomId).get().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                chatroomModel = task.result?.toObject(ChatroomModel::class.java)

                if (chatroomModel == null) {
                    // First time creating the chatroom.
                    chatroomModel = ChatroomModel(
                        chatroomId = chatroomId,
                        userIds = listOf(FirebaseUtil.currentUserId()!!, otherUser.userId),
                        lastMessageTimestamp = Timestamp.now(),
                        lastMessageSenderId = ""
                    )

                    FirebaseUtil.getChatroomReference(chatroomId).set(chatroomModel!!)
                        .addOnSuccessListener {
                            println("Info: Chatroom created successfully in the database.")
                            onComplete()
                        }
                        .addOnFailureListener { e ->
                            println("Error: Failed to create chatroom. ${e.message}")
                        }
                } else {
                    println("Info: Existing chatroom found: $chatroomModel")
                    onComplete()
                }
            } else {
                println("Error: Failed to retrieve chatroom. ${task.exception?.message}")
            }
        }
    }
}