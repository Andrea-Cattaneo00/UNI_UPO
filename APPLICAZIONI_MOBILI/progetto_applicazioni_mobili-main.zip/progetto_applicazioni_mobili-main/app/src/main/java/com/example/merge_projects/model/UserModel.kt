package com.example.merge_projects.model

import java.io.Serializable

/**
 * Represents a user in the application.
 *
 * @property userId The unique identifier for the user.
 * @property email The email address of the user.
 * @property role The role of the user (e.g., "PM", "PL", "DV").
 */
data class UserModel(
    var userId: String = "",
    var email: String = "",
    var role: String = "",
) : Serializable