package com.example.merge_projects

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import java.sql.Timestamp
import java.util.Calendar

class NewProjectFormActivity(
    private val context: Context,
    private val layoutInflater: LayoutInflater,
    private var homeActivity: Home?,
    private var isToggleChecked: Boolean
) {

    private lateinit var nameEditText: EditText
    private lateinit var responsibleEditText: EditText
    private lateinit var descriptionText: EditText
    private lateinit var selectedDeadline: Timestamp
    private lateinit var chipGroup: ChipGroup
    private lateinit var dateButton: Button
    private lateinit var datePickerDialog: DatePickerDialog
    private lateinit var nameFromDetails: String

    /**
     * Sets the form name for the activity.
     *
     * @param text The name to set.
     */
    fun setFormName(text: String) {
        nameFromDetails = text
    }

    /**
     * Displays an alert dialog for creating a new project, task, or subtask based on the user's role.
     *
     * @param role The role of the user (e.g., "PM", "PL", "DEV").
     */
    fun showAlert(role: String) {
        val builder = AlertDialog.Builder(context)
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.new_element_form, null)
        builder.setView(dialogView)
        val alertDialog = builder.create()

        val createProjectButton = dialogView.findViewById<Button>(R.id.close_button)
        nameEditText = dialogView.findViewById(R.id.titleEditText)
        responsibleEditText = dialogView.findViewById(R.id.responsibleEditText)
        descriptionText = dialogView.findViewById(R.id.descriptionEditText)
        chipGroup = dialogView.findViewById(R.id.chipGroup)

        // Set hints and visibility based on the user's role
        when (role) {
            "PM" -> {
                nameEditText.hint = "Project Name:"
                responsibleEditText.hint = "Project Leader:"
                descriptionText.visibility = View.GONE
            }
            "PL" -> {
                nameEditText.hint = "Task Name:"
                descriptionText.hint = "Task Description:"
                responsibleEditText.hint = "Developer:"
            }
            "DEV" -> {
                nameEditText.hint = "Subtask Name:"
                descriptionText.hint = "Subtask Description:"
                responsibleEditText.visibility = View.GONE
                val priority = dialogView.findViewById<TextView>(R.id.priority)
                chipGroup.visibility = View.VISIBLE
                priority.visibility = View.VISIBLE
            }
        }

        // Initialize the date picker
        initDatePicker()

        dateButton = dialogView.findViewById(R.id.datePickerButton)
        dateButton.text = getTodaysDate()
        dateButton.setOnClickListener { openDatePicker() }

        // Update the selected date in the DatePicker
        datePickerDialog.setOnDateSetListener { _, year, month, dayOfMonth ->
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)
            selectedDeadline = Timestamp(calendar.time.time) // Set the selected timestamp
            dateButton.text = makeDateString(dayOfMonth, month + 1, year) // Display the date
        }

        // Handle the create button click
        createProjectButton.setOnClickListener {
            getDatas(role)
            alertDialog.dismiss()
            val email = homeActivity?.getEmail()
            if (email != null) {
                homeActivity?.loadInitialData(email)
            }
        }

        alertDialog.show()
    }

    /**
     * Retrieves data from the form and sends it to the API based on the user's role.
     *
     * @param role The role of the user (e.g., "PM", "PL", "DEV").
     */
    private fun getDatas(role: String) {
        val name = nameEditText.text.toString()
        val responsible = responsibleEditText.text.toString()
        val deadline = selectedDeadline ?: Timestamp(Calendar.getInstance().time.time)
        val description = descriptionText.text.toString()
        val priority = getSelectedChipValues()
        val api = API()

        Log.d("NewProjectFormActivity", "Responsible value: $responsible")

        when (role) {
            "PM" -> {
                val project = hashMapOf<String, Any>(
                    "name" to name,
                    "pl" to responsible,
                    "deadline" to deadline,
                    "progress" to 0,
                )
                api.addProject(project)
            }
            "PL" -> {
                if (isToggleChecked) {
                    val item = preSetData("task", name, responsible, description, deadline, priority)
                    api.addTask(item)
                } else {
                    val item = preSetData("subtask", name, responsible, description, deadline, priority)
                    api.addSubTask(item)
                }
            }
            "DEV" -> {
                val item = preSetData("subtask", name, responsible, description, deadline, priority)
                api.addSubTask(item)
            }
        }
    }

    /**
     * Prepares data for creating a task or subtask.
     *
     * @param type The type of data ("task" or "subtask").
     * @param name The name of the task/subtask.
     * @param responsible The responsible person for the task/subtask.
     * @param description The description of the task/subtask.
     * @param deadline The deadline for the task/subtask.
     * @param priority The priority of the task/subtask.
     * @return A HashMap containing the prepared data.
     */
    private fun preSetData(type: String, name: String, responsible: String, description: String, deadline: Timestamp, priority: String): HashMap<String, Any> {
        return if (type == "task") {
            hashMapOf<String, Any>(
                "name" to name,
                "dev" to responsible,
                "description" to description,
                "deadline" to deadline,
                "progress" to 0,
                "projectName" to nameFromDetails,
            )
        } else {
            hashMapOf<String, Any>(
                "name" to name,
                "dev" to responsible,
                "description" to description,
                "deadline" to deadline,
                "progress" to 0,
                "priority" to priority,
                "taskName" to nameFromDetails,
            )
        }
    }

    /**
     * Retrieves the selected chip value from the ChipGroup.
     *
     * @return The text of the selected chip, or an empty string if no chip is selected.
     */
    private fun getSelectedChipValues(): String {
        val selectedChipId = chipGroup.checkedChipId
        if (selectedChipId != View.NO_ID) {
            val selectedChip = chipGroup.findViewById<Chip>(selectedChipId)
            return selectedChip.text.toString()
        }
        return ""
    }

    /**
     * Opens the date picker dialog.
     */
    private fun openDatePicker() {
        datePickerDialog.show()
    }

    /**
     * Initializes the date picker dialog.
     */
    private fun initDatePicker() {
        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            Log.d("DatePicker", "Selected date: $dayOfMonth/${month + 1}/$year")
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)
            selectedDeadline = Timestamp(calendar.time.time)
            dateButton.text = makeDateString(dayOfMonth, month + 1, year)
            Log.d("DatePicker", "Button text updated: ${dateButton.text}")
        }

        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH)
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val style = com.google.android.material.R.style.ThemeOverlay_MaterialComponents_Dialog

        datePickerDialog = DatePickerDialog(context, style, dateSetListener, year, month, day)
        datePickerDialog.datePicker.minDate = cal.timeInMillis
    }

    /**
     * Formats the date into a string in the format "DD/MM/YYYY".
     *
     * @param dayOfMonth The day of the month.
     * @param month The month.
     * @param year The year.
     * @return The formatted date string.
     */
    private fun makeDateString(dayOfMonth: Int, month: Int, year: Int): String {
        return "$dayOfMonth/${month}/$year" // Format: DD/MM/YYYY
    }

    /**
     * Formats the month to ensure it has two digits.
     *
     * @param month The month to format.
     * @return The formatted month string.
     */
    private fun getMonthFormat(month: Int): String {
        return if (month < 10) {
            "0$month"
        } else {
            month.toString()
        }
    }

    /**
     * Retrieves today's date in the format "DD/MM/YYYY".
     *
     * @return Today's date as a formatted string.
     */
    private fun getTodaysDate(): String {
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        return makeDateString(day, month, year)
    }
}