package com.example.merge_projects

import android.content.ContentValues
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QueryDocumentSnapshot
import java.sql.Timestamp

class API() {

    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val data: ArrayList<ItemsViewModel> = ArrayList()

    /**
     * Extracts project data from a Firestore document and adds it to the data list.
     *
     * @param project The Firestore document representing a project.
     * The document is expected to contain fields: "name", "pl", "deadline", "progress", and "pm".
     */
    private fun setProjectData(project: QueryDocumentSnapshot) {
        val projectName = project.getString("name").toString()
        val pl = project.getString("pl").toString()
        val deadlineTimestamp = project.getTimestamp("deadline")?.let { Timestamp(it.toDate().time) } ?: Timestamp(0)
        val progress = project.getLong("progress")?.toInt() ?: 0
        val pm = project.getString("pm").toString()
        data.add(
            ItemsViewModel(
                projectName = projectName,
                PL = pl,
                PM = pm,
                deadlineTimestamp = deadlineTimestamp,
                progress = progress
            )
        )
    }

    /**
     * Extracts task data from a Firestore document and adds it to the data list.
     *
     * @param task The Firestore document representing a task.
     * The document is expected to contain fields: "name", "dev", "pl", "pm", "description",
     * "deadline", "progress", "projectName", and "priority".
     */
    private fun setTaskData(task: QueryDocumentSnapshot) {
        val taskName = task.getString("name").toString()
        val dev = task.getString("dev").toString()
        val pl = task.getString("pl").toString()
        val pm = task.getString("pm").toString()
        val description = task.getString("description").toString()
        val deadlineTimestamp = task.getTimestamp("deadline")?.let { Timestamp(it.toDate().time) } ?: Timestamp(0)
        val progress = task.getLong("progress")?.toInt() ?: 0
        val projectName = task.getString("projectName").toString()
        val priority = task.getString("priority").toString()
        data.add(
            ItemsViewModel(
                taskName = taskName,
                projectName = projectName,
                dev = dev,
                PL = pl,
                PM = pm,
                description = description,
                deadlineTimestamp = deadlineTimestamp,
                progress = progress,
                priority = priority
            )
        )
    }

    /**
     * Extracts subtask data from a Firestore document and adds it to the data list.
     *
     * @param subtask The Firestore document representing a subtask.
     * The document is expected to contain fields: "name", "priority", "description",
     * "deadline", "progress", "taskName", "projectName", "pm", "pl", and "dev".
     */
    private fun setSubtaskData(subtask: QueryDocumentSnapshot) {
        val name = subtask.getString("name").toString()
        val priority = subtask.getString("priority").toString()
        val description = subtask.getString("description").toString()
        val deadlineTimestamp = subtask.getTimestamp("deadline")?.let { Timestamp(it.toDate().time) } ?: Timestamp(0)
        val progress = subtask.getLong("progress")?.toInt() ?: 0
        val taskName = subtask.getString("taskName").toString()
        val projectName = subtask.getString("projectName").toString()
        val pm = subtask.getString("pm").toString()
        val pl = subtask.getString("pl").toString()
        val dev = subtask.getString("dev").toString()
        data.add(
            ItemsViewModel(
                subtaskName = name,
                projectName = projectName,
                description = description,
                deadlineTimestamp = deadlineTimestamp,
                progress = progress,
                priority = priority,
                taskName = taskName,
                PM = pm,
                PL = pl,
                dev = dev
            )
        )
    }

    /**
     * Adds a new project to the Firestore "projects" collection.
     *
     * @param project A HashMap containing the project data to be added.
     * On success, logs the document ID of the newly added project.
     * On failure, logs an error message.
     */
    fun addProject(project: HashMap<String, Any>) {
        db.collection("projects")
            .add(project)
            .addOnSuccessListener { documentReference ->
                Log.d(ContentValues.TAG, "Project added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error adding document", e)
            }
    }

    /**
     * Adds a new task to the Firestore "tasks" collection.
     *
     * @param task A HashMap containing the task data to be added.
     * On success, logs the document ID of the newly added task.
     * On failure, logs an error message.
     */
    fun addTask(task: HashMap<String, Any>) {
        db.collection("tasks")
            .add(task)
            .addOnSuccessListener { documentReference ->
                Log.d(ContentValues.TAG, "Task added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error adding document", e)
            }
    }

    /**
     * Adds a new subtask to the Firestore "subtasks" collection.
     *
     * @param subtask A HashMap containing the subtask data to be added.
     * On success, logs the document ID of the newly added subtask.
     * On failure, logs an error message.
     */
    fun addSubTask(subtask: HashMap<String, Any>) {
        db.collection("subtasks")
            .add(subtask)
            .addOnSuccessListener { documentReference ->
                Log.d(ContentValues.TAG, "Subtask added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error adding document", e)
            }
    }

    /**
     * Retrieves all projects from Firestore based on the user's role and email.
     *
     * @param email The email of the user to filter projects.
     * @param role The role of the user (e.g., "PM" or "PL").
     * @param callback A callback function to return the list of projects.
     */
    fun getAllProjects(email: String, role: String, callback: (ArrayList<ItemsViewModel>) -> Unit) {
        val collectionRef = db.collection("projects")

        // Apply the filter based on the role
        val query = when (role) {
            "PM" -> collectionRef
            "PL" -> collectionRef.whereEqualTo("pl", email) // Filter for PL
            else -> throw IllegalArgumentException("Unsupported role: $role")
        }

        query.get()
            .addOnSuccessListener { projects ->
                data.clear()
                for (project in projects) {
                    setProjectData(project)
                }
                callback(data)
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error getting documents: ", e)
                callback(ArrayList())
            }
    }

    /**
     * Retrieves all tasks assigned to a specific Project Leader (PL) from Firestore.
     *
     * @param email The email of the Project Leader (PL).
     * @param callback A callback function to return the list of tasks.
     */
    fun getAllTasks(email: String, callback: (ArrayList<ItemsViewModel>) -> Unit) {
        db.collection("tasks")
            .whereEqualTo("pl", email) // Filter tasks for the specific PL
            .get()
            .addOnSuccessListener { tasks ->
                data.clear()
                for (task in tasks) {
                    setTaskData(task) // Add task data to the list
                }
                callback(data) // Pass data to the callback
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error getting documents: ", e)
                callback(ArrayList()) // Pass an empty list in case of error
            }
    }

    /**
     * Retrieves all tasks assigned to a specific Developer (DEV) from Firestore.
     *
     * @param email The email of the Developer (DEV).
     * @param callback A callback function to return the list of tasks.
     */
    fun getAllTaskForDev(email: String, callback: (ArrayList<ItemsViewModel>) -> Unit) {
        db.collection("tasks")
            .whereEqualTo("dev", email)
            .get()
            .addOnSuccessListener { tasks ->
                data.clear()
                for (task in tasks) {
                    setTaskData(task)
                }
                callback(data)
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error getting documents: ", e)
                callback(ArrayList())
            }
    }

    /**
     * Retrieves all subtasks assigned to a specific Developer (DEV) from Firestore.
     *
     * @param email The email of the Developer (DEV).
     * @param callback A callback function to return the list of subtasks.
     */
    fun getAllSubtasks(email: String, callback: (ArrayList<ItemsViewModel>) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("dev", email)
            .get()
            .addOnSuccessListener { subtasks ->
                data.clear()
                for (subtask in subtasks) {
                    setSubtaskData(subtask)
                }
                callback(data)
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error getting documents: ", e)
                callback(ArrayList())
            }
    }

    /**
     * Retrieves all tasks belonging to a specific project for display in a GridView.
     *
     * @param name The name of the project.
     * @param callback A callback function to return the list of tasks.
     */
    fun getTaskForGridView(name: String, callback: (ArrayList<ItemsViewModel>) -> Unit) {
        db.collection("tasks")
            .whereEqualTo("projectName", name)
            .get()
            .addOnSuccessListener { tasks ->
                data.clear()
                for (task in tasks) {
                    setTaskData(task)
                }
                callback(data)
            }
            .addOnFailureListener {
                Log.e("Log", "Error reading tasks belonging to the project: ${it.message}")
                callback(ArrayList())
            }
    }

    /**
     * Retrieves all subtasks belonging to a specific task for display in a GridView.
     *
     * @param name The name of the task.
     * @param callback A callback function to return the list of subtasks.
     */
    fun getSubtaskForGridView(name: String, callback: (ArrayList<ItemsViewModel>) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("taskName", name)
            .get()
            .addOnSuccessListener { subtasks ->
                data.clear()
                // Iterate over the found documents
                for (subtask in subtasks) {
                    setSubtaskData(subtask)
                }
                callback(data)
            }
            .addOnFailureListener {
                Log.e("TAG", "Error reading tasks belonging to the project: ${it.message}")
                callback(ArrayList())
            }
    }

    /**
     * Removes a list of tasks from Firestore.
     *
     * @param deleteItemList The list of tasks to be deleted.
     * @param onComplete A callback function to notify the result of the deletion process.
     */
    fun removeTasks(deleteItemList: ArrayList<ItemsViewModel>, onComplete: (Boolean) -> Unit) {
        var success = true
        val tasks = deleteItemList.size
        var completed = 0

        for (item in deleteItemList) {
            db.collection("tasks")
                .whereEqualTo("name", item.taskName)
                .get()
                .addOnSuccessListener { documents ->
                    for (document in documents) {
                        db.collection("tasks").document(document.id)
                            .delete()
                            .addOnFailureListener {
                                Log.e("Firestore", "Error deleting ${item.taskName}")
                                success = false
                            }
                            .addOnCompleteListener {
                                completed++
                                if (completed == tasks) {
                                    onComplete(success)
                                }
                            }
                    }
                }
                .addOnFailureListener {
                    Log.e("Firestore", "Error querying for ${item.taskName}")
                    success = false
                    completed++
                    if (completed == tasks) {
                        onComplete(success)
                    }
                }
        }
    }

    /**
     * Removes a list of subtasks from Firestore.
     *
     * @param deleteItemList The list of subtasks to be deleted.
     * @param onComplete A callback function to notify the result of the deletion process.
     */
    fun removeSubTasks(deleteItemList: ArrayList<ItemsViewModel>, onComplete: (Boolean) -> Unit) {
        var success = true
        val tasks = deleteItemList.size
        var completed = 0

        for (item in deleteItemList) {
            db.collection("subtasks")
                .whereEqualTo("name", item.subtaskName)
                .get()
                .addOnSuccessListener { documents ->
                    for (document in documents) {
                        db.collection("tasks").document(document.id)
                            .delete()
                            .addOnFailureListener {
                                Log.e("Firestore", "Error deleting ${item.subtaskName}")
                                success = false
                            }
                            .addOnCompleteListener {
                                completed++
                                if (completed == tasks) {
                                    onComplete(success)
                                }
                            }
                    }
                }
                .addOnFailureListener {
                    Log.e("Firestore", "Error querying for ${item.subtaskName}")
                    success = false
                    completed++
                    if (completed == tasks) {
                        onComplete(success)
                    }
                }
        }
    }

    /**
     * Updates the values of a task in Firestore.
     *
     * @param fieldValues A map containing the fields to be updated (e.g., name, description, dev).
     * @param taskName The name of the task to be updated.
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun editTaskValues(fieldValues: Map<String, String>, taskName: String, onComplete: (Boolean) -> Unit) {
        db.collection("tasks")
            .whereEqualTo("name", taskName)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]

                    val updates = mutableMapOf<String, Any>()
                    if (!fieldValues["name"].isNullOrEmpty()) {
                        updates["name"] = fieldValues["name"]!!
                    }
                    if (!fieldValues["description"].isNullOrEmpty()) {
                        updates["description"] = fieldValues["description"]!!
                    }
                    if (!fieldValues["dev"].isNullOrEmpty()) {
                        updates["dev"] = fieldValues["dev"]!!
                    }

                    document.reference.update(updates)
                        .addOnSuccessListener {
                            onComplete(true) // Notify success
                        }
                        .addOnFailureListener { e ->
                            Log.e("Log", "Error during the update: ", e)
                            onComplete(false) // Notify error
                        }
                } else {
                    Log.d("Log", "No document found with name: $taskName")
                    onComplete(false) // Notify that the document was not found
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error querying document", e)
                onComplete(false) // Notify query error
            }
    }

    /**
     * Updates the task name in all related subtasks in Firestore.
     *
     * @param taskName The new name of the task.
     * @param oldTaskName The old name of the task.
     * @param newDev The new developer assigned to the task (optional).
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun updateTaskNameInSubs(taskName: String, oldTaskName: String, newDev: String?, onComplete: (Boolean) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("taskName", oldTaskName)
            .get()
            .addOnSuccessListener { subs ->
                if (!subs.isEmpty) {
                    var success = true
                    val totalSubs = subs.size()
                    var completed = 0

                    for (sub in subs) {
                        // Create a map for updates
                        val updates = mutableMapOf<String, Any>()
                        updates["taskName"] = taskName

                        // If newDev is not null, update the dev field as well
                        if (newDev != null) {
                            updates["dev"] = newDev
                        }

                        // Perform the update
                        sub.reference.update("taskName", taskName)
                            .addOnSuccessListener {
                                completed++
                                if (completed == totalSubs) {
                                    onComplete(success)
                                }
                            }
                            .addOnFailureListener { e ->
                                Log.e("Firestore", "Error updating subtask: ${sub.id}", e)
                                success = false
                                completed++
                                if (completed == totalSubs) {
                                    onComplete(success)
                                }
                            }
                    }
                } else {
                    Log.d("Log", "No document found with name: $taskName")
                    onComplete(false) // Notify that the document was not found
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error querying document", e)
                onComplete(false) // Notify query error
            }
    }

    /**
     * Updates the values of a subtask in Firestore.
     *
     * @param fieldValues A map containing the fields to be updated (e.g., name, description, dev).
     * @param subtaskName The name of the subtask to be updated.
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun editSubtaskValues(fieldValues: Map<String, String>, subtaskName: String, onComplete: (Boolean) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("name", subtaskName)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]

                    val updates = mutableMapOf<String, Any>()
                    if (!fieldValues["name"].isNullOrEmpty()) {
                        updates["name"] = fieldValues["name"]!!
                    }
                    if (!fieldValues["description"].isNullOrEmpty()) {
                        updates["description"] = fieldValues["description"]!!
                    }
                    if (!fieldValues["dev"].isNullOrEmpty()) {
                        updates["dev"] = fieldValues["dev"]!!
                    }

                    document.reference.update(updates)
                        .addOnSuccessListener {
                            onComplete(true) // Notify success
                        }
                        .addOnFailureListener { e ->
                            Log.e("Log", "Error during the update: ", e)
                            onComplete(false) // Notify error
                        }
                } else {
                    Log.d("Log", "No document found with name: $subtaskName")
                    onComplete(false) // Notify that the document was not found
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error querying document", e)
                onComplete(false) // Notify query error
            }
    }

    /**
     * Retrieves the list of all developers from Firestore.
     *
     * @param callback A callback function to return the list of developers.
     */
    fun getAllDevelopers(callback: (devList: MutableList<String>) -> Unit) {
        db.collection("users")
            .whereEqualTo("role", "DV")
            .get()
            .addOnSuccessListener { developers ->
                val devList = mutableListOf<String>()
                for (developer in developers.documents) {
                    val name = developer.getString("email")
                    if (name != null) {
                        devList.add(name)
                    }
                }
                Log.d("dev", "$devList")
                callback(devList)
            }
            .addOnFailureListener {
                Log.e("TAG", "Error reading developers from the database: ${it.message}")
                callback(mutableListOf<String>())
            }
    }

    /**
     * Updates the developer assigned to all subtasks of a specific task in Firestore.
     *
     * @param taskName The name of the task.
     * @param newDev The new developer to be assigned.
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun updateSpecificSubDev(taskName: String, newDev: String, onComplete: (Boolean) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("taskName", taskName)
            .get()
            .addOnSuccessListener { subs ->

                for (sub in subs.documents) {
                    val subtaskId = sub.id

                    db.collection("subtasks")
                        .document(subtaskId)
                        .update("dev", newDev)
                        .addOnCompleteListener {
                            Log.d("UpdateSubDev", "Document $subtaskId updated successfully")
                        }
                        .addOnFailureListener { e ->
                            Log.e("UpdateSubDev", "Error updating document $subtaskId", e)
                        }
                }
                onComplete(true)
            }
            .addOnFailureListener { e ->
                Log.e("UpdateSubDev", "Error fetching subtasks", e)
                onComplete(false)
            }
    }

    /**
     * Increases the progress of a subtask by 25%.
     *
     * @param subtaskName The name of the subtask to update.
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun increaseSubPercentage(subtaskName: String, onComplete: (Boolean) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("name", subtaskName)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]

                    val currentProgress = document.getLong("progress") ?: 0
                    val newProgress = currentProgress + 25

                    document.reference.update("progress", newProgress)
                        .addOnSuccessListener {
                            onComplete(true)
                        }
                        .addOnFailureListener { e ->
                            Log.e("Log", "Error during the progress update: ", e)
                            onComplete(false)
                        }
                } else {
                    Log.d("Log", "No document found with name: $subtaskName")
                    onComplete(false)
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error querying document", e)
            }
    }

    /**
     * Decreases the progress of a subtask by 25%.
     *
     * @param subtaskName The name of the subtask to update.
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun decreaseSubPercentage(subtaskName: String, onComplete: (Boolean) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("name", subtaskName)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]

                    val currentProgress = document.getLong("progress") ?: 0
                    val newProgress = currentProgress - 25

                    document.reference.update("progress", newProgress)
                        .addOnSuccessListener {
                            onComplete(true)
                        }
                        .addOnFailureListener { e ->
                            Log.e("Log", "Error during the progress update: ", e)
                            onComplete(false)
                        }
                } else {
                    Log.d("Log", "No document found with name: $subtaskName")
                    onComplete(false)
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error querying document", e)
            }
    }

    /**
     * Updates the progress of a task based on the average progress of its subtasks.
     *
     * @param taskName The name of the task to update.
     * @param projectName The name of the project the task belongs to.
     * @param onComplete A callback function to notify the result of the update process.
     */
    fun updateTaskProgress(taskName: String, projectName: String, onComplete: (Int) -> Unit) {
        db.collection("subtasks")
            .whereEqualTo("taskName", taskName)
            .get()
            .addOnSuccessListener { subtasks ->

                val totalProgress = subtasks.sumOf { it.getLong("progress")?.toInt() ?: 0 }
                val averageProgress = totalProgress / subtasks.size()

                db.collection("tasks")
                    .whereEqualTo("name", taskName)
                    .get()
                    .addOnSuccessListener { querySnapshot ->

                        val document = querySnapshot.documents[0]
                        document.reference.update("progress", averageProgress)
                        Log.d("Log", "Task update executed")
                        updateProjectProgress(projectName) { outcome ->
                            if (outcome) {
                                onComplete(2)       // Project was also updated
                            } else {
                                onComplete(1)       // Only the task was updated
                            }

                        } // Update the project
                    }
                    .addOnFailureListener { e ->
                        Log.w(ContentValues.TAG, "Error updating task progress", e)
                        onComplete(0)
                    }
            }
    }

    /**
     * Updates the progress of a project based on the average progress of its tasks.
     *
     * @param projectName The name of the project to update.
     * @param onComplete A callback function to notify the result of the update process.
     */
    private fun updateProjectProgress(projectName: String, onComplete: (Boolean) -> Unit) {
        db.collection("tasks")
            .whereEqualTo("projectName", projectName)
            .get()
            .addOnSuccessListener { tasks ->
                if (tasks.isEmpty) {
                    Log.w(ContentValues.TAG, "No tasks found for project: $projectName")
                    onComplete(false)
                    return@addOnSuccessListener
                }
                val totalProgress = tasks.sumOf { it.getLong("progress")?.toInt() ?: 0 }
                val averageProgress = totalProgress / tasks.size()

                db.collection("projects")
                    .whereEqualTo("name", projectName)
                    .get()
                    .addOnSuccessListener { querySnapshot ->
                        if (!querySnapshot.isEmpty) {
                            val document = querySnapshot.documents[0]
                            document.reference.update("progress", averageProgress)
                                .addOnSuccessListener {
                                    Log.d("Log", "Project progress updated successfully")
                                    onComplete(true)
                                }
                                .addOnFailureListener { e ->
                                    Log.e("Log", "Error updating project progress", e)
                                    onComplete(false)
                                }
                        } else {
                            Log.d("Log", "No project found with name: $projectName")
                            onComplete(false)
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e("Log", "Error querying project", e)
                        onComplete(false)
                    }
            }
            .addOnFailureListener { e ->
                Log.w(ContentValues.TAG, "Error fetching tasks for project: $projectName", e)
                onComplete(false)
            }
    }

    /**
     * Retrieves the Firebase Cloud Messaging (FCM) token of a specific user.
     *
     * @param email The email of the user.
     * @param role The role of the user (e.g., "PM", "PL", "DV").
     * @param onComplete A callback function to return the FCM token.
     */
    fun getTokenOf(email: String, role: String, onComplete: (String?) -> Unit) {
        db.collection("users")
            .whereEqualTo("email", email)
            .whereEqualTo("role", role)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]
                    val token = document.getString("token")
                    Log.d("Api", "Token fetched successfully: $token")
                    onComplete(token)
                } else {
                    onComplete(null)
                }
            }
            .addOnFailureListener { e ->
                Log.e("FirestoreError", "Error fetching user token", e)
                onComplete(null)
            }
    }
}