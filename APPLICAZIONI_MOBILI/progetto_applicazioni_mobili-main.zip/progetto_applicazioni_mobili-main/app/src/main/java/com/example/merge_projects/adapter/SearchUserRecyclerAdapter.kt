package com.example.merge_projects.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.merge_projects.R
import com.example.merge_projects.model.UserModel
import com.example.merge_projects.ChatActivity
import com.example.merge_projects.utils.AndroidUtil
import com.firebase.ui.firestore.FirestoreRecyclerAdapter
import com.firebase.ui.firestore.FirestoreRecyclerOptions

class SearchUserRecyclerAdapter(
    options: FirestoreRecyclerOptions<UserModel>,
    private val context: Context
) : FirestoreRecyclerAdapter<UserModel, SearchUserRecyclerAdapter.UserModelViewHolder>(options) {

    /**
     * Binds the user data to the ViewHolder.
     * @param holder The ViewHolder to bind the data to.
     * @param position The position of the item in the dataset.
     * @param model The user model containing the data.
     */
    override fun onBindViewHolder(holder: UserModelViewHolder, position: Int, model: UserModel) {
        holder.emailText.text = model.email
        holder.roleText.text = model.role

        // Set a click listener to open the chat activity with the selected user
        holder.itemView.setOnClickListener {
            val intent = Intent(context, ChatActivity::class.java)
            AndroidUtil.passUserModelAsIntent(intent, model)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }
    }

    /**
     * Creates a new ViewHolder for the user item.
     * @param parent The parent ViewGroup.
     * @param viewType The type of the view.
     * @return A new UserModelViewHolder instance.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserModelViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.search_user_recycler_row, parent, false)
        return UserModelViewHolder(view)
    }

    /**
     * ViewHolder class for the user item.
     * @param itemView The view of the user item.
     */
    inner class UserModelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val emailText: TextView = itemView.findViewById(R.id.email_text)
        val roleText: TextView = itemView.findViewById(R.id.role_text)
        val profilePic: ImageView = itemView.findViewById(R.id.profile_pic_image_view)
    }
}
