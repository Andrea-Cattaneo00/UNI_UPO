package com.example.merge_projects

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    /**
     * Handles incoming FCM messages.
     * @param remoteMessage The message received from Firebase Cloud Messaging.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        // Handle the notification payload.
        remoteMessage.notification?.let {
            showNotification(it.title, it.body)
        }

        // Handle the data payload (optional).
        if (remoteMessage.data.isNotEmpty()) {
            val title = remoteMessage.notification?.title
            val body = remoteMessage.notification?.body
            showNotification(title, body)
        }
    }

    /**
     * Displays a notification with the provided title and message.
     * @param title The title of the notification.
     * @param message The message body of the notification.
     */
    private fun showNotification(title: String?, message: String?) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create a notification channel (required for Android 8.0 and above).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "default_channel_id",
                "Default Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        // Create an intent to open the app when the notification is clicked.
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        // Build the notification.
        val notificationBuilder = NotificationCompat.Builder(this, "default_channel_id")
            .setContentTitle(title ?: "Completion!") // Use a default title if title is null.
            .setContentText(message ?: "A project has been completed! Go check it out!") // Use a default message if message is null.
            .setSmallIcon(R.drawable.ic_notification) // Mandatory icon.
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        // Display the notification.
        notificationManager.notify(0, notificationBuilder.build())
    }

    /**
     * Called when a new FCM token is generated.
     * @param token The new token.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "New token generated: $token")
    }
}