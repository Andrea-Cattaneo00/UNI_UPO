package com.example.merge_projects.utils

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore

object FirebaseUtil {

    // Ottieni l'ID dell'utente corrente
    fun currentUserId(): String? {
        return FirebaseAuth.getInstance().currentUser?.uid
    }

    // Ottieni il riferimento alla collezione di tutti gli utenti
    fun allUserCollectionReference(): CollectionReference {
        return FirebaseFirestore.getInstance().collection("users")
    }

    // Ottieni il riferimento a una chatroom
    fun getChatroomReference(chatroomId: String): DocumentReference {
        return FirebaseFirestore.getInstance().collection("chatrooms").document(chatroomId)
    }

    // Ottieni il riferimento alla collezione di messaggi di una chatroom
    fun getChatroomMessageReference(chatroomId: String): CollectionReference {
        return FirebaseFirestore.getInstance().collection("chatrooms").document(chatroomId).collection("chats")
    }

    // Genera l'ID della chatroom
    fun getChatroomId(userId1: String, userId2: String): String {
        return if (userId1 < userId2) {
            "$userId1-$userId2"
        } else {
            "$userId2-$userId1"
        }
    }


}