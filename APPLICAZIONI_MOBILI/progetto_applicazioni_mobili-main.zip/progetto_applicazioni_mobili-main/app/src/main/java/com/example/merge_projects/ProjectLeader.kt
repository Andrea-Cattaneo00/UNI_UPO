package com.example.merge_projects

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import java.sql.Timestamp
import java.util.ArrayList

class ProjectLeader(
    private val recyclerView: RecyclerView,
    private val context: Context
) {

    private var data: ArrayList<ItemsViewModel> = ArrayList()
    private var isToggleChecked: Boolean = false

    /**
     * Sets up the RecyclerView with projects or tasks based on the toggle state.
     * @param email The email of the Project Leader (PL).
     * @param isToggleChecked Indicates whether to load projects (true) or tasks (false).
     */
    fun setUpRecycler(email: String, isToggleChecked: Boolean) {
        val api = API()
        this.isToggleChecked = isToggleChecked
        if (isToggleChecked) {
            // Load projects for the Project Leader.
            api.getAllProjects(email, "PL") { projects: ArrayList<ItemsViewModel> ->
                if (projects.isEmpty()) {
                    Log.d("ProjectLeader", "No projects found for PL: $email")
                } else {
                    data.clear()
                    data.addAll(projects)
                    Log.d("ProjectLeader", "Projects found: ${projects.size}")
                    for (project in projects) {
                        Log.d("ProjectLeader", "Project: ${project.projectName}")
                    }
                    distributeTasksToRecyclerViews(projects, true)
                }
            }
        } else {
            // Load tasks for the Project Leader.
            api.getAllTasks(email) { tasks: ArrayList<ItemsViewModel> ->
                if (tasks.isEmpty()) {
                    Log.d("ProjectLeader", "No tasks found for PL: $email")
                } else {
                    data.clear()
                    data.addAll(tasks)
                    Log.d("ProjectLeader", "Tasks found: ${tasks.size}")
                    for (task in tasks) {
                        Log.d("ProjectLeader", "Task: ${task.taskName}")
                    }
                    distributeTasksToRecyclerViews(tasks, false)
                }
            }
        }
    }

    /**
     * Applies filters to the data and updates the RecyclerView.
     * @param filters A map of filters to apply (state, dev, deadline, priority).
     */
    fun applyFilters(filters: Map<String, Any?>) {
        Log.d("ProjectLeader", "Applying filters to data: $data")
        val filteredData = data.filter { item ->
            val matchesState = filters["state"]?.let { state ->
                when (state) {
                    "Started" -> item.progress > 0 && item.progress < 100
                    "NotStarted" -> item.progress == 0
                    "Finished" -> item.progress == 100
                    else -> true
                }
            } ?: true

            val matchesDev = filters["dev"]?.let { dev ->
                item.dev == dev
            } ?: true

            val matchesDeadline = filters["deadline"]?.let { deadline ->
                item.deadlineTimestamp <= deadline as Timestamp
            } ?: true

            val matchesPriority = filters["priority"]?.let { priority ->
                if (priority is List<*>) {
                    // If it's a list, check if item.priority is in the list.
                    priority.contains(item.priority)
                } else {
                    // If it's not a list, compare directly.
                    item.priority == priority
                }
            } ?: true

            matchesState && matchesDev && matchesDeadline && matchesPriority
        }

        distributeTasksToRecyclerViews(filteredData, false)
    }

    /**
     * Resets the filters and updates the RecyclerView with the original data.
     * @param isToggleChecked Indicates whether to reset for projects (true) or tasks (false).
     */
    fun resetFilters(isToggleChecked: Boolean) {
        Log.d("ProjectLeader", "Resetting filters. isToggleChecked: $isToggleChecked")
        Log.d("ProjectLeader", "Data content: $data")
        distributeTasksToRecyclerViews(data, !isToggleChecked)
    }

    /**
     * Distributes tasks or projects to the RecyclerView and sets up the adapter.
     * @param data The list of tasks or projects to display.
     * @param isToggleChecked Indicates whether the data consists of projects (true) or tasks (false).
     */
    private fun distributeTasksToRecyclerViews(
        data: List<ItemsViewModel>,
        isToggleChecked: Boolean
    ) {
        Log.d("ProjectLeader", "Distributing tasks to RecyclerView. isToggleChecked: $isToggleChecked")
        val dataList = ArrayList(data)

        val adapter = CustomAdapter(
            "PL", dataList, isToggleChecked, context,
            object : OnItemClickListener {
                override fun onItemClick(position: Int) {
                    val clickedItem = data[position]
                    val intent = if (isToggleChecked) {
                        // Open the project details page.
                        Intent(context, DetailsProjects::class.java).apply {
                            putExtra("isToggleChecked", true)
                            putExtra("role", "PL")
                            putExtra("projectName", clickedItem.projectName)
                            putExtra("deadline", clickedItem.deadlineTimestamp.time)
                            putExtra("progress", clickedItem.progress)
                        }
                    } else {
                        // Open the task details page.
                        Intent(context, DetailsProjects::class.java).apply {
                            putExtra("isToggleChecked", false)
                            putExtra("role", "PL")
                            putExtra("taskName", clickedItem.taskName)
                            putExtra("deadline", clickedItem.deadlineTimestamp.time)
                            putExtra("description", clickedItem.description)
                            putExtra("progress", clickedItem.progress)
                            putExtra("dev", clickedItem.dev)
                        }
                    }
                    context.startActivity(intent)
                }
            }
        )
        recyclerView.adapter = adapter
    }
}