package com.example.merge_projects

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ProgressBar
import android.widget.TextView
import androidx.cardview.widget.CardView

class GridAdapter(
    val data: ArrayList<ItemsViewModel>,
    private val context: Context,
    private val role: String,
    private val isSecondPage: Boolean,
    private var isCardInteracted: Boolean,
    private var isToggleChecked: Boolean,
    private var layoutInflater: LayoutInflater,
    private var taskName: String
) : BaseAdapter() {

    private var isLongClickEnabled = false
    private var deleteItemTempList = ArrayList<ItemsViewModel>()
    private var detailsProjects = DetailsProjects()

    /**
     * ViewHolder for subtask items.
     */
    private class SubtaskViewHolder(view: View) {
        val name: TextView = view.findViewById(R.id.miniName)
        val progressBar: ProgressBar = view.findViewById(R.id.progressBar)
        val percent: TextView = view.findViewById(R.id.percentage)
        val deadline: TextView = view.findViewById(R.id.miniDeadline)
        val card: CardView = view.findViewById(R.id.cardView)
    }

    /**
     * ViewHolder for task items.
     */
    private class TaskViewHolder(view: View) {
        val name: TextView = view.findViewById(R.id.miniName)
        val progressBar: ProgressBar = view.findViewById(R.id.progressBar)
        val percent: TextView = view.findViewById(R.id.percentage)
        val dev: TextView = view.findViewById(R.id.miniDevName)
        val card: CardView = view.findViewById(R.id.cardView)
    }

    /**
     * Returns the list of items marked for deletion.
     */
    fun getDeleteItemTempList(): ArrayList<ItemsViewModel> {
        return deleteItemTempList
    }

    /**
     * Removes the specified items from the data list.
     * @param items The list of items to remove.
     */
    fun removeItems(items: ArrayList<ItemsViewModel>) {
        data.removeAll(items.toSet())
        notifyDataSetChanged()
    }

    /**
     * Enables or disables long-click functionality.
     * @param enabled Whether long-click is enabled.
     */
    fun setLongClickEnabled(enabled: Boolean) {
        isLongClickEnabled = enabled
        notifyDataSetChanged()
    }

    /**
     * Resets the background color of all cards and clears the deletion list.
     */
    fun resetCardBackgrounds(): Boolean {
        deleteItemTempList.clear()
        notifyDataSetChanged()
        return true
    }

    override fun getCount(): Int = data.size

    override fun getItem(position: Int): Any = data[position]

    override fun getItemId(position: Int): Long = position.toLong()

    /**
     * Creates and returns the view for each item in the grid.
     */
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val holder: Any
        val layoutRes = if (role == "DEV") R.layout.mini_subtask else R.layout.mini_task

        if (convertView == null) {
            // Inflate a new view only if convertView is null.
            view = layoutInflater.inflate(layoutRes, parent, false)
            holder = if (role == "DEV") {
                SubtaskViewHolder(view)
            } else {
                TaskViewHolder(view)
            }
            view.tag = holder // Store the ViewHolder in the view.
        } else {
            // Reuse the recycled view.
            view = convertView
            holder = view.tag as Any
        }

        val item = data[position]

        when (holder) {
            is SubtaskViewHolder -> {
                holder.name.text = item.taskName
                holder.progressBar.progress = item.progress
                holder.percent.text = "${item.progress}%"
                if (!isToggleChecked) {
                    holder.deadline.text = item.deadlineTimestamp.toString()
                }
                // Set the card background color.
                if (deleteItemTempList.contains(item)) {
                    holder.card.setCardBackgroundColor(Color.parseColor("#80FF9595"))
                } else {
                    holder.card.setCardBackgroundColor(null)
                }
            }
            is TaskViewHolder -> {
                // Logic for the "mini_task" layout.
                holder.name.text = if (isToggleChecked) item.taskName else item.subtaskName
                holder.progressBar.progress = item.progress
                holder.percent.text = "${item.progress}%"
                holder.dev.text = item.dev

                // Set the card background color.
                if (deleteItemTempList.contains(item)) {
                    holder.card.setCardBackgroundColor(Color.parseColor("#80FF9595"))
                } else {
                    holder.card.setCardBackgroundColor(null)
                }
            }
        }

        // Handle long-click events.
        view.setOnLongClickListener {
            if (isLongClickEnabled) {
                Log.d("GridAdapter", "Long click on item: ${item.taskName}")
                if (deleteItemTempList.contains(item)) {
                    secondClick((holder as? SubtaskViewHolder)?.card ?: (holder as? TaskViewHolder)?.card!!, item)
                } else {
                    firstClick((holder as? SubtaskViewHolder)?.card ?: (holder as? TaskViewHolder)?.card!!, item)
                }
                vibrateDevice()
                true // Return true to indicate the event was handled.
            } else {
                false
            }
        }

        // Handle normal click events when long-click is not enabled.
        view.setOnClickListener {
            if (!isLongClickEnabled) {
                // Logic for normal click.

                if (isSecondPage || (role == "DEV")) {
                    detailsProjects.setIsSecondPage()
                    val test = SecondPage(item, view.context, isToggleChecked, layoutInflater, taskName)
                    test.openPage(data, role)
                }
            }
        }
        return view
    }

    /**
     * Handles the first click on an item (marks it for deletion).
     */
    private fun firstClick(card: CardView, item: ItemsViewModel) {
        isCardInteracted = true
        card.setCardBackgroundColor(Color.parseColor("#80FF9595"))
        deleteItemTempList.add(item)
    }

    /**
     * Handles the second click on an item (unmarks it for deletion).
     */
    private fun secondClick(card: CardView, item: ItemsViewModel) {
        card.setCardBackgroundColor(null)
        deleteItemTempList.remove(item)
    }

    /**
     * Vibrates the device to provide feedback for long-click events.
     */
    private fun vibrateDevice() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(VibratorManager::class.java)
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(200)
            }
        }
    }
}