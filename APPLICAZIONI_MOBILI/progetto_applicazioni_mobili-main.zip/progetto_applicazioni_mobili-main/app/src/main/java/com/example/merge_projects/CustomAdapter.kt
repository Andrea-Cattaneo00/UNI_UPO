package com.example.merge_projects

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CustomAdapter(
    private val role: String,
    private val dataList: ArrayList<ItemsViewModel>,
    private val isToggleOn: Boolean?,
    private val context: Context,
    private val listener: OnItemClickListener?
) : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

        private val cardView: CardView = itemView.findViewById(R.id.cardView)
        // Fixed values (present in both project_card and subtask_card).
        val projectNameTextView: TextView = itemView.findViewById(R.id.title)
        val deadlineTextView: TextView = itemView.findViewById(R.id.deadlineTxt)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        val progressText: TextView = itemView.findViewById(R.id.percentage)

        init {
            cardView.setOnClickListener(this) // Attach click listener to this cardView.
        }

        override fun onClick(v: View?) {
            val position = bindingAdapterPosition
            if (position != RecyclerView.NO_POSITION) {
                if (role == "DEV" && isToggleOn == false) {
                    showSubtaskDetails(position)
                } else if (role == "DEV" && isToggleOn == true) {
                    val clickedItem = dataList[position]
                    val secondPage = SecondPage(clickedItem, context, isToggleOn, LayoutInflater.from(context), clickedItem.taskName)
                    secondPage.openPage(dataList, role)
                } else {
                    listener?.onItemClick(position)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = if (role == "DEV" && !isToggleOn!!) {
            LayoutInflater.from(parent.context).inflate(R.layout.subtask_card, parent, false)
        } else if (role == "PL" && !isToggleOn!!) {
            LayoutInflater.from(parent.context).inflate(R.layout.project_card, parent, false)
        } else {
            LayoutInflater.from(parent.context).inflate(R.layout.project_card, parent, false)
        }
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = dataList[position]
        when (role) {
            "PM" -> {
                holder.projectNameTextView.text = currentItem.projectName
                val responsibleTextView = holder.itemView.findViewById<TextView>(R.id.responsibleName)
                responsibleTextView.text = currentItem.PL
                val reminderBtn = holder.itemView.findViewById<ImageButton>(R.id.reminderBtn)
                reminderBtn.setOnClickListener {
                    Toast.makeText(context, "Reminder sent!", Toast.LENGTH_SHORT).show()
                    sendReminder(role, currentItem, context)
                }
            }
            "PL" -> {
                if (isToggleOn == false) {  // Set up the Task cards.
                    holder.projectNameTextView.text = currentItem.taskName
                    val descriptionLayout = holder.itemView.findViewById<RelativeLayout>(R.id.descriptionTask)
                    descriptionLayout.visibility = View.VISIBLE
                    val description = holder.itemView.findViewById<TextView>(R.id.description)
                    description.text = currentItem.description
                    val responsibleText = holder.itemView.findViewById<TextView>(R.id.responsibleText)
                    responsibleText.text = "Developer: "
                    val responsibleName = holder.itemView.findViewById<TextView>(R.id.responsibleName)
                    responsibleName.text = currentItem.dev
                    val priorityLayout = holder.itemView.findViewById<RelativeLayout>(R.id.priorityLayout)
                    priorityLayout.visibility = View.VISIBLE
                    val priorityText = holder.itemView.findViewById<TextView>(R.id.priority)
                    priorityText.text = currentItem.priority
                    when (priorityText.text) {
                        "High" -> priorityText.setTextColor(Color.parseColor("#FF0000"))
                        "Medium" -> priorityText.setTextColor(Color.parseColor("#FFA500"))
                        "Low" -> priorityText.setTextColor(Color.parseColor("#008000"))
                    }
                } else {
                    holder.projectNameTextView.text = currentItem.projectName
                    holder.itemView.findViewById<RelativeLayout>(R.id.infos).visibility = View.GONE
                    val reminderBtn = holder.itemView.findViewById<ImageButton>(R.id.reminderBtn)
                    reminderBtn.visibility = View.GONE
                }
            }
            "DEV" -> {
                if (isToggleOn == false) {  // Set up the Subtask cards.
                    setSubtaskCard(holder, currentItem, position)
                } else {   // Set up the Task cards.
                    holder.projectNameTextView.text = currentItem.taskName
                    val responsibleTextView = holder.itemView.findViewById<TextView>(R.id.responsibleName)
                    responsibleTextView.text = currentItem.PL
                    val reminderBtn = holder.itemView.findViewById<ImageButton>(R.id.reminderBtn)
                    reminderBtn.visibility = View.GONE
                    val priorityText = holder.itemView.findViewById<TextView>(R.id.priority)
                    priorityText.text = currentItem.priority
                    when (priorityText.text) {
                        "High" -> priorityText.setTextColor(Color.parseColor("#FF0000"))
                        "Medium" -> priorityText.setTextColor(Color.parseColor("#FFA500"))
                        "Low" -> priorityText.setTextColor(Color.parseColor("#008000"))
                    }
                }
            }
        }
        holder.deadlineTextView.text = formatDate(currentItem.deadlineTimestamp)
        holder.progressBar.progress = currentItem.progress
        holder.progressText.text = "${currentItem.progress}%"
    }

    /**
     * Sets up the subtask card with the provided data.
     * @param holder The ViewHolder for the subtask card.
     * @param currentItem The current subtask item.
     * @param position The position of the item in the list.
     */
    private fun setSubtaskCard(holder: ViewHolder, currentItem: ItemsViewModel, position: Int) {
        holder.projectNameTextView.text = currentItem.subtaskName
        val descriptionTextView: TextView = holder.itemView.findViewById(R.id.description)
        val priority: TextView = holder.itemView.findViewById(R.id.subPriority)
        descriptionTextView.text = currentItem.description
        priority.text = currentItem.priority
        when (priority.text) {
            "High" -> priority.setTextColor(Color.parseColor("#FF0000"))
            "Medium" -> priority.setTextColor(Color.parseColor("#FFA500"))
            "Low" -> priority.setTextColor(Color.parseColor("#008000"))
        }
        val increaseBtn = holder.itemView.findViewById<ImageButton>(R.id.increasePercentage)
        val decreaseBtn = holder.itemView.findViewById<ImageButton>(R.id.decreasePercentage)
        increaseBtn.setOnClickListener { increaseSubPercentage(position) }
        decreaseBtn.setOnClickListener { decreaseSubPercentage(position) }
    }

    /**
     * Increases the progress percentage of a subtask.
     * @param position The position of the subtask in the list.
     */
    private fun increaseSubPercentage(position: Int) {
        if (dataList[position].progress + 25 <= 100) {   // Ensure progress does not exceed 100.
            val api = API()
            api.increaseSubPercentage(dataList[position].subtaskName) { outcome ->
                if (outcome) {
                    dataList[position].progress += 25
                    notifyItemChanged(position)
                    if (checkProgress(position)) {
                        api.updateTaskProgress(dataList[position].taskName, dataList[position].projectName) { result ->
                            setNotification(result, position)
                        }
                        Log.d("Subtask", "Subtask completed at 100%")
                    }
                    Log.d("Progress", "Progress increased successfully!")
                }
            }
        }
    }

    /**
     * Sends a notification based on the result of the progress update.
     * @param result The result of the progress update.
     * @param position The position of the item in the list.
     */
    private fun setNotification(result: Int, position: Int) {
        val messageTitle: String
        val messageBody: String
        when (result) {
            2 -> {
                messageTitle = "Project completed!"
                messageBody = "The task '${dataList[position].taskName}' in project '${dataList[position].projectName}' has been completed!"
                getUserToken(dataList[position].PM, "PM") { token ->
                    if (token != null) {
                        CoroutineScope(Dispatchers.IO).launch {
                            val accessToken = getAccessToken(context)
                            sendNotification(token, messageTitle, messageBody, accessToken)
                        }
                    } else {
                        Log.d("Token", "Error occurred during user token fetching.")
                    }
                }
            }
            1 -> {
                messageTitle = "Task completed!"
                messageBody = "The task '${dataList[position].taskName}' in project '${dataList[position].projectName}' has been completed!"
                getUserToken(dataList[position].PL, "PL") { token ->
                    if (token != null) {
                        CoroutineScope(Dispatchers.IO).launch {
                            val accessToken = getAccessToken(context)
                            sendNotification(token, messageTitle, messageBody, accessToken)
                        }
                    } else {
                        Log.d("Token", "Error occurred during user token fetching.")
                    }
                }
            }
            0 -> {
                return
            }
        }
    }

    /**
     * Decreases the progress percentage of a subtask.
     * @param position The position of the subtask in the list.
     */
    private fun decreaseSubPercentage(position: Int) {
        if (dataList[position].progress - 25 >= 0) {     // Ensure progress does not go below 0.
            val api = API()
            api.decreaseSubPercentage(dataList[position].subtaskName) { outcome ->
                if (outcome) {
                    dataList[position].progress -= 25
                    notifyItemChanged(position)
                    Log.d("Progress", "Progress decreased successfully!")
                    api.updateTaskProgress(dataList[position].taskName, dataList[position].projectName) { onComplete ->
                        if (onComplete == null) {
                            Log.d("Error", "Error during task progress decrease update.")
                            return@updateTaskProgress
                        }
                    }
                } else {
                    Log.d("Error", "Error during progress update process!")
                }
            }
        }
    }

    /**
     * Checks if the progress of a subtask is 100%.
     * @param position The position of the subtask in the list.
     * @return True if progress is 100%, otherwise false.
     */
    private fun checkProgress(position: Int): Boolean {
        return dataList[position].progress == 100
    }

    /**
     * Formats a timestamp into a readable date string.
     * @param timestamp The timestamp to format.
     * @return The formatted date string.
     */
    private fun formatDate(timestamp: Timestamp): String {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = timestamp.time
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }

    /**
     * Displays subtask details in a dialog.
     * @param position The position of the subtask in the list.
     */
    private fun showSubtaskDetails(position: Int) {
        val builder = android.app.AlertDialog.Builder(context)
        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.subtask_details, null)
        builder.setView(dialogView)
        val alertDialog = builder.create()

        val item = dataList[position]

        val textTaskName = dialogView.findViewById<TextView>(R.id.name)
        val textDeadline = dialogView.findViewById<TextView>(R.id.deadlineTxt)
        val progressbar = dialogView.findViewById<ProgressBar>(R.id.progressBar)
        val descriptionView = dialogView.findViewById<TextView>(R.id.taskDescription)
        val devView = dialogView.findViewById<TextView>(R.id.taskDev)
        val devIcon = dialogView.findViewById<ImageView>(R.id.profilePic)
        devIcon.visibility = View.GONE
        devView.visibility = View.GONE  // Hide the dev field as it is the user themselves.

        textTaskName.text = if (isToggleOn == true) item.taskName else item.subtaskName
        textDeadline.text = item.deadlineTimestamp.toString()
        progressbar.progress = item.progress
        descriptionView.text = item.description
        val priority = dialogView.findViewById<TextView>(R.id.priorityTxt)
        priority.text = item.priority

        when (priority.text.toString().trim()) {
            "High" -> priority.setTextColor(ContextCompat.getColor(context, R.color.high_priority))
            "Medium" -> priority.setTextColor(ContextCompat.getColor(context, R.color.medium_priority))
            "Low" -> priority.setTextColor(ContextCompat.getColor(context, R.color.low_priority))
        }
        alertDialog.show()
    }
}