package com.example.merge_projects

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.ToggleButton
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth

class Home : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var navHeaderUsername: TextView
    private var userRole: String = ""
    private lateinit var newSomethingBtn: Button
    private lateinit var filterButton: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var projectManager: ProjectManager
    private lateinit var projectLeader: ProjectLeader
    private var email: String = ""
    private var isFilterActive: Boolean = false
    private lateinit var clearFiltersButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)

        // Initialize UI elements
        filterButton = findViewById(R.id.filterButton)
        clearFiltersButton = findViewById(R.id.clearFiltersButton)
        clearFiltersButton.visibility = View.GONE

        // Retrieve email and role from the intent
        this.email = intent.getStringExtra("email").toString()
        userRole = intent.getStringExtra("role").toString()

        // Initialize ProjectManager and ProjectLeader
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        projectManager = ProjectManager(recyclerView, this)
        projectLeader = ProjectLeader(recyclerView, this)

        // Set up the sidebar and redirect to the correct screen based on the user's role
        setUpSideBar(email)
        when (userRole) {
            "PM" -> setPmScreen(email)
            "PL" -> setPlScreen(email)
            "DV" -> setDeveloperScreen(email)
        }

        // Set up the filter button listener
        filterButton.setOnClickListener {
            val bottomSheet = FiltersBottomSheet.newInstance(userRole) { filters ->
                if (filters.isNotEmpty()) {
                    applyFilters(filters)
                } else {
                    resetFilters()
                    if (userRole == "PL") {
                        val toggleButton = findViewById<ToggleButton>(R.id.ToggleButton)
                        toggleButton.isChecked = false
                    }
                }
            }
            bottomSheet.show(supportFragmentManager, "FiltersBottomSheet")
        }

        // Set up the clear filters button listener
        clearFiltersButton.setOnClickListener {
            resetFilters()
        }

        // Load initial data
        loadInitialData(email)
    }

    /**
     * Applies the selected filters to the RecyclerView based on the user's role.
     *
     * @param filters A map of filters to apply.
     */
    private fun applyFilters(filters: Map<String, Any?>) {
        when (userRole) {
            "PM" -> projectManager.applyFilters(filters)
            "PL" -> projectLeader.applyFilters(filters)
        }
        isFilterActive = true
        updateClearFilterButtonVisibility()
    }

    /**
     * Resets the filters and updates the RecyclerView based on the user's role.
     */
    private fun resetFilters() {
        when (userRole) {
            "PM" -> projectManager.resetFilters()
            "PL" -> {
                val toggleButton = findViewById<ToggleButton>(R.id.ToggleButton)
                Log.d("ToggleButtonState", "ToggleButton isChecked: ${toggleButton.isChecked}")
                projectLeader.resetFilters(!toggleButton.isChecked)
            }
        }
        isFilterActive = false
        updateClearFilterButtonVisibility()
    }

    /**
     * Updates the visibility of the clear filters button based on whether filters are active.
     */
    private fun updateClearFilterButtonVisibility() {
        clearFiltersButton.visibility = if (isFilterActive) View.VISIBLE else View.GONE
    }

    /**
     * Loads the initial data into the RecyclerView based on the user's role.
     *
     * @param email The email of the logged-in user.
     */
    fun loadInitialData(email: String) {
        when (userRole) {
            "PM" -> projectManager.setUpRecycler(email)
            "PL" -> projectLeader.setUpRecycler(email, true)
        }
    }

    /**
     * Sets up the navigation drawer (sidebar) with the user's email and menu items.
     *
     * @param email The email of the logged-in user.
     */
    private fun setUpSideBar(email: String) {
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        toggle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        val headerView = navView.getHeaderView(0)
        navHeaderUsername = headerView.findViewById(R.id.nav_header_email)
        navHeaderUsername.text = email

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {}
                R.id.nav_chat -> {
                    val intent = Intent(this, SearchUserActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_logout -> logoutUser()
            }
            drawerLayout.closeDrawers()
            true
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (toggle.onOptionsItemSelected(item)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    /**
     * Logs out the user and redirects to the MainActivity.
     */
    private fun logoutUser() {
        FirebaseAuth.getInstance().signOut()
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    /**
     * Sets up the screen for the Project Manager (PM) role.
     *
     * @param email The email of the logged-in user.
     */
    @SuppressLint("SetTextI18n")
    private fun setPmScreen(email: String) {
        val newFormActivity = NewProjectFormActivity(this, layoutInflater, this, isToggleChecked = false)

        newSomethingBtn = findViewById(R.id.newSomethingBtn)
        newSomethingBtn.setOnClickListener { newFormActivity.showAlert(userRole) }
        newSomethingBtn.text = "New Project"

        projectManager.setUpRecycler(email)
    }

    /**
     * Sets up the screen for the Project Leader (PL) role.
     *
     * @param email The email of the logged-in user.
     */
    @SuppressLint("SetTextI18n")
    private fun setPlScreen(email: String) {
        newSomethingBtn = findViewById(R.id.newSomethingBtn)
        newSomethingBtn.visibility = View.GONE

        // Show the ToggleButton only for PL
        val typeRecyclerToggleBtn = findViewById<ToggleButton>(R.id.ToggleButton)
        typeRecyclerToggleBtn.visibility = View.VISIBLE

        // Configure the ToggleButton text for PL
        typeRecyclerToggleBtn.textOn = "Project"
        typeRecyclerToggleBtn.textOff = "Task"
        typeRecyclerToggleBtn.isChecked = true // Set initial state to "Project"

        // Set the initial state of the RecyclerView (show projects)
        projectLeader.setUpRecycler(email, true)

        val filterBtn = findViewById<Button>(R.id.filterButton)

        // Handle ToggleButton state changes
        typeRecyclerToggleBtn.setOnCheckedChangeListener { _, isChecked ->
            Log.d("ToggleButton", "ToggleButton state changed: $isChecked")
            if (isChecked) {
                filterBtn.visibility = View.GONE
                // Show projects
                projectLeader.setUpRecycler(email, true)
            } else {
                filterBtn.visibility = View.VISIBLE
                // Show tasks
                projectLeader.setUpRecycler(email, false)
            }
        }
    }

    /**
     * Sets up the screen for the Developer (DV) role.
     *
     * @param email The email of the logged-in user.
     */
    @SuppressLint("SetTextI18n")
    private fun setDeveloperScreen(email: String) {
        newSomethingBtn = findViewById(R.id.newSomethingBtn)
        newSomethingBtn.visibility = View.GONE
        filterButton.visibility = View.GONE

        // Show the ToggleButton only for DV
        val typeRecyclerToggleBtn = findViewById<ToggleButton>(R.id.ToggleButton)
        typeRecyclerToggleBtn.visibility = View.VISIBLE

        // Configure the ToggleButton text for DV
        typeRecyclerToggleBtn.textOn = "Task"
        typeRecyclerToggleBtn.textOff = "SubTask"
        typeRecyclerToggleBtn.isChecked = true // Set initial state to "Task"

        // Set the initial state of the RecyclerView (show tasks)
        val dev = Developer(recyclerView, this)
        dev.setUpRecycler(email, true)

        // Handle ToggleButton state changes
        typeRecyclerToggleBtn.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Show tasks
                dev.setUpRecycler(email, true)
            } else {
                // Show subtasks
                dev.setUpRecycler(email, false)
            }
        }
    }

    /**
     * Returns the email of the logged-in user.
     *
     * @return The email of the logged-in user.
     */
    fun getEmail(): String {
        return this.email
    }
}