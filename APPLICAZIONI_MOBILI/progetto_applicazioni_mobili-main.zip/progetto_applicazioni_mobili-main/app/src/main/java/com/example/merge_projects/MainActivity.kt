package com.example.merge_projects

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var interactButton: Button
    private lateinit var roleArea: LinearLayout
    private lateinit var roleGroup: RadioGroup
    private lateinit var titleForm: TextView
    private lateinit var userSelection: RadioButton

    /**
     * Initializes the activity and sets up the UI components.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        // Initialize views.
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        interactButton = findViewById(R.id.interactionButton)
        roleArea = findViewById(R.id.userRoleArea)
        roleGroup = findViewById(R.id.roleButtonGroup)
        titleForm = findViewById(R.id.title)

        // Get a reference to the register button.
        val registerButton = findViewById<Button>(R.id.registerButton)

        // Listener to toggle between login and sign-up forms.
        registerButton.setOnClickListener {
            if (registerButton.text == "Sign up") {
                registerButton.setText(R.string.logIn)
                roleArea.visibility = View.VISIBLE
                interactButton.setText(R.string.signIn)
                titleForm.setText(R.string.signIn)
            } else {
                registerButton.setText(R.string.signIn)
                registerButton.visibility = View.VISIBLE
                roleArea.visibility = View.GONE
                interactButton.setText(R.string.logIn)
                titleForm.setText(R.string.logIn)
            }
        }

        // Listener to update the selected user role.
        roleGroup.setOnCheckedChangeListener { group, checkedID ->
            userSelection = findViewById(checkedID)
        }

        // Listener for the central button (login or sign-up).
        interactButton.setOnClickListener {
            val emailText = email.text.toString()
            val passwordText = password.text.toString()

            if (interactButton.text == "Log in") {
                doLogin(emailText, passwordText)
            } else if (interactButton.text == "Sign up") {
                doSignUp(emailText, passwordText)
            }
        }
    }

    /**
     * Handles user sign-up.
     * @param email The user's email.
     * @param password The user's password.
     */
    private fun doSignUp(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Sign-up successful, get the user ID.
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        // Save user data in Firestore.

                        FirebaseMessaging.getInstance().token.addOnCompleteListener { token ->
                            if (token.isSuccessful) {
                                val token = token.result

                                val user = mapOf(
                                    "email" to email,
                                    "password" to password,
                                    "role" to resources.getResourceEntryName(userSelection.id),
                                    "userId" to userId, // Add the user ID.
                                    "token" to token,
                                )

                                db.collection("users")
                                    .document(userId) // Use the user ID as the document ID.
                                    .set(user)
                                    .addOnSuccessListener {
                                        Log.d(TAG, "User registered successfully!")
                                        redirectUser(user["role"].toString(), email)
                                    }
                                    .addOnFailureListener { e ->
                                        Log.w(TAG, "Error during registration", e)
                                    }
                            } else {
                                Log.w(TAG, "Error during FCM token fetching")
                            }
                        }
                    }
                } else {
                    Log.w(TAG, "Sign-up failed", task.exception)
                    Toast.makeText(
                        this,
                        "Sign-up failed: ${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    /**
     * Handles user login.
     * @param email The user's email.
     * @param password The user's password.
     */
    private fun doLogin(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Login successful, get the user ID.
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        // Retrieve user data from Firestore.
                        db.collection("users")
                            .document(userId)
                            .get()
                            .addOnSuccessListener { document ->
                                if (document.exists()) {
                                    val role = document.getString("role")
                                    redirectUser(role, email)
                                } else {
                                    Log.w(TAG, "User not found in the database")
                                }
                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error retrieving user data", e)
                            }
                    }
                } else {
                    Log.w(TAG, "Login failed", task.exception)
                    Toast.makeText(
                        this,
                        "Login failed: ${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    /**
     * Redirects the user based on their role.
     * @param role The user's role (PM, PL, DV).
     * @param email The user's email.
     */
    private fun redirectUser(role: String?, email: String) {
        val intent = when (role) {
            "PM" -> Intent(this, Home::class.java)
            "PL" -> Intent(this, Home::class.java)
            "DV" -> Intent(this, Home::class.java)
            else -> null
        }
        intent?.putExtra("email", email)
        intent?.putExtra("role", role)
        intent?.let {
            startActivity(it)
            finish()
        }
    }
}