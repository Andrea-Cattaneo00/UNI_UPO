package com.example.merge_projects

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import java.sql.Timestamp
import java.util.ArrayList

class ProjectManager(
    private val recyclerView: RecyclerView,
    private val context: Context
) {

    private var data: ArrayList<ItemsViewModel> = ArrayList()

    /**
     * Sets up the RecyclerView with projects for the Project Manager (PM).
     * @param email The email of the Project Manager.
     * @return True if projects are found, otherwise false.
     */
    fun setUpRecycler(email: String): Boolean {
        val api = API()
        var result = true

        api.getAllProjects(email, "PM") { projects ->
            if (projects.isEmpty()) {
                result = false
                Log.d("ProjectManager", "No projects found for PM: $email")
            } else {
                data.clear()
                data.addAll(projects)
                Log.d("ProjectManager", "Projects found: ${projects.size}")
                distributeProjectsToRecyclerViews(data)
            }
        }
        return result
    }

    /**
     * Applies filters to the data and updates the RecyclerView.
     * @param filters A map of filters to apply (state, pl, deadline).
     */
    fun applyFilters(filters: Map<String, Any?>) {
        val filteredData = data.filter { project ->
            val matchesState = filters["state"]?.let { state ->
                when (state) {
                    "Started" -> project.progress > 0 && project.progress < 100
                    "NotStarted" -> project.progress == 0
                    "Finished" -> project.progress == 100
                    else -> true
                }
            } ?: true

            val matchesPL = filters["pl"]?.let { pl ->
                project.PL == pl
            } ?: true

            val matchesDeadline = filters["deadline"]?.let { deadline ->
                project.deadlineTimestamp <= deadline as Timestamp
            } ?: true

            matchesState && matchesPL && matchesDeadline
        }

        distributeProjectsToRecyclerViews(filteredData)
    }

    /**
     * Resets the filters and updates the RecyclerView with the original data.
     */
    fun resetFilters() {
        distributeProjectsToRecyclerViews(data)
    }

    /**
     * Distributes projects to the RecyclerView and sets up the adapter.
     * @param data The list of projects to display.
     */
    private fun distributeProjectsToRecyclerViews(data: List<ItemsViewModel>) {
        val projects = ArrayList(data)
        val adapter = CustomAdapter("PM", projects, null, context, null)
        recyclerView.adapter = adapter
    }
}