package com.example.merge_projects.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.merge_projects.model.ChatMessageModel
import com.example.merge_projects.utils.FirebaseUtil
import com.example.merge_projects.R
import com.firebase.ui.firestore.FirestoreRecyclerAdapter
import com.firebase.ui.firestore.FirestoreRecyclerOptions

class ChatRecyclerAdapter(
    options: FirestoreRecyclerOptions<ChatMessageModel>,
    private val context: Context
) : FirestoreRecyclerAdapter<ChatMessageModel, ChatRecyclerAdapter.ChatModelViewHolder>(options) {

    /**
     * Binds the chat message data to the ViewHolder.
     * @param holder The ViewHolder to bind the data to.
     * @param position The position of the item in the dataset.
     * @param model The chat message model containing the data.
     */
    override fun onBindViewHolder(holder: ChatModelViewHolder, position: Int, model: ChatMessageModel) {
        println("Binding message: ${model.message} from sender: ${model.senderId}")
        println("Message at position $position: ${model.message} with timestamp: ${model.timestamp}")

        if (model.message.isNullOrEmpty()) {
            println("Error: The message is empty or null!")
            return
        }

        if (model.senderId == FirebaseUtil.currentUserId()) {
            // If the message is sent by the current user, show the right layout
            holder.leftChatLayout.visibility = View.GONE
            holder.rightChatLayout.visibility = View.VISIBLE
            holder.rightChatTextView.text = model.message
        } else {
            // If the message is sent by another user, show the left layout
            holder.rightChatLayout.visibility = View.GONE
            holder.leftChatLayout.visibility = View.VISIBLE
            holder.leftChatTextView.text = model.message
        }

        // Force layout measurement and layout pass
        holder.leftChatLayout.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        holder.leftChatLayout.layout(0, 0, holder.leftChatLayout.measuredWidth, holder.leftChatLayout.measuredHeight)

        holder.rightChatLayout.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        holder.rightChatLayout.layout(0, 0, holder.rightChatLayout.measuredWidth, holder.rightChatLayout.measuredHeight)

        // Log the heights of the layouts
        println("Left layout height: ${holder.leftChatLayout.height}")
        println("Right layout height: ${holder.rightChatLayout.height}")
    }

    /**
     * Creates a new ViewHolder for the chat message item.
     * @param parent The parent ViewGroup.
     * @param viewType The type of the view.
     * @return A new ChatModelViewHolder instance.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatModelViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.chat_message_recycler_row, parent, false)
        return ChatModelViewHolder(view)
    }

    /**
     * ViewHolder class for the chat message item.
     * @param itemView The view of the chat message item.
     */
    inner class ChatModelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val leftChatLayout: LinearLayout = itemView.findViewById(R.id.left_chat_layout)
        val rightChatLayout: LinearLayout = itemView.findViewById(R.id.right_chat_layout)
        val leftChatTextView: TextView = itemView.findViewById(R.id.left_chat_textview)
        val rightChatTextView: TextView = itemView.findViewById(R.id.right_chat_textview)
    }
}
