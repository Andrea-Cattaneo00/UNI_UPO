package com.example.merge_projects

import java.sql.Timestamp

// Data class representing a view model for items (projects, tasks, subtasks)
data class ItemsViewModel(
    val projectName: String = "",
    val taskName: String = "",
    val subtaskName: String = "",
    val PM: String = "",
    val PL: String = "",
    val dev: String = "",
    val deadlineTimestamp: Timestamp = Timestamp(0),
    var progress: Int = 0,
    val description: String = "",
    val priority: String = ""
) {
    val state: String
        get() = when {
            progress == 0 -> "NotStarted"
            progress in 1..99 -> "Started"
            progress == 100 -> "Finished"
            else -> "Unknown"
        }
}