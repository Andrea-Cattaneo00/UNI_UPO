package com.example.merge_projects

interface OnItemClickListener {

    fun onItemClick(position: Int)

}