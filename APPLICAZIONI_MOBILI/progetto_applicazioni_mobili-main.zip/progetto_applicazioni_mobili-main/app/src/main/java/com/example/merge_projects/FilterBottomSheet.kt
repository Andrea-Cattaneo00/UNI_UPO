package com.example.merge_projects

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.sql.Timestamp
import java.util.Calendar

class FiltersBottomSheet(
    private val onApplyFilters: (filters: Map<String, Any?>) -> Unit
) : BottomSheetDialogFragment() {

    private var selectedDeadline: Timestamp? = null
    private lateinit var role: String

    companion object {
        private const val ARG_ROLE = "role"

        /**
         * Creates a new instance of FiltersBottomSheet with the specified role and callback.
         *
         * @param role The role of the user (e.g., "PM", "PL", "DV").
         * @param onApplyFilters Callback to be invoked when filters are applied.
         * @return A new instance of FiltersBottomSheet.
         */
        fun newInstance(role: String, onApplyFilters: (Map<String, Any?>) -> Unit): FiltersBottomSheet {
            val fragment = FiltersBottomSheet(onApplyFilters)
            val args = Bundle()
            args.putString(ARG_ROLE, role)
            fragment.arguments = args
            return fragment
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.bottom_sheet_filters, container, false)

        // Get the role from the arguments
        role = arguments?.getString(ARG_ROLE) ?: "PM"

        // References to UI elements
        val filterStarted = view.findViewById<CheckBox>(R.id.filterStarted)
        val filterNotStarted = view.findViewById<CheckBox>(R.id.filterNotStarted)
        val filterFinished = view.findViewById<CheckBox>(R.id.filterFinished)
        val plEditText = view.findViewById<EditText>(R.id.filterPL)
        val devEditText = view.findViewById<EditText>(R.id.filterDev)
        val priorityCheckboxGroup = view.findViewById<LinearLayout>(R.id.priorityCheckboxGroup)
        val filterPriorityLow = view.findViewById<CheckBox>(R.id.filterPriorityLow)
        val filterPriorityMedium = view.findViewById<CheckBox>(R.id.filterPriorityMedium)
        val filterPriorityHigh = view.findViewById<CheckBox>(R.id.filterPriorityHigh)
        val deadlineButton = view.findViewById<Button>(R.id.deadlineButton)
        val applyButton = view.findViewById<Button>(R.id.applyFiltersButton)

        // Show or hide filters based on the role
        when (role) {
            "PM" -> {
                // Show filters for PM: status, PL, deadline
                view.findViewById<TextView>(R.id.filterPLTitle).visibility = View.VISIBLE
                plEditText.visibility = View.VISIBLE
                view.findViewById<TextView>(R.id.deadlineTitle).visibility = View.VISIBLE
                deadlineButton.visibility = View.VISIBLE

                // Hide filters specific to PL
                view.findViewById<TextView>(R.id.filterDevTitle).visibility = View.GONE
                devEditText.visibility = View.GONE
                view.findViewById<TextView>(R.id.filterPriorityTitle).visibility = View.GONE
                priorityCheckboxGroup.visibility = View.GONE
            }
            "PL" -> {
                // Show filters for PL: status, DV, deadline, priority
                view.findViewById<TextView>(R.id.filterDevTitle).visibility = View.VISIBLE
                devEditText.visibility = View.VISIBLE
                view.findViewById<TextView>(R.id.filterPriorityTitle).visibility = View.VISIBLE
                priorityCheckboxGroup.visibility = View.VISIBLE
                view.findViewById<TextView>(R.id.deadlineTitle).visibility = View.VISIBLE
                deadlineButton.visibility = View.VISIBLE

                // Hide filters specific to PM
                view.findViewById<TextView>(R.id.filterPLTitle).visibility = View.GONE
                plEditText.visibility = View.GONE
            }
            "DV" -> {
                // Hide all filters for DV
                view.findViewById<TextView>(R.id.filterPLTitle).visibility = View.GONE
                plEditText.visibility = View.GONE
                view.findViewById<TextView>(R.id.filterDevTitle).visibility = View.GONE
                devEditText.visibility = View.GONE
                view.findViewById<TextView>(R.id.filterPriorityTitle).visibility = View.GONE
                priorityCheckboxGroup.visibility = View.GONE
                view.findViewById<TextView>(R.id.deadlineTitle).visibility = View.GONE
                deadlineButton.visibility = View.GONE
            }
        }

        // Handle date picker dialog
        deadlineButton.setOnClickListener {
            showDatePickerDialog { date ->
                selectedDeadline = Timestamp(date.time)
                deadlineButton.text = formatDate(date)
            }
        }

        // Apply filters
        applyButton.setOnClickListener {
            val selectedFilters = mutableMapOf<String, Any?>()

            // Common filters for PM and PL: status
            if (filterStarted.isChecked) selectedFilters["state"] = "Started"
            if (filterNotStarted.isChecked) selectedFilters["state"] = "NotStarted"
            if (filterFinished.isChecked) selectedFilters["state"] = "Finished"

            // Role-specific filters
            when (role) {
                "PM" -> {
                    val plFilter = plEditText.text.toString()
                    if (plFilter.isNotEmpty()) selectedFilters["pl"] = plFilter
                }
                "PL" -> {
                    val devFilter = devEditText.text.toString()
                    if (devFilter.isNotEmpty()) selectedFilters["dev"] = devFilter

                    // Priority filters (checkboxes)
                    val priorities = mutableListOf<String>()
                    if (filterPriorityLow.isChecked) priorities.add("Low")
                    if (filterPriorityMedium.isChecked) priorities.add("Medium")
                    if (filterPriorityHigh.isChecked) priorities.add("High")
                    if (priorities.isNotEmpty()) selectedFilters["priority"] = priorities
                }
            }

            // Deadline filter (only for PM and PL)
            if (selectedDeadline != null && role != "DV") selectedFilters["deadline"] = selectedDeadline

            onApplyFilters(selectedFilters)
            dismiss()
        }

        return view
    }

    /**
     * Displays a date picker dialog and invokes the callback when a date is selected.
     *
     * @param onDateSelected Callback to be invoked with the selected date.
     */
    private fun showDatePickerDialog(onDateSelected: (java.util.Date) -> Unit) {
        val calendar = Calendar.getInstance()
        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, dayOfMonth)
                onDateSelected(selectedDate.time)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    /**
     * Formats the given date into a string in the format "dd/MM/yyyy".
     *
     * @param date The date to format.
     * @return The formatted date string.
     */
    private fun formatDate(date: java.util.Date): String {
        val cal = Calendar.getInstance().apply { time = date }
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        return "$day/$month/$year"
    }
}