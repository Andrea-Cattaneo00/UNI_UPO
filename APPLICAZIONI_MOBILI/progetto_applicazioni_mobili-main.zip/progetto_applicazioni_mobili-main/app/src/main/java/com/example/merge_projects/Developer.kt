package com.example.merge_projects

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class Developer(
    private val recyclerView: RecyclerView,
    private val context: Context
) {

    private var data: ArrayList<ItemsViewModel> = ArrayList()

    /**
     * Sets up the RecyclerView with tasks or subtasks based on the toggle state.
     * @param email The email of the developer.
     * @param isToggleChecked Indicates whether to load tasks (true) or subtasks (false).
     */
    fun setUpRecycler(email: String, isToggleChecked: Boolean) {
        val api = API()

        if (isToggleChecked) {
            // Load tasks for the developer.
            api.getAllTaskForDev(email) { tasks ->
                if (tasks.isEmpty()) {
                    // Display a message if there are no tasks.
                    Log.i("Developer", "No tasks found for developer: $email")
                } else {
                    data.clear()
                    data.addAll(tasks)
                    distributeTasksToRecyclerViews(tasks, true)
                }
            }
        } else {
            // Load subtasks for the developer.
            api.getAllSubtasks(email) { subtasks ->
                if (subtasks.isEmpty()) {
                    // Display a message if there are no subtasks.
                    Log.i("Developer", "No subtasks found for developer: $email")
                } else {
                    data.clear()
                    data.addAll(subtasks)
                    distributeTasksToRecyclerViews(subtasks, false)
                }
            }
        }
    }

    /**
     * Distributes tasks or subtasks to the RecyclerView and sets up the adapter.
     * @param data The list of tasks or subtasks to display.
     * @param isTask Indicates whether the data consists of tasks (true) or subtasks (false).
     */
    private fun distributeTasksToRecyclerViews(data: List<ItemsViewModel>, isTask: Boolean) {
        val adapter = CustomAdapter(
            "DEV",
            data as ArrayList<ItemsViewModel>,
            isTask,
            context,
            object : OnItemClickListener {
                override fun onItemClick(position: Int) {
                    val clickedItem = data[position]
                    val intent = Intent(context, DetailsProjects::class.java)
                    intent.putExtra("role", "DEV")
                    if (isTask) {
                        intent.putExtra("taskName", clickedItem.taskName)
                    } else {
                        intent.putExtra("subtaskName", clickedItem.subtaskName)
                    }
                    intent.putExtra("isToggleChecked", true)
                    intent.putExtra("deadline", clickedItem.deadlineTimestamp.time)
                    intent.putExtra("progress", clickedItem.progress)
                    intent.putExtra("description", clickedItem.description)
                    intent.putExtra("dev", clickedItem.dev)
                    context.startActivity(intent)
                }
            }
        )
        recyclerView.adapter = adapter
    }
}
