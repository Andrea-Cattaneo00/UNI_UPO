package com.example.merge_projects.model

import com.google.firebase.Timestamp

/**
 * Represents a chat message in the application.
 *
 * @property message The content of the message.
 * @property senderId The ID of the user who sent the message.
 * @property timestamp The timestamp when the message was sent. Defaults to null.
 */
data class ChatMessageModel(
    var message: String = "",
    var senderId: String = "",
    var timestamp: Timestamp? = null
)