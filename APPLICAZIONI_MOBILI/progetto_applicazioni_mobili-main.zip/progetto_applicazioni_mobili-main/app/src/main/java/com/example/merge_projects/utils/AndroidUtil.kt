package com.example.merge_projects.utils

import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.merge_projects.model.UserModel

object AndroidUtil {

    // Funzione per mostrare un toast
    @JvmStatic
    fun showToast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    // Funzione per passare un UserModel come extra in un Intent
    @JvmStatic
    fun passUserModelAsIntent(intent: Intent, model: UserModel) {
        intent.putExtra("email", model.email)
        intent.putExtra("role", model.role)
        intent.putExtra("userId", model.userId)
    }

    fun getUserModelFromIntent(intent: Intent): UserModel {
        val userModel = UserModel()

        userModel.email = intent.getStringExtra("email").toString()
        userModel.role = intent.getStringExtra("role").toString()
        userModel.userId = intent.getStringExtra("userId").toString()

        return userModel
    }

}
