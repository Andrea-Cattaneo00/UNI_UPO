package com.example.merge_projects

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat

/**
 * Class responsible for handling the second page of the application,
 * which displays task or subtask details and allows editing.
 *
 * @param item The data model for the task or subtask.
 * @param context The application context.
 * @param isToggleChecked Indicates whether the toggle is checked (used to determine the layout).
 * @param layoutInflater The layout inflater for creating views.
 * @param taskName The name of the task (used for subtask operations).
 */
class SecondPage(
    private val item: ItemsViewModel,
    private val context: Context,
    private val isToggleChecked: Boolean, // Indicates whether the toggle is checked
    private val layoutInflater: LayoutInflater,
    private val taskName: String,
) {

    private val api = API() // API instance for network operations
    private val datas: ArrayList<ItemsViewModel> = ArrayList() // Data list for GridView
    private lateinit var dialogView: View // View for the dialog
    private var gridView: GridView? = null // GridView for subtasks (nullable)

    /**
     * Opens the second page (dialog) to display task or subtask details.
     *
     * @param data The list of items to display in the GridView (if applicable).
     * @param role The role of the user (e.g., "PM", "PL", "DEV").
     */
    fun openPage(data: ArrayList<ItemsViewModel>, role: String) {
        val builder = AlertDialog.Builder(context)
        val inflater = LayoutInflater.from(context)

        // Inflate the correct layout based on isToggleChecked
        dialogView = if (isToggleChecked) {
            inflater.inflate(R.layout.task_page, null).also {
                gridView = it.findViewById(R.id.subtasksGrid) // Initialize GridView for task_page
            }
        } else {
            inflater.inflate(R.layout.subtask_details, null) // Do not initialize GridView for subtask_details
        }

        builder.setView(dialogView)
        val alertDialog = builder.create()

        // Initialize views after inflating the correct layout
        val textTaskName = dialogView.findViewById<TextView>(R.id.name)
        val textDeadline = dialogView.findViewById<TextView>(R.id.deadlineTxt)
        val progressbar = dialogView.findViewById<ProgressBar>(R.id.progressBar)
        val descriptionView = dialogView.findViewById<TextView>(R.id.taskDescription)
        val devView = dialogView.findViewById<TextView>(R.id.taskDev)

        // Set common view values
        textTaskName.text = if (isToggleChecked) item.taskName else item.subtaskName
        textDeadline.text = item.deadlineTimestamp.toString()
        progressbar.progress = item.progress
        descriptionView.text = item.description

        val hideButton = dialogView.findViewById<LinearLayout>(R.id.linearButton)
        val percentageText = dialogView.findViewById<TextView>(R.id.percentuale)

        // Handle specific logic for tasks and subtasks
        if (isToggleChecked) {
            // If it's a task, display the assigned developer
            devView.text = item.dev ?: "No developer assigned" // Use a default value if dev is null

            hideButton.visibility = View.GONE
            percentageText.text = item.progress.toString()

        } else {
            val editButton = dialogView.findViewById<Button>(R.id.editButton)
            editButton.visibility = View.VISIBLE
            editButton.setOnClickListener {
                showEditForm(item.subtaskName, item.description, item.dev)
            }
            // If it's a subtask, display the priority
            val priority = dialogView.findViewById<TextView>(R.id.priorityTxt)
            priority.text = item.priority

            when (priority.text.toString().trim()) {
                "High" -> {
                    priority.setTextColor(ContextCompat.getColor(context, R.color.high_priority))
                }

                "Medium" -> {
                    priority.setTextColor(ContextCompat.getColor(context, R.color.medium_priority))
                }

                "Low" -> {
                    priority.setTextColor(ContextCompat.getColor(context, R.color.low_priority))
                }
            }

            // If the subtask has a dev field, display it
            devView.text = item.dev ?: "No developer assigned" // Use a default value if dev is null
        }

        // Fetch data for the GridView (only for task_page)
        if (gridView != null) {
            val api = API()
            item.taskName?.let { taskName ->
                api.getSubtaskForGridView(taskName) { items ->
                    handlerGridData(items, role)
                }
            }

            // Set the adapter for the GridView
            val adapter =
                GridAdapter(data, context, role, false, false, false, layoutInflater, taskName)
            gridView?.adapter = adapter
        }

        // Show the dialog
        alertDialog.show()
    }

    /**
     * Handles data for the GridView and updates the UI accordingly.
     *
     * @param items The list of subtasks to display in the GridView.
     * @param role The role of the user.
     */
    private fun handlerGridData(items: ArrayList<ItemsViewModel>, role: String) {
        if (items.isEmpty()) {
            gridView?.visibility = View.GONE
            val noTaskError = dialogView.findViewById<TextView>(R.id.noTask)
            noTaskError.visibility = View.VISIBLE
        } else {
            datas.clear()
            datas.addAll(items)
            val adapter =
                GridAdapter(datas, context, role, false, false, false, layoutInflater, taskName)
            gridView?.adapter = adapter
        }
    }

    /**
     * Displays the edit form for modifying task or subtask details.
     *
     * @param name The current name of the task/subtask.
     * @param description The current description of the task/subtask.
     * @param dev The current assigned developer.
     */
    private fun showEditForm(name: String, description: String, dev: String) {
        val builder = AlertDialog.Builder(context)
        val inflater = LayoutInflater.from(context)
        val dialogView = inflater.inflate(R.layout.edit_form, null)
        builder.setView(dialogView)
        val alertDialog = builder.create()

        val closeForm = dialogView.findViewById<Button>(R.id.cancelEditBtn)
        closeForm.setOnClickListener { alertDialog.dismiss() }

        val toggleName = dialogView.findViewById<ToggleButton>(R.id.toggleName)
        val toggleDescription = dialogView.findViewById<ToggleButton>(R.id.toggleDescription)
        val toggleDev = dialogView.findViewById<ToggleButton>(R.id.toggleDev)
        val inputName = dialogView.findViewById<EditText>(R.id.inputName)
        val inputDescription = dialogView.findViewById<EditText>(R.id.inputDescription)
        val inputDev = dialogView.findViewById<AutoCompleteTextView>(R.id.autoCompleteDev)

        // Configure ToggleButtons
        setupToggleButtons(
            toggleName, inputName,
            toggleDescription, inputDescription,
            toggleDev, inputDev
        )

        inputName.setText(name)
        inputDescription.setText(description)
        inputDev.setText(dev)

        if (toggleDev.isChecked) {
            api.getAllDevelopers() { devList ->
                val adapter = ArrayAdapter(context, android.R.layout.simple_dropdown_item_1line, devList)
                inputDev.setAdapter(adapter)
                inputDev.threshold = 1
            }
        }

        presetEditForm(inputName, inputDescription, inputDev, name, description, dev)

        val confirmEdit = dialogView.findViewById<Button>(R.id.confirmEditBtn)
        confirmEdit.setOnClickListener {
            if (checkToggleStatus(toggleName, toggleDescription, toggleDev)) {
                Toast.makeText(context, "No changes were activated", Toast.LENGTH_SHORT).show()
            } else {
                val fieldValues = getEnabledFieldValues(toggleName, inputName, toggleDescription, inputDescription, toggleDev, inputDev)
                if (taskName.isNotEmpty()) {
                    api.editTaskValues(fieldValues, taskName) { onComplete ->
                        if (onComplete) {
                            Toast.makeText(context, "Edit successful!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Something went wrong during the edit! We apologize", Toast.LENGTH_SHORT).show()
                        }
                    }

                    // Update the task name in subtasks
                    val newTaskName = fieldValues["name"] // Use the key "name" to get the new task name
                    val newDev = fieldValues["dev"]
                    if (newTaskName != null) {
                        api.updateTaskNameInSubs(newTaskName, taskName, newDev) { onComplete ->
                            if (onComplete) {
                                Toast.makeText(context, "Subtasks updated successfully!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Something went wrong while updating subtasks! We apologize", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        Toast.makeText(context, "The new task name is invalid!", Toast.LENGTH_SHORT).show()
                    }
                }

                val newDev = fieldValues["dev"]
                if (newDev != null) {
                    api.updateSpecificSubDev(taskName, newDev) { onComplete ->
                        if (onComplete) {
                            Toast.makeText(
                                context,
                                "Subtasks updated successfully!",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                context,
                                "Something went wrong while updating subtasks! We apologize",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }
        alertDialog.show()
    }

    /**
     * Presets the edit form with current values.
     *
     * @param inputName The EditText for the name.
     * @param inputDescription The EditText for the description.
     * @param inputDev The AutoCompleteTextView for the developer.
     * @param name The current name.
     * @param description The current description.
     * @param dev The current developer.
     */
    private fun presetEditForm(inputName: EditText, inputDescription: EditText, inputDev: AutoCompleteTextView, name: String, description: String, dev: String) {
        inputName.setText(name)
        inputDescription.setText(description)
        inputDev.setText(dev)
    }

    /**
     * Retrieves the values of enabled fields in the edit form.
     *
     * @param toggleName The ToggleButton for the name field.
     * @param inputName The EditText for the name.
     * @param toggleDescription The ToggleButton for the description field.
     * @param inputDescription The EditText for the description.
     * @param toggleDev The ToggleButton for the developer field.
     * @param inputDev The AutoCompleteTextView for the developer.
     * @return A map of field values.
     */
    private fun getEnabledFieldValues(
        toggleName: ToggleButton, inputName: EditText,
        toggleDescription: ToggleButton, inputDescription: EditText,
        toggleDev: ToggleButton, inputDev: AutoCompleteTextView
    ): Map<String, String> {
        val fieldValues = mutableMapOf<String, String>()

        // Check if toggleName is active and add the value of inputName
        if (toggleName.isChecked) {
            fieldValues["name"] = inputName.text.toString()
        }

        // Check if toggleDescription is active and add the value of inputDescription
        if (toggleDescription.isChecked) {
            fieldValues["description"] = inputDescription.text.toString()
        }

        // Check if toggleDev is active and add the value of inputDev
        if (toggleDev.isChecked) {
            fieldValues["dev"] = inputDev.text.toString()
        }

        return fieldValues
    }

    /**
     * Checks if all ToggleButtons are off (no changes activated).
     *
     * @param toggleName The ToggleButton for the name field.
     * @param toggleDescription The ToggleButton for the description field.
     * @param toggleDev The ToggleButton for the developer field.
     * @return True if all ToggleButtons are off, false otherwise.
     */
    private fun checkToggleStatus(toggleName: ToggleButton, toggleDescription: ToggleButton, toggleDev: ToggleButton): Boolean {
        return !toggleName.isChecked &&
                !toggleDescription.isChecked &&
                !toggleDev.isChecked
    }

    /**
     * Sets up ToggleButtons and links them to their respective input fields.
     *
     * @param toggleName The ToggleButton for the name field.
     * @param inputName The EditText for the name.
     * @param toggleDescription The ToggleButton for the description field.
     * @param inputDescription The EditText for the description.
     * @param toggleDev The ToggleButton for the developer field.
     * @param inputDev The AutoCompleteTextView for the developer.
     */
    private fun setupToggleButtons(
        toggleName: ToggleButton, inputName: EditText,
        toggleDescription: ToggleButton, inputDescription: EditText,
        toggleDev: ToggleButton, inputDev: AutoCompleteTextView
    ) {
        // Map to associate each ToggleButton with its respective input field
        val toggleMap = mapOf(
            toggleName to inputName,
            toggleDescription to inputDescription,
            toggleDev to inputDev
        )
        // Iterate over the map and set the listener for each ToggleButton
        for ((toggleButton, inputField) in toggleMap) {
            toggleButton.setOnCheckedChangeListener { _, isChecked ->
                inputField.isEnabled = isChecked // Enable or disable the input field

                if (toggleButton.id == R.id.toggleDev) {
                    if (isChecked) {
                        api.getAllDevelopers() { devList ->
                            val adapter = ArrayAdapter(context, android.R.layout.simple_dropdown_item_1line, devList)
                            inputDev.setAdapter(adapter)
                            inputDev.threshold = 1  // Show suggestions after 1 character
                        }
                    } else {
                        inputDev.setAdapter(null)
                    }
                }
            }
            // Set the initial state of the input field based on the ToggleButton
            inputField.isEnabled = toggleButton.isChecked
        }
    }
}