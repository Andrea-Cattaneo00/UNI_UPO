package com.example.merge_projects

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.sql.Timestamp
import kotlin.collections.ArrayList

class DetailsProjects : AppCompatActivity() {

    private lateinit var role: String
    private lateinit var api: API
    private lateinit var gridView: GridView
    private lateinit var gridAdapter: GridAdapter
    private val data: ArrayList<ItemsViewModel> = ArrayList()
    private var isLongClickEnabled = false
    private var isSecondPage = false
    private var isToggleChecked = true

    /**
     * Initializes the activity and sets up the UI components.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        api = API()

        // Retrieve values from the intent.
        role = intent.getStringExtra("role").toString()
        isToggleChecked = intent.getBooleanExtra("isToggleChecked", false)
        val deadlineMillis = intent.getLongExtra("deadline", 0L)
        val deadlineTimestamp = Timestamp(deadlineMillis)
        val progress = intent.getIntExtra("progress", 0)
        lateinit var name: String

        // Set the layout based on the role and isToggleChecked state.
        setTypePages(role)

        // Set up the page based on the role.
        if (role == "PL" && isToggleChecked) { // Set up the project page for PL.
            name = intent.getStringExtra("projectName") ?: "Unnamed Project"
            setProjPage(name, deadlineTimestamp, progress)
            setUpUserActions(name)
        } else if ((role == "PL" && !isToggleChecked) || (role == "DEV" && isToggleChecked)) {
            name = intent.getStringExtra("taskName") ?: "Unnamed Task"
            val dev = intent.getStringExtra("dev") ?: "Not specified"
            val description = intent.getStringExtra("description") ?: "No description available"
            setTaskPage(name, deadlineTimestamp, progress, dev, description)

            val editTaskBtn = findViewById<ImageButton>(R.id.editTaskBtn)
            if (editTaskBtn != null) {
                editTaskBtn.setOnClickListener {
                    showEditForm(name, description, dev)
                }
            } else {
                Log.e("DetailsProjects", "editTaskBtn not found in the current layout")
            }
            gridView = findViewById(R.id.subtasksGrid)
            gridAdapter = GridAdapter(data, this, role, true, false, isToggleChecked, layoutInflater, taskName)
            gridView.adapter = gridAdapter
            setUpUserActions(name)
        }
    }

    /**
     * Sets the layout type based on the role and isToggleChecked state.
     * @param role The role of the user (PL or DEV).
     */
    private fun setTypePages(role: String) {
        when {
            role == "PL" && isToggleChecked -> setContentView(R.layout.proj_page)
            role == "PL" && !isToggleChecked -> setContentView(R.layout.task_page)
            role == "DEV" && isToggleChecked -> setContentView(R.layout.task_page)
        }
    }

    /**
     * Sets up user actions such as adding or deleting tasks.
     * @param name The name of the project or task.
     */
    private fun setUpUserActions(name: String) {
        val addBtn = findViewById<ImageButton>(R.id.addBtn)
        addBtn.setOnClickListener {
            val newFormActivity = NewProjectFormActivity(this, layoutInflater, null, isToggleChecked)
            newFormActivity.setFormName(name)
            newFormActivity.showAlert(role)
            // TODO: Refresh the page to re-run queries.
        }

        // Set up the delete button listener.
        val toggleListeners = findViewById<ImageButton>(R.id.deleteBtn)
        toggleListeners.setOnClickListener {
            toggleListeners.visibility = View.GONE

            isLongClickEnabled = !isLongClickEnabled
            Toast.makeText(this, if (isLongClickEnabled) "Long click enabled" else "Long click disabled", Toast.LENGTH_SHORT).show()
            gridAdapter = gridView.adapter as GridAdapter
            gridAdapter.setLongClickEnabled(isLongClickEnabled)
            val gridInteractions = findViewById<RelativeLayout>(R.id.gridInteractions)
            gridInteractions.visibility = View.VISIBLE
            setListeners(toggleListeners)
        }
    }

    /**
     * Displays the edit form for a task.
     * @param name The name of the task.
     * @param description The description of the task.
     * @param dev The developer assigned to the task.
     */
    private fun showEditForm(name: String, description: String, dev: String) {
        val builder = AlertDialog.Builder(this)
        val inflater = LayoutInflater.from(this)
        val dialogView = inflater.inflate(R.layout.edit_form, null)
        builder.setView(dialogView)
        val alertDialog = builder.create()

        val closeForm = dialogView.findViewById<Button>(R.id.cancelEditBtn)
        closeForm.setOnClickListener { alertDialog.dismiss() }

        val toggleName = dialogView.findViewById<ToggleButton>(R.id.toggleName)
        val toggleDescription = dialogView.findViewById<ToggleButton>(R.id.toggleDescription)
        val toggleDev = dialogView.findViewById<ToggleButton>(R.id.toggleDev)
        val inputName = dialogView.findViewById<EditText>(R.id.inputName)
        val inputDescription = dialogView.findViewById<EditText>(R.id.inputDescription)
        val inputDev = dialogView.findViewById<AutoCompleteTextView>(R.id.autoCompleteDev)

        // Configure the toggle buttons.
        setupToggleButtons(
            toggleName, inputName,
            toggleDescription, inputDescription,
            toggleDev, inputDev
        )

        inputName.setText(name)
        inputDescription.setText(description)
        inputDev.setText(dev)

        if (toggleDev.isChecked) {
            Log.d("EditForm", "Fetching developers list")
            api.getAllDevelopers { devList ->
                val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, devList)
                inputDev.setAdapter(adapter)
                inputDev.threshold = 1
            }
        }

        presetEditForm(inputName, inputDescription, inputDev, name, description, dev)

        val confirmEdit = dialogView.findViewById<Button>(R.id.confirmEditBtn)
        confirmEdit.setOnClickListener {
            if (checkToggleStatus(toggleName, toggleDescription, toggleDev)) {
                Toast.makeText(this, "No changes were activated", Toast.LENGTH_SHORT).show()
            } else {
                val fieldValues = getEnabledFieldValues(toggleName, inputName, toggleDescription, inputDescription, toggleDev, inputDev)
                if (taskName.isNotEmpty()) {
                    api.editTaskValues(fieldValues, taskName) { onComplete ->
                        if (onComplete) {
                            Toast.makeText(this, "Task updated successfully!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Something went wrong during the update!", Toast.LENGTH_SHORT).show()
                        }
                    }

                    // Update the task name in subtasks.
                    val newTaskName = fieldValues["name"]
                    val newDev = fieldValues["dev"]
                    if (newTaskName != null) {
                        api.updateTaskNameInSubs(newTaskName, taskName, newDev) { onComplete ->
                            if (onComplete) {
                                Toast.makeText(this, "Subtasks updated successfully!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Something went wrong while updating subtasks!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        Toast.makeText(this, "Invalid new task name!", Toast.LENGTH_SHORT).show()
                    }
                }

                val newDev = fieldValues["dev"]
                if (newDev != null) {
                    api.updateSpecificSubDev(taskName, newDev) { onComplete ->
                        if (onComplete) {
                            Toast.makeText(this, "Subtasks updated successfully!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Something went wrong while updating subtasks!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    /**
     * Presets the edit form with existing values.
     */
    private fun presetEditForm(inputName: EditText, inputDescription: EditText, inputDev: AutoCompleteTextView, name: String, description: String, dev: String) {
        inputName.setText(name)
        inputDescription.setText(description)
        inputDev.setText(dev)
    }

    /**
     * Retrieves the values of enabled fields in the edit form.
     */
    private fun getEnabledFieldValues(
        toggleName: ToggleButton, inputName: EditText,
        toggleDescription: ToggleButton, inputDescription: EditText,
        toggleDev: ToggleButton, inputDev: AutoCompleteTextView
    ): Map<String, String> {
        val fieldValues = mutableMapOf<String, String>()

        if (toggleName.isChecked) {
            fieldValues["name"] = inputName.text.toString()
        }

        if (toggleDescription.isChecked) {
            fieldValues["description"] = inputDescription.text.toString()
        }

        if (toggleDev.isChecked) {
            fieldValues["dev"] = inputDev.text.toString()
        }

        return fieldValues
    }

    /**
     * Checks if all toggle buttons are off (no changes activated).
     */
    private fun checkToggleStatus(toggleName: ToggleButton, toggleDescription: ToggleButton, toggleDev: ToggleButton): Boolean {
        return !toggleName.isChecked &&
                !toggleDescription.isChecked &&
                !toggleDev.isChecked
    }

    /**
     * Sets up toggle buttons and their listeners.
     */
    private fun setupToggleButtons(
        toggleName: ToggleButton, inputName: EditText,
        toggleDescription: ToggleButton, inputDescription: EditText,
        toggleDev: ToggleButton, inputDev: AutoCompleteTextView
    ) {
        val toggleMap = mapOf(
            toggleName to inputName,
            toggleDescription to inputDescription,
            toggleDev to inputDev
        )

        for ((toggleButton, inputField) in toggleMap) {
            toggleButton.setOnCheckedChangeListener { _, isChecked ->
                inputField.isEnabled = isChecked

                if (toggleButton.id == R.id.toggleDev) {
                    if (isChecked) {
                        api.getAllDevelopers { devList ->
                            val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, devList)
                            inputDev.setAdapter(adapter)
                            inputDev.threshold = 1
                        }
                    } else {
                        inputDev.setAdapter(null)
                    }
                }
            }
            inputField.isEnabled = toggleButton.isChecked
        }
    }

    /**
     * Marks the page as the second page.
     */
    fun setIsSecondPage() {
        isSecondPage = true
    }

    /**
     * Sets up listeners for the delete and cancel buttons.
     */
    private fun setListeners(toggleListeners: ImageButton) {
        val cancelBtn = findViewById<ImageButton>(R.id.cancelBtn)
        cancelBtn.setOnClickListener {
            isLongClickEnabled = !isLongClickEnabled
            gridAdapter.setLongClickEnabled(isLongClickEnabled)
            gridAdapter.resetCardBackgrounds()
            val gridInteractions = findViewById<RelativeLayout>(R.id.gridInteractions)
            gridInteractions.visibility = View.GONE
            cancelBtn.visibility = View.VISIBLE
            toggleListeners.visibility = View.VISIBLE
        }

        val confirmBtn = findViewById<ImageButton>(R.id.confirmBtn)
        confirmBtn.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            val inflater = layoutInflater
            val dialogView = inflater.inflate(R.layout.sure_form, null)
            builder.setView(dialogView)
            val alertDialog = builder.create()

            val notSureBtn = dialogView.findViewById<Button>(R.id.notSureBtn)
            val sureBtn = dialogView.findViewById<Button>(R.id.sureBtn)
            val deleteItemList = gridAdapter.getDeleteItemTempList()

            if (role == "PL") {
                sureBtn.setOnClickListener {
                    api.removeTasks(deleteItemList) { success ->
                        if (success) {
                            gridAdapter.removeItems(deleteItemList)
                            gridAdapter.notifyDataSetChanged()
                            Toast.makeText(this, "Items deleted successfully!", Toast.LENGTH_SHORT).show()
                            alertDialog.dismiss()
                        } else {
                            Toast.makeText(this, "Error deleting items!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                sureBtn.setOnClickListener {
                    api.removeSubTasks(deleteItemList) { success ->
                        if (success) {
                            gridAdapter.removeItems(deleteItemList)
                            gridAdapter.notifyDataSetChanged()
                            Toast.makeText(this, "Subtasks deleted successfully!", Toast.LENGTH_SHORT).show()
                            alertDialog.dismiss()
                        } else {
                            Toast.makeText(this, "Error deleting subtasks!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            notSureBtn.setOnClickListener { alertDialog.dismiss() }
            alertDialog.show()
        }
    }

    /**
     * Sets up the project page with the provided details.
     */
    private fun setProjPage(name: String, deadline: Timestamp, progress: Int) {
        val textTaskName = findViewById<TextView>(R.id.name)
        val textDeadline = findViewById<TextView>(R.id.deadlineTxt)
        val progressbar = findViewById<ProgressBar>(R.id.progressBar)
        val percentageText = findViewById<TextView>(R.id.percentage)

        textTaskName.text = name
        textDeadline.text = deadline.toString()
        progressbar.progress = progress
        percentageText.text = progress.toString()

        setGridView(name)
    }

    private var taskName: String = ""

    /**
     * Sets up the task page with the provided details.
     */
    private fun setTaskPage(
        name: String,
        deadline: Timestamp,
        progress: Int,
        dev: String,
        description: String
    ) {
        val textTaskName = findViewById<TextView>(R.id.name)
        val textDeadline = findViewById<TextView>(R.id.deadlineTxt)
        val progressbar = findViewById<ProgressBar>(R.id.progressBar)
        val percentageText = findViewById<TextView>(R.id.percentuale)
        val descriptionView = findViewById<TextView>(R.id.taskDescription)
        val devView = findViewById<TextView>(R.id.taskDev)

        devView.text = dev
        textTaskName.text = name
        taskName = textTaskName.text as String
        textDeadline.text = deadline.toString()
        progressbar.progress = progress
        percentageText.text = progress.toString()
        descriptionView.text = description

        setGridView(name)
    }

    /**
     * Sets up the grid view based on the role and name.
     */
    private fun setGridView(name: String) {
        if (role == "PL" && isToggleChecked) {
            api.getTaskForGridView(name) { items ->
                handlerGridData(items)
            }
        } else if (role == "DEV" || (role == "PL" && !isToggleChecked)) {
            api.getSubtaskForGridView(name) { items ->
                handlerGridData(items)
            }
        }
    }

    /**
     * Handles the grid data and updates the UI accordingly.
     */
    private fun handlerGridData(items: ArrayList<ItemsViewModel>) {
        gridView = findViewById(R.id.subtasksGrid)

        if (items.isEmpty()) {
            gridView.visibility = View.GONE
            val noTaskError = findViewById<TextView>(R.id.noTask)
            noTaskError.visibility = View.VISIBLE
        } else {
            data.clear()
            data.addAll(items)
            val adapter = GridAdapter(data, this, role, true, false, isToggleChecked, layoutInflater, taskName)
            gridView.adapter = adapter
        }
    }
}