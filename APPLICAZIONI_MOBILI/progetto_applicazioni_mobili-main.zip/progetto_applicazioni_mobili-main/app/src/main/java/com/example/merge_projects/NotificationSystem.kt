package com.example.merge_projects

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import com.google.auth.oauth2.GoogleCredentials
import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.InputStream

/**
 * Sends a notification to a specific device using Firebase Cloud Messaging (FCM).
 *
 * @param deviceToken The token of the device to which the notification will be sent.
 * @param title The title of the notification.
 * @param body The body/content of the notification.
 * @param accessToken The access token required to authenticate the FCM request.
 */
fun sendNotification(deviceToken: String, title: String, body: String, accessToken: String) {
    val client = OkHttpClient()

    // FCM API V1 URL
    val url = "https://fcm.googleapis.com/v1/projects/progetto-app-mobili/messages:send"

    // Create the JSON payload
    val json = """
        {
            "message": {
                "token": "$deviceToken",
                "notification": {
                    "title": "$title",
                    "body": "$body"
                },
                "data": {
                    "key1": "value1",
                    "key2": "value2"
                }
            }
        }
    """.trimIndent()

    // Create the request body
    val mediaType = "application/json; charset=utf-8".toMediaType()
    val requestBody = json.toRequestBody(mediaType)

    // Build the HTTP request
    val request = Request.Builder()
        .url(url)
        .addHeader("Authorization", "Bearer $accessToken")
        .addHeader("Content-Type", "application/json")
        .post(requestBody)
        .build()

    // Execute the request
    val response = client.newCall(request).execute()
    println(response.body?.string())
}

/**
 * Retrieves an access token for Firebase using GoogleCredentials.
 *
 * @param context The application context to access resources.
 * @return The access token as a String.
 */
fun getAccessToken(context: Context): String {
    // Open the JSON file from the res/raw folder
    val inputStream: InputStream = context.resources.openRawResource(R.raw.progetto_app_mobili_firebase_adminsdk_swabb_199701b9b6)

    // Generate the access token
    val credentials = GoogleCredentials.fromStream(inputStream)
        .createScoped(listOf("https://www.googleapis.com/auth/firebase.messaging"))
    credentials.refreshIfExpired()
    return credentials.accessToken.tokenValue
}

/**
 * Sends a reminder notification to the appropriate user based on their role.
 *
 * @param role The role of the user (e.g., "PM", "PL").
 * @param data The data containing project/task details.
 * @param context The application context to access resources.
 */
fun sendReminder(role: String, data: ItemsViewModel, context: Context) {
    val messageTitle = "Reminder!"
    val messageBody = "It is necessary to complete the project: ${data.projectName}"

    // TODO: Retrieve the DEV token related to the task
    // TODO: Retrieve the PL token related to the project
    if (role == "PM") {
        getUserToken(data.PL, "PL") { token ->
            if (token != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    // No need to terminate the coroutine as it ends automatically after execution
                    val accessToken = getAccessToken(context)
                    sendNotification(token, messageTitle, messageBody, accessToken)
                }
            } else {
                Log.d("Token", "Error occurred during the user token fetching")
            }
        }
    } else if (role == "PL") {
        getUserToken(data.dev, "DEV") { token ->
            if (token != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    // No need to terminate the coroutine as it ends automatically after execution
                    val accessToken = getAccessToken(context)
                    sendNotification(token, messageTitle, messageBody, accessToken)
                }
            } else {
                Log.d("Token", "Error occurred during the user token fetching")
            }
        }
    }
}

/**
 * Retrieves the user token based on the user's role.
 *
 * @param user The user identifier.
 * @param target The role of the user (e.g., "PL", "PM", "DEV").
 * @param onComplete A callback function that receives the token or null if an error occurs.
 */
fun getUserToken(user: String, target: String, onComplete: (String?) -> Unit) {
    val api = API()
    when (target) {
        "PL" -> {
            api.getTokenOf(user, "PL") { token ->
                if (token != null) {
                    onComplete(token)
                } else {
                    Log.d("Token", "Token not found")
                    onComplete(null)
                }
            }
        }
        "PM" -> {
            api.getTokenOf(user, "PM") { token ->
                if (token != null) {
                    onComplete(token)
                } else {
                    Log.d("Token", "Token not found")
                    onComplete(null)
                }
            }
        }
        "DEV" -> {
            api.getTokenOf(user, "DV") { token ->
                if (token != null) {
                    onComplete(token)
                } else {
                    Log.d("Token", "Token not found")
                    onComplete(null)
                }
            }
        }
    }
}