package com.example.merge_projects

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.merge_projects.adapter.SearchUserRecyclerAdapter
import com.example.merge_projects.model.UserModel
import com.example.merge_projects.utils.FirebaseUtil
import com.firebase.ui.firestore.FirestoreRecyclerOptions

class SearchUserActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private var adapter: SearchUserRecyclerAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_user)

        // Initialize UI elements
        recyclerView = findViewById(R.id.search_user_recycler_view)
        val searchInput: EditText = findViewById(R.id.search_email_input)
        val searchButton: ImageButton = findViewById(R.id.search_user_btn)
        val backButton: ImageButton = findViewById(R.id.back_btn)

        // Set focus on the search input field
        searchInput.requestFocus()

        // Set up the back button to navigate back
        backButton.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Set up the search button to trigger the search
        searchButton.setOnClickListener {
            val searchTerm = searchInput.text.toString()
            if (searchTerm.isEmpty()) {
                searchInput.error = "Invalid email"
                return@setOnClickListener
            }
            setupSearchRecyclerView(searchTerm)
        }
    }

    /**
     * Sets up the RecyclerView to display search results based on the provided search term.
     *
     * @param searchTerm The email or part of the email to search for.
     */
    private fun setupSearchRecyclerView(searchTerm: String) {
        // Create a Firestore query to search for users with emails greater than or equal to the search term
        val query = FirebaseUtil.allUserCollectionReference()
            .whereGreaterThanOrEqualTo("email", searchTerm)

        // Configure the FirestoreRecyclerOptions for the adapter
        val options = FirestoreRecyclerOptions.Builder<UserModel>()
            .setQuery(query, UserModel::class.java)
            .setLifecycleOwner(this)
            .build()

        // Initialize the adapter with the configured options
        adapter = SearchUserRecyclerAdapter(options, this)

        // Set up the RecyclerView with a LinearLayoutManager and the adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        adapter?.startListening()
    }

    override fun onStart() {
        super.onStart()
        // Start listening for Firestore data when the activity starts
        adapter?.startListening()
    }

    override fun onStop() {
        super.onStop()
        // Stop listening for Firestore data when the activity stops
        adapter?.stopListening()
    }

    override fun onResume() {
        super.onResume()
        // Start listening for Firestore data when the activity resumes
        adapter?.startListening()
    }
}