package com.example.merge_projects.model

import com.google.firebase.Timestamp

/**
 * Data class representing a chatroom in the application.
 *
 * @property chatroomId The unique identifier for the chatroom. Can be null if not yet assigned.
 * @property userIds A list of user IDs participating in the chatroom. Can be null if no users are added yet.
 * @property lastMessageTimestamp The timestamp of the last message sent in the chatroom. Can be null if no messages have been sent.
 * @property lastMessageSenderId The ID of the user who sent the last message in the chatroom. Can be null if no messages have been sent.
 */
data class ChatroomModel(
    var chatroomId: String? = null, // Unique identifier for the chatroom
    var userIds: List<String?>? = null, // List of user IDs in the chatroom
    var lastMessageTimestamp: Timestamp? = null, // Timestamp of the last message
    var lastMessageSenderId: String? = null // ID of the last message sender
)